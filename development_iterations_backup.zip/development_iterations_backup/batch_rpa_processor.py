"""
Batch RPA Processor

Processes multiple recording sessions in batch to generate RPA commands.
Includes progress tracking, error handling, and summary reporting.
"""

import os
import json
import time
from datetime import datetime
from typing import List, Dict, Optional
from dataclasses import dataclass
from simple_rpa_generator import SimpleRpaGenerator
from rpa_config import RpaConfig

@dataclass
class ProcessingResult:
    """Result of processing a single session"""
    session_name: str
    success: bool
    output_file: Optional[str] = None
    error_message: Optional[str] = None
    processing_time: float = 0.0
    tokens_used: int = 0

class BatchRpaProcessor:
    """Batch processor for multiple RPA sessions"""
    
    def __init__(self, records_dir: str = "records"):
        """Initialize batch processor"""
        self.records_dir = records_dir
        self.generator = SimpleRpaGenerator()
        self.config = RpaConfig()
        self.results: List[ProcessingResult] = []
        
    def discover_processable_sessions(self) -> List[Dict[str, str]]:
        """Discover all processable sessions in the records directory"""
        sessions = []
        
        for filename in os.listdir(self.records_dir):
            if filename.endswith('.mp4'):
                base_name = filename.replace('.mp4', '')
                corresponding_json = f"{base_name}_interactions.json"
                
                video_path = os.path.join(self.records_dir, filename)
                json_path = os.path.join(self.records_dir, corresponding_json)
                
                if os.path.exists(json_path):
                    # Check file size
                    size_mb = os.path.getsize(video_path) / (1024 * 1024)
                    if size_mb <= self.config.MAX_FILE_SIZE_MB:
                        sessions.append({
                            'name': base_name,
                            'video_path': video_path,
                            'json_path': json_path,
                            'size_mb': size_mb
                        })
        
        # Sort by size (process smaller files first)
        sessions.sort(key=lambda x: x['size_mb'])
        return sessions
    
    def process_session_with_tracking(self, session: Dict[str, str]) -> ProcessingResult:
        """Process a single session with error tracking"""
        session_name = session['name']
        start_time = time.time()
        
        print(f"\n📹 Processing: {session_name}")
        print(f"   Size: {session['size_mb']:.1f} MB")
        
        try:
            # Process the session
            rpa_commands = self.generator.process_single_session(
                session['video_path'], 
                session['json_path'],
                f"{session_name}_rpa_commands.txt"
            )
            
            processing_time = time.time() - start_time
            
            if rpa_commands:
                output_file = f"{session_name}_rpa_commands.txt"
                return ProcessingResult(
                    session_name=session_name,
                    success=True,
                    output_file=output_file,
                    processing_time=processing_time
                )
            else:
                return ProcessingResult(
                    session_name=session_name,
                    success=False,
                    error_message="Failed to generate RPA commands",
                    processing_time=processing_time
                )
                
        except Exception as e:
            processing_time = time.time() - start_time
            return ProcessingResult(
                session_name=session_name,
                success=False,
                error_message=str(e),
                processing_time=processing_time
            )
    
    def process_all_sessions(self, max_sessions: Optional[int] = None, 
                           delay_between_sessions: float = 2.0) -> None:
        """Process all available sessions with progress tracking"""
        
        print("🔍 Discovering processable sessions...")
        sessions = self.discover_processable_sessions()
        
        if not sessions:
            print("❌ No processable sessions found")
            return
        
        if max_sessions:
            sessions = sessions[:max_sessions]
        
        total_sessions = len(sessions)
        print(f"📊 Found {total_sessions} processable sessions")
        
        # Calculate estimated size
        total_size = sum(s['size_mb'] for s in sessions)
        print(f"📏 Total data: {total_size:.1f} MB")
        
        print(f"\n🚀 Starting batch processing...")
        print(f"   Delay between sessions: {delay_between_sessions}s")
        print(f"   Max file size: {self.config.MAX_FILE_SIZE_MB} MB")
        print("=" * 60)
        
        start_time = time.time()
        
        for i, session in enumerate(sessions, 1):
            print(f"\n📈 Progress: {i}/{total_sessions} ({i/total_sessions*100:.1f}%)")
            
            # Process session
            result = self.process_session_with_tracking(session)
            self.results.append(result)
            
            # Print immediate result
            if result.success:
                print(f"✅ Success: {result.session_name} ({result.processing_time:.1f}s)")
            else:
                print(f"❌ Failed: {result.session_name} - {result.error_message}")
            
            # Delay between sessions (except for the last one)
            if i < total_sessions and delay_between_sessions > 0:
                print(f"⏸️  Waiting {delay_between_sessions}s before next session...")
                time.sleep(delay_between_sessions)
        
        total_time = time.time() - start_time
        print(f"\n🏁 Batch processing complete!")
        print(f"   Total time: {total_time:.1f}s")
        
        # Generate summary
        self.generate_summary()
        
    def generate_summary(self) -> None:
        """Generate and save processing summary"""
        if not self.results:
            return
        
        successful = [r for r in self.results if r.success]
        failed = [r for r in self.results if not r.success]
        
        total_time = sum(r.processing_time for r in self.results)
        avg_time = total_time / len(self.results) if self.results else 0
        
        print(f"\n📊 BATCH PROCESSING SUMMARY")
        print("=" * 50)
        print(f"Total sessions processed: {len(self.results)}")
        print(f"Successful: {len(successful)} ({len(successful)/len(self.results)*100:.1f}%)")
        print(f"Failed: {len(failed)} ({len(failed)/len(self.results)*100:.1f}%)")
        print(f"Total processing time: {total_time:.1f}s")
        print(f"Average time per session: {avg_time:.1f}s")
        
        if successful:
            print(f"\n✅ Successful Sessions:")
            for result in successful:
                print(f"   • {result.session_name} → {result.output_file}")
        
        if failed:
            print(f"\n❌ Failed Sessions:")
            for result in failed:
                print(f"   • {result.session_name}: {result.error_message}")
        
        # Save summary to file
        summary_data = {
            "timestamp": datetime.now().isoformat(),
            "total_sessions": len(self.results),
            "successful_count": len(successful),
            "failed_count": len(failed),
            "total_processing_time": total_time,
            "average_time_per_session": avg_time,
            "successful_sessions": [
                {
                    "session_name": r.session_name,
                    "output_file": r.output_file,
                    "processing_time": r.processing_time
                }
                for r in successful
            ],
            "failed_sessions": [
                {
                    "session_name": r.session_name,
                    "error_message": r.error_message,
                    "processing_time": r.processing_time
                }
                for r in failed
            ]
        }
        
        output_dir = self.config.ensure_output_dir()
        summary_file = os.path.join(output_dir, f"batch_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        
        with open(summary_file, 'w') as f:
            json.dump(summary_data, f, indent=2)
        
        print(f"\n💾 Summary saved to: {summary_file}")


def main():
    """Main function for batch processing"""
    import sys
    
    print("🔄 Batch RPA Processor")
    print("=" * 40)
    
    try:
        processor = BatchRpaProcessor()
        
        # Check command line arguments
        max_sessions = None
        delay = 2.0
        
        if len(sys.argv) > 1:
            try:
                max_sessions = int(sys.argv[1])
                print(f"🎯 Processing maximum {max_sessions} sessions")
            except ValueError:
                print("❌ Invalid session count, processing all sessions")
        
        if len(sys.argv) > 2:
            try:
                delay = float(sys.argv[2])
                print(f"⏱️  Using {delay}s delay between sessions")
            except ValueError:
                print("❌ Invalid delay value, using default 2.0s")
        
        # Process all sessions
        processor.process_all_sessions(max_sessions=max_sessions, delay_between_sessions=delay)
        
    except KeyboardInterrupt:
        print("\n⏹️  Processing interrupted by user")
    except Exception as e:
        print(f"❌ Fatal error: {e}")


if __name__ == "__main__":
    main()