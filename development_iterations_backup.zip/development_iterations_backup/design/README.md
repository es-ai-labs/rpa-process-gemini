# Design Diagrams for Intelligent Murex RPA System

This folder contains Mermaid diagrams that document the architecture and workflows of the Intelligent Murex RPA System.

## Diagram Files

### 1. `01-system-architecture-overview.mmd`
**Purpose**: High-level system architecture showing all major components and their relationships
**Key Features**:
- Data capture layer (video, audio, UI interactions)
- Workflow processing pipeline with AI synthesis
- Intelligent agent core with natural language understanding
- RPA execution engine
- Operating modes (Assistant, Configuration Copy, Debug)

### 2. `02-user-journey-workflows.mmd`
**Purpose**: Step-by-step user journeys for different operational modes
**Key Features**:
- Workflow creation process
- Assistant mode execution flow
- Configuration copy process
- Debug mode operations

### 3. `03-technical-implementation-map.mmd`
**Purpose**: Detailed technical implementation showing existing Python modules
**Key Features**:
- Current file structure and relationships
- Processing modules and their connections
- Data storage organization
- Testing and validation components

### 4. `04-sequence-diagram.mmd`
**Purpose**: Detailed interaction sequences between system components
**Key Features**:
- Workflow creation process interactions
- Assistant mode execution sequence
- Configuration copy mode sequence
- Debug mode sequence

## How to Use These Diagrams

### Viewing the Diagrams

1. **Mermaid Live Editor** (Recommended)
   - Go to https://mermaid.live
   - Copy the content from any `.mmd` file
   - Paste into the editor
   - View and export as images

2. **GitHub**
   - Create markdown files with the content wrapped in ```mermaid code blocks
   - GitHub will render the diagrams automatically

3. **VS Code**
   - Install the "Mermaid Preview" extension
   - Open `.mmd` files to see live preview
   - Export as images using the extension

4. **Documentation Tools**
   - Many documentation platforms support Mermaid
   - Check your platform's documentation for Mermaid support

### Color Coding System

The diagrams use a high-contrast color scheme for better visibility:

- **Blue** (`#1e3a8a`): Data capture and interface components
- **Purple** (`#7c3aed`): Core processing modules
- **Green** (`#059669`): Video processing and storage
- **Red** (`#dc2626`): RPA execution components
- **Orange** (`#ea580c`): Session management
- **Cyan** (`#0891b2`): Configuration and AI integration
- **Pink** (`#be185d`): Testing and validation

### Editing the Diagrams

1. **Modify Colors**: Update the `classDef` sections to change component colors
2. **Add Components**: Insert new nodes and connections as needed
3. **Update Text**: Modify node labels and descriptions
4. **Adjust Layout**: Change graph direction (`TB`, `LR`, etc.) or node positioning

### Best Practices

1. **Keep it Simple**: Don't overcrowd diagrams with too many components
2. **Use Consistent Naming**: Maintain consistent naming conventions
3. **Update Regularly**: Keep diagrams in sync with code changes
4. **Version Control**: Track diagram changes in git
5. **Document Changes**: Update this README when adding new diagrams

## Integration with Development

These diagrams should be updated as the system evolves:

- **New Components**: Add new modules and their relationships
- **Architecture Changes**: Reflect major architectural decisions
- **User Flows**: Update when new operational modes are added
- **Technical Details**: Keep implementation map current with actual code

## Export Options

From Mermaid Live Editor, you can export diagrams as:
- PNG (recommended for documentation)
- SVG (scalable, good for web)
- PDF (for formal documentation)
- JSON (for programmatic use)

## Troubleshooting

- **Rendering Issues**: Check Mermaid syntax in the live editor
- **Color Problems**: Verify hex color codes are valid
- **Layout Issues**: Adjust graph direction or node positioning
- **Missing Components**: Ensure all referenced nodes are defined

---

**Last Updated**: January 2025  
**Maintained By**: Development Team  
**Version**: 1.0 