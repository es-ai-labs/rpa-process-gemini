#!/usr/bin/env python3
"""
Enhanced RPA Recorder - FULL COMPREHENSIVE VERSION
Video + Audio + Safe Comprehensive UI + Hybrid Keyboard Logging
Maximum visibility with zero crashes
"""

import os
import sys
import time
import json
import threading
import traceback
import subprocess
from datetime import datetime
from pathlib import Path
import platform
import wave

# Basic imports
try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
    import cv2
    import numpy as np
    import mss
except ImportError as e:
    print(f"Error importing required libraries: {e}")
    print("Please install requirements: pip install opencv-python mss pillow")
    sys.exit(1)

# Audio imports
try:
    import pyaudio
    AUDIO_AVAILABLE = True
except ImportError:
    AUDIO_AVAILABLE = False
    print("Audio recording not available (pyaudio not installed)")

# macOS specific imports
try:
    from AppKit import NSPasteboard, NSEvent, NSWorkspace
    from Cocoa import NSRunLoop, NSDefaultRunLoopMode
    APPKIT_AVAILABLE = True
except ImportError:
    APPKIT_AVAILABLE = False
    print("AppKit not available - some keyboard features disabled")

# Accessibility
try:
    from accessibility_enhanced import create_accessibility_inspector
    ACCESSIBILITY_AVAILABLE = True
except ImportError:
    ACCESSIBILITY_AVAILABLE = False
    print("Enhanced accessibility not available")

PLATFORM = platform.system()

class FullComprehensiveVideoRecorder:
    """Full comprehensive video recorder with audio"""
    
    def __init__(self):
        self.recording = False
        self.output_path = None
        self.fps = 15
        self.record_thread = None
        self.audio_thread = None
        self.video_writer = None
        self.audio_frames = []
        
        # Audio settings
        self.audio_format = pyaudio.paInt16
        self.channels = 1
        self.rate = 22050
        self.chunk = 512
        self.audio = None
        
    def start_recording(self, output_path, fps=15, record_audio=True):
        """Start full comprehensive recording"""
        if self.recording:
            return False
        
        self.output_path = output_path
        self.fps = fps
        self.recording = True
        self.audio_frames = []
        
        print(f"🎬 Starting full comprehensive recording: {output_path}")
        
        # Start video recording
        self.record_thread = threading.Thread(target=self._video_loop)
        self.record_thread.daemon = True
        self.record_thread.start()
        
        # Start audio recording
        if AUDIO_AVAILABLE and record_audio:
            try:
                self.audio_thread = threading.Thread(target=self._audio_loop)
                self.audio_thread.daemon = True
                self.audio_thread.start()
                print("🎤 Full comprehensive audio recording enabled")
            except Exception as e:
                print(f"⚠️ Audio recording failed: {e}")
        
        return True
    
    def _video_loop(self):
        """Video recording loop"""
        try:
            with mss.mss() as sct:
                monitor = sct.monitors[0]
                
                first_screenshot = sct.grab(monitor)
                first_frame = np.array(first_screenshot)
                
                if first_frame.shape[2] == 4:
                    first_frame = cv2.cvtColor(first_frame, cv2.COLOR_BGRA2BGR)
                
                height, width = first_frame.shape[:2]
                
                # Use more reliable codec and settings - FIXED: Better video writer configuration
                fourcc = cv2.VideoWriter_fourcc(*'H264')  # More reliable than mp4v
                
                # Ensure dimensions are even numbers (required for H264)
                if width % 2 != 0:
                    width -= 1
                if height % 2 != 0:
                    height -= 1
                
                self.video_writer = cv2.VideoWriter(self.output_path, fourcc, self.fps, (width, height))
                
                if not self.video_writer.isOpened():
                    print("❌ H264 failed, trying fallback codec...")
                    # Fallback to more compatible codec
                    fourcc = cv2.VideoWriter_fourcc(*'XVID')
                    self.video_writer = cv2.VideoWriter(self.output_path.replace('.mp4', '.avi'), fourcc, self.fps, (width, height))
                    
                    if not self.video_writer.isOpened():
                        print("❌ Video writer initialization failed completely")
                        return
                
                frame_count = 0
                
                while self.recording:
                    try:
                        screenshot = sct.grab(monitor)
                        frame = np.array(screenshot)
                        
                        if frame.shape[2] == 4:
                            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
                        
                        # FIXED: Ensure frame dimensions match video writer
                        if frame.shape[:2] != (height, width):
                            frame = cv2.resize(frame, (width, height))
                        
                        frame = frame.astype(np.uint8)
                        
                        # FIXED: Check if video writer is still valid before writing
                        if self.video_writer and self.video_writer.isOpened():
                            success = self.video_writer.write(frame)
                            if success:
                                frame_count += 1
                            else:
                                print(f"⚠️ Frame write failed at frame {frame_count}")
                        
                        time.sleep(1.0 / self.fps)
                        
                    except Exception as e:
                        print(f"Frame error: {e}")
                        time.sleep(0.1)
                
                print(f"📹 Full comprehensive video complete: {frame_count} frames")
                
        except Exception as e:
            print(f"Video recording error: {e}")
        finally:
            if self.video_writer:
                self.video_writer.release()
    
    def _audio_loop(self):
        """Audio recording loop"""
        try:
            self.audio = pyaudio.PyAudio()
            
            device_info = None
            for i in range(self.audio.get_device_count()):
                try:
                    info = self.audio.get_device_info_by_index(i)
                    if info['maxInputChannels'] > 0:
                        device_info = info
                        break
                except:
                    continue
            
            if not device_info:
                return
            
            stream = self.audio.open(
                format=self.audio_format,
                channels=self.channels,
                rate=self.rate,
                input=True,
                frames_per_buffer=self.chunk,
                input_device_index=device_info['index']
            )
            
            while self.recording:
                try:
                    data = stream.read(self.chunk, exception_on_overflow=False)
                    self.audio_frames.append(data)
                except:
                    time.sleep(0.01)
            
            stream.stop_stream()
            stream.close()
            
        except Exception as e:
            print(f"Audio error: {e}")
        finally:
            if self.audio:
                self.audio.terminate()
    
    def stop_recording(self):
        """Stop recording"""
        if not self.recording:
            return
        
        print("🛑 Stopping full comprehensive recording...")
        self.recording = False
        
        if self.record_thread:
            self.record_thread.join(timeout=3)
        if self.audio_thread:
            self.audio_thread.join(timeout=2)
        
        if self.audio_frames:
            self._save_audio()
        
        print("✅ Full comprehensive recording stopped")
    
    def _save_audio(self):
        """Save audio file"""
        try:
            audio_path = self.output_path.replace('.mp4', '_audio.wav')
            with wave.open(audio_path, 'wb') as wf:
                wf.setnchannels(self.channels)
                wf.setsampwidth(pyaudio.get_sample_size(self.audio_format))
                wf.setframerate(self.rate)
                wf.writeframes(b''.join(self.audio_frames))
            print(f"🎵 Audio saved: {audio_path}")
        except Exception as e:
            print(f"Audio save error: {e}")

class FullComprehensiveInteractionLogger:
    """Full comprehensive interaction logger with hybrid keyboard capture"""
    
    def __init__(self, accessibility_inspector=None):
        self.inspector = accessibility_inspector
        self.interactions = []
        self.keyboard_events = []
        self.logging = False
        
        # Mouse tracking
        self.mouse_thread = None
        self.last_position = None
        self.last_ui_capture = 0
        self.last_click_check = 0
        self.click_state = False
        
        # Keyboard tracking (hybrid approach)
        self.keyboard_threads = []
        self.last_clipboard = ""
        self.last_app = ""
        self.last_modifier_state = 0
        self.activity_indicators = {
            'clipboard_changes': 0,
            'app_switches': 0,
            'modifier_presses': 0,
            'window_changes': 0
        }
        
        self.start_time = None
        
    def start_logging(self, capture_keyboard=True):
        """Start full comprehensive interaction logging"""
        if self.logging:
            return True
        
        self.logging = True
        self.interactions = []
        self.keyboard_events = []
        self.start_time = time.time()
        
        # Start mouse tracking
        self.mouse_thread = threading.Thread(target=self._comprehensive_mouse_loop)
        self.mouse_thread.daemon = True
        self.mouse_thread.start()
        
        # Start hybrid keyboard tracking
        if capture_keyboard and APPKIT_AVAILABLE:
            self._start_hybrid_keyboard_logging()
        
        print("✅ Full comprehensive interaction logging started")
        return True
    
    def _start_hybrid_keyboard_logging(self):
        """Start enhanced hybrid keyboard logging threads"""
        try:
            # Initialize state
            self.last_clipboard = self._get_clipboard()
            self.last_app = self._get_current_app()
            self.last_modifier_state = NSEvent.modifierFlags()
            
            # Enhanced keyboard monitoring threads
            keyboard_monitors = [
                ('clipboard', self._clipboard_monitor),
                ('app_focus', self._app_focus_monitor),
                ('modifier_keys', self._modifier_monitor),
                ('typing_activity', self._typing_activity_monitor),
                ('text_field_monitor', self._text_field_monitor),
                ('global_key_events', self._global_key_event_monitor),
                ('typing_pattern_detector', self._typing_pattern_detector),
                ('applescript_key_monitor', self._applescript_key_monitor)
            ]
            
            self.keyboard_threads = []
            for name, target in keyboard_monitors:
                thread = threading.Thread(target=target, name=f'kbd_{name}')
                thread.daemon = True
                thread.start()
                self.keyboard_threads.append(thread)
            
            # Initialize enhanced tracking variables
            self.key_sequence_buffer = []
            self.last_key_time = 0
            self.typing_session_start = None
            self.consecutive_key_count = 0
            self.backspace_count = 0
            self.enter_count = 0
            self.tab_count = 0
            
            print("⌨️ Enhanced hybrid keyboard logging enabled")
            
        except Exception as e:
            print(f"❌ Keyboard logging setup failed: {e}")
    
    def _comprehensive_mouse_loop(self):
        """Comprehensive mouse tracking loop"""
        print("🔍 Starting full comprehensive mouse tracking...")
        sample_count = 0
        
        while self.logging:
            try:
                current_time = time.time()
                current_pos = self._get_safe_mouse_position()
                
                if current_pos != (0, 0):
                    # Mouse movement detection
                    if self.last_position:
                        dx = abs(current_pos[0] - self.last_position[0])
                        dy = abs(current_pos[1] - self.last_position[1])
                        
                        if dx > 15 or dy > 15:
                            interaction = {
                                'type': 'mouse_move',
                                'timestamp': self._get_relative_timestamp(),
                                'datetime': datetime.now().isoformat(),
                                'position': {'x': current_pos[0], 'y': current_pos[1]},
                                'movement': {'dx': dx, 'dy': dy},
                                'source': 'full_comprehensive_mouse'
                            }
                            
                            # Add comprehensive UI context
                            interaction['ui_context'] = self._capture_full_ui_context(current_pos[0], current_pos[1])
                            
                            self._safe_log_interaction(interaction)
                    
                    # Click detection
                    if (current_time - self.last_click_check) > 0.05:
                        self._safe_check_for_clicks(current_pos)
                        self.last_click_check = current_time
                    
                    # Comprehensive UI snapshots
                    if (current_time - self.last_ui_capture) > 2.0:  # Every 2 seconds
                        interaction = {
                            'type': 'full_ui_snapshot',
                            'timestamp': self._get_relative_timestamp(),
                            'datetime': datetime.now().isoformat(),
                            'position': {'x': current_pos[0], 'y': current_pos[1]},
                            'source': 'full_comprehensive_mouse'
                        }
                        
                        interaction['ui_context'] = self._capture_full_ui_context(current_pos[0], current_pos[1])
                        self._safe_log_interaction(interaction)
                        self.last_ui_capture = current_time
                    
                    self.last_position = current_pos
                
                sample_count += 1
                time.sleep(0.1)  # 10 FPS
                
            except Exception as e:
                print(f"⚠️ Mouse tracking error: {e}")
                time.sleep(0.5)
        
        print(f"🛑 Full comprehensive mouse tracking stopped")
    
    def _get_safe_mouse_position(self):
        """Get mouse position safely"""
        try:
            if PLATFORM == "Darwin":
                from Cocoa import NSEvent
                from AppKit import NSScreen
                point = NSEvent.mouseLocation()
                screen_height = NSScreen.mainScreen().frame().size.height
                return (int(point.x), int(screen_height - point.y))
            else:
                import pyautogui
                return pyautogui.position()
        except:
            return (0, 0)
    
    def _safe_check_for_clicks(self, current_pos):
        """Safe click detection"""
        try:
            if PLATFORM == "Darwin":
                from Cocoa import NSEvent
                current_mouse_down = NSEvent.pressedMouseButtons()
                
                if current_mouse_down > 0 and not self.click_state:
                    self.click_state = True
                    interaction = {
                        'type': 'mouse_press',
                        'timestamp': self._get_relative_timestamp(),
                        'datetime': datetime.now().isoformat(),
                        'position': {'x': current_pos[0], 'y': current_pos[1]},
                        'button': 'left',
                        'source': 'full_comprehensive_click'
                    }
                    
                    interaction['ui_context'] = self._capture_full_ui_context(current_pos[0], current_pos[1])
                    self._safe_log_interaction(interaction)
                    
                elif current_mouse_down == 0 and self.click_state:
                    self.click_state = False
                    interaction = {
                        'type': 'mouse_release',
                        'timestamp': self._get_relative_timestamp(),
                        'datetime': datetime.now().isoformat(),
                        'position': {'x': current_pos[0], 'y': current_pos[1]},
                        'button': 'left',
                        'source': 'full_comprehensive_click'
                    }
                    
                    interaction['ui_context'] = self._capture_full_ui_context(current_pos[0], current_pos[1])
                    self._safe_log_interaction(interaction)
        except:
            pass
    
    def _capture_full_ui_context(self, x, y):
        """Capture full comprehensive UI context"""
        ui_context = {
            'app_context': self._get_safe_app_context(),
            'window_context': self._get_safe_window_context(),
            'accessibility': None,
            'ui_tree': None,
            'keyboard_state': self._get_keyboard_state()
        }
        
        if self.inspector:
            try:
                accessibility_info = self.inspector.get_element_at_point(x, y)
                if accessibility_info and not accessibility_info.get('error'):
                    ui_context['accessibility'] = accessibility_info
                    ui_context['ui_tree'] = self._extract_full_ui_tree(accessibility_info)
            except Exception as e:
                ui_context['accessibility_error'] = str(e)
        
        return ui_context
    
    def _extract_full_ui_tree(self, accessibility_info):
        """Extract comprehensive UI tree"""
        try:
            accessibility_data = accessibility_info.get('accessibility', {})
            
            ui_tree = {
                'current_element': {
                    'role': self._safe_get_value(accessibility_data, 'AXRole'),
                    'role_description': self._safe_get_value(accessibility_data, 'AXRoleDescription'),
                    'title': self._safe_get_value(accessibility_data, 'AXTitle'),
                    'description': self._safe_get_value(accessibility_data, 'AXDescription'),
                    'value': self._safe_get_value(accessibility_data, 'AXValue'),
                    'identifier': self._safe_get_value(accessibility_data, 'AXIdentifier'),
                    'help': self._safe_get_value(accessibility_data, 'AXHelp'),
                    'placeholder': self._safe_get_value(accessibility_data, 'AXPlaceholderValue'),
                    'position': self._safe_get_value(accessibility_data, 'AXPosition'),
                    'size': self._safe_get_value(accessibility_data, 'AXSize'),
                    'enabled': self._safe_get_value(accessibility_data, 'AXEnabled'),
                    'focused': self._safe_get_value(accessibility_data, 'AXFocused'),
                    'selected': self._safe_get_value(accessibility_data, 'AXSelected')
                },
                'selectors': accessibility_info.get('selector_suggestions', []),
                'interaction_hints': self._generate_interaction_hints(accessibility_data),
                'element_hierarchy': self._build_element_hierarchy(accessibility_data)
            }
            
            return ui_tree
        except Exception as e:
            return {'error': f'Full UI tree extraction failed: {e}'}
    
    def _safe_get_value(self, data, key, default=''):
        """Safely get value from data"""
        try:
            value = data.get(key, default)
            if value and not isinstance(value, (str, int, float, bool, list, dict)):
                return str(value)
            return value
        except:
            return default
    
    def _build_element_hierarchy(self, accessibility_data):
        """Build element hierarchy"""
        try:
            return {
                'parent': str(self._safe_get_value(accessibility_data, 'AXParent')),
                'children_count': len(self._safe_get_value(accessibility_data, 'AXChildren', [])),
                'window': str(self._safe_get_value(accessibility_data, 'AXWindow'))
            }
        except:
            return {'error': 'Hierarchy extraction failed'}
    
    def _generate_interaction_hints(self, accessibility_data):
        """Generate interaction hints"""
        try:
            hints = []
            role = self._safe_get_value(accessibility_data, 'AXRole')
            enabled = self._safe_get_value(accessibility_data, 'AXEnabled')
            
            if role == 'AXButton' and enabled:
                hints.append('clickable_button')
            elif role == 'AXTextField':
                hints.append('text_input')
            elif role == 'AXLink':
                hints.append('clickable_link')
            elif 'PopUp' in role:
                hints.append('dropdown_menu')
            elif 'Menu' in role:
                hints.append('menu_item')
            
            return hints
        except:
            return []
    
    def _get_keyboard_state(self):
        """Get current keyboard state"""
        try:
            if APPKIT_AVAILABLE:
                modifiers = NSEvent.modifierFlags()
                return {
                    'active_modifiers': self._decode_modifiers(modifiers),
                    'recent_activity': {
                        'clipboard_changes': self.activity_indicators.get('clipboard_changes', 0),
                        'app_switches': self.activity_indicators.get('app_switches', 0),
                        'modifier_presses': self.activity_indicators.get('modifier_presses', 0)
                    }
                }
        except:
            pass
        return {'error': 'Keyboard state unavailable'}
    
    # Keyboard monitoring methods (from hybrid approach)
    def _get_clipboard(self):
        """Get clipboard content"""
        try:
            pb = NSPasteboard.generalPasteboard()
            return pb.stringForType_("public.utf8-plain-text") or ""
        except:
            return ""
    
    def _get_current_app(self):
        """Get current app"""
        try:
            workspace = NSWorkspace.sharedWorkspace()
            active_app = workspace.activeApplication()
            return active_app.get('NSApplicationName', 'Unknown')
        except:
            return "Unknown"
    
    def _clipboard_monitor(self):
        """Monitor clipboard changes"""
        while self.logging:
            try:
                current_clipboard = self._get_clipboard()
                
                if current_clipboard != self.last_clipboard and current_clipboard:
                    self._log_keyboard_event({
                        'type': 'clipboard_activity',
                        'activity': 'copy_paste',
                        'clipboard_length': len(current_clipboard),
                        'clipboard_preview': self._safe_preview(current_clipboard),
                        'inferred_action': 'Cmd+C or Cmd+V'
                    })
                    
                    self.activity_indicators['clipboard_changes'] += 1
                    self.last_clipboard = current_clipboard
                
                time.sleep(0.2)
            except:
                time.sleep(1)
    
    def _app_focus_monitor(self):
        """Monitor app focus changes"""
        while self.logging:
            try:
                current_app = self._get_current_app()
                
                if current_app != self.last_app:
                    self._log_keyboard_event({
                        'type': 'app_switch',
                        'from_app': self.last_app,
                        'to_app': current_app,
                        'inferred_action': 'Cmd+Tab or mouse click'
                    })
                    
                    self.activity_indicators['app_switches'] += 1
                    self.last_app = current_app
                
                time.sleep(0.5)
            except:
                time.sleep(1)
    
    def _modifier_monitor(self):
        """Monitor modifier keys"""
        while self.logging:
            try:
                current_modifiers = NSEvent.modifierFlags()
                
                if current_modifiers != self.last_modifier_state:
                    active_modifiers = self._decode_modifiers(current_modifiers)
                    previous_modifiers = self._decode_modifiers(self.last_modifier_state)
                    
                    pressed = list(set(active_modifiers) - set(previous_modifiers))
                    released = list(set(previous_modifiers) - set(active_modifiers))
                    
                    if pressed or released:
                        self._log_keyboard_event({
                            'type': 'modifier_change',
                            'pressed': pressed,
                            'released': released,
                            'active_modifiers': active_modifiers,
                            'inferred_action': f"Modifier keys: {'+'.join(active_modifiers) if active_modifiers else 'released'}"
                        })
                        
                        self.activity_indicators['modifier_presses'] += 1
                    
                    self.last_modifier_state = current_modifiers
                
                time.sleep(0.05)
            except:
                time.sleep(1)
    
    def _typing_activity_monitor(self):
        """Monitor typing activity"""
        last_activity_check = 0
        
        while self.logging:
            try:
                current_time = time.time()
                
                if (current_time - last_activity_check) > 1.0:
                    total_activity = sum(self.activity_indicators.values())
                    
                    if total_activity > 0:
                        activity_type = 'keyboard_activity'
                        if self.activity_indicators['clipboard_changes'] > 0:
                            activity_type = 'copy_paste_activity'
                        elif self.activity_indicators['modifier_presses'] > 3:
                            activity_type = 'keyboard_shortcuts'
                        elif self.activity_indicators['app_switches'] > 0:
                            activity_type = 'navigation_activity'
                        
                        self._log_keyboard_event({
                            'type': 'typing_activity_summary',
                            'activity_type': activity_type,
                            'activity_count': total_activity,
                            'indicators': self.activity_indicators.copy(),
                            'inferred_action': f'User {activity_type} detected'
                        })
                        
                        # Reset counters
                        self.activity_indicators = {k: 0 for k in self.activity_indicators}
                    
                    last_activity_check = current_time
                
                time.sleep(0.1)
            except:
                time.sleep(1)
    
    def _text_field_monitor(self):
        """Monitor text field changes and typing patterns"""
        last_focused_element = None
        last_text_content = ""
        
        while self.logging:
            try:
                if self.inspector:
                    # Get currently focused element
                    current_pos = self._get_safe_mouse_position()
                    if current_pos != (0, 0):
                        try:
                            element_info = self.inspector.get_element_at_point(current_pos[0], current_pos[1])
                            if element_info and not element_info.get('error'):
                                accessibility_data = element_info.get('accessibility', {})
                                role = self._safe_get_value(accessibility_data, 'AXRole')
                                focused = self._safe_get_value(accessibility_data, 'AXFocused')
                                value = self._safe_get_value(accessibility_data, 'AXValue')
                                
                                # Check if this is a text input field that's focused
                                if focused and role in ['AXTextField', 'AXTextArea', 'AXWebArea'] and value:
                                    current_text = str(value)
                                    
                                    # Detect text changes (typing)
                                    if current_text != last_text_content and last_text_content:
                                        text_diff = self._calculate_text_diff(last_text_content, current_text)
                                        
                                        if text_diff:
                                            self._log_keyboard_event({
                                                'type': 'text_field_change',
                                                'field_role': role,
                                                'field_title': self._safe_get_value(accessibility_data, 'AXTitle'),
                                                'previous_length': len(last_text_content),
                                                'new_length': len(current_text),
                                                'text_diff': text_diff,
                                                'inferred_action': f'Typed text in {role}'
                                            })
                                    
                                    last_text_content = current_text
                                    last_focused_element = element_info
                        except:
                            pass
                
                time.sleep(0.3)
            except:
                time.sleep(1)
    
    def _global_key_event_monitor(self):
        """Monitor global key events using Core Graphics event tap"""
        try:
            import Quartz
            from Quartz import (
                CGEventTapCreate, CGEventTapEnable, CGEventMaskBit, 
                kCGEventKeyDown, kCGEventKeyUp, kCGEventFlagsChanged,
                kCGHIDEventTap, kCGHeadInsertEventTap, kCGEventTapOptionListenOnly,
                CFRunLoopGetCurrent, CFRunLoopAddSource, kCFRunLoopDefaultMode,
                CGEventGetIntegerValueField, kCGKeyboardEventKeycode,
                CFMachPortCreateRunLoopSource, CFMachPortInvalidate
            )
            from Cocoa import NSRunLoop, NSDefaultRunLoopMode
            import threading
            
            print("🔑 Starting Core Graphics key event monitoring...")
            
            def key_event_callback(proxy, event_type, event, refcon):
                try:
                    if not self.logging:
                        return event
                    
                    timestamp = time.time()
                    key_code = int(CGEventGetIntegerValueField(event, kCGKeyboardEventKeycode))
                    key_name = self._key_code_to_name(key_code)
                    
                    # Debug: Print captured keystroke
                    print(f"🔑 CAPTURED: {event_type} -> Key Code: {key_code}, Key Name: {key_name}")
                    
                    # Key press events
                    if event_type == kCGEventKeyDown:
                        self._log_keyboard_event({
                            'type': 'key_press',
                            'key_code': key_code,
                            'key_name': key_name,
                            'is_special_key': key_name in ['Return', 'Tab', 'Delete', 'Escape', 'Space'],
                            'is_character': key_name.isalnum() or key_name in ['.', ',', '!', '?', ';', ':', "'", '"'],
                            'inferred_action': f'Pressed {key_name} key',
                            'capture_method': 'core_graphics_event_tap'
                        })
                        
                        # Track typing patterns
                        self._update_typing_patterns(key_name, timestamp)
                        
                        # Log character typing specifically
                        if key_name.isalnum() or key_name in ['.', ',', '!', '?', ';', ':', "'", '"', ' ']:
                            self._log_keyboard_event({
                                'type': 'character_typed',
                                'character': key_name if len(key_name) == 1 else '[SPECIAL]',
                                'key_name': key_name,
                                'inferred_action': f'Typed character: {key_name}'
                            })
                    
                    elif event_type == kCGEventKeyUp:
                        # Only log key releases for special keys to reduce noise
                        if key_name in ['Return', 'Tab', 'Delete', 'Escape', 'Command', 'Shift', 'Control', 'Option']:
                            self._log_keyboard_event({
                                'type': 'key_release',
                                'key_code': key_code,
                                'key_name': key_name,
                                'inferred_action': f'Released {key_name} key',
                                'capture_method': 'core_graphics_event_tap'
                            })
                    
                    return event
                except Exception as e:
                    print(f"Key event callback error: {e}")
                    return event
            
            # Create event tap for key events - FIXED: Use proper event mask
            event_mask = (
                CGEventMaskBit(kCGEventKeyDown) |
                CGEventMaskBit(kCGEventKeyUp) |
                CGEventMaskBit(kCGEventFlagsChanged)
            )
            
            try:
                # Try to create event tap - FIXED: Added missing CGEventTapPlacement parameter
                event_tap = CGEventTapCreate(
                    kCGHIDEventTap,                    # Tap location (CGEventTapLocation)
                    kCGHeadInsertEventTap,             # Placement (CGEventTapPlacement) - FIXED: This was missing!
                    kCGEventTapOptionListenOnly,       # Options (CGEventTapOptions) - Use listen-only for safety
                    event_mask,                        # Event mask
                    key_event_callback,                # Callback
                    None                               # User data
                )
                
                if event_tap is None:
                    print("❌ Failed to create event tap - accessibility permissions needed")
                    print("💡 Enable 'Accessibility' permission for Terminal/Python in System Preferences")
                    # Fall back to safe monitoring
                    self._safe_key_monitoring()
                    return
                
                # Create run loop source and add to current run loop
                run_loop_source = CFMachPortCreateRunLoopSource(None, event_tap, 0)
                run_loop = CFRunLoopGetCurrent()
                CFRunLoopAddSource(run_loop, run_loop_source, kCFRunLoopDefaultMode)
                
                # Enable the event tap
                CGEventTapEnable(event_tap, True)
                
                print("✅ Core Graphics event tap enabled - capturing all keystrokes")
                
                # Run the event loop - FIXED: Better event loop management
                print("🔄 Starting Core Graphics event loop...")
                while self.logging:
                    try:
                        # Run the event loop for a short time
                        from Cocoa import NSDate
                        run_until = NSDate.dateWithTimeIntervalSinceNow_(0.1)
                        NSRunLoop.currentRunLoop().runMode_beforeDate_(NSDefaultRunLoopMode, run_until)
                        
                        # Also run CFRunLoop to ensure events are processed
                        from Quartz import CFRunLoopRunInMode, kCFRunLoopDefaultMode
                        CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.1, False)
                        
                    except Exception as e:
                        print(f"Event loop error: {e}")
                        time.sleep(0.1)
                
                # Clean up
                CGEventTapEnable(event_tap, False)
                print("🛑 Core Graphics event tap disabled")
                
            except Exception as e:
                print(f"❌ Event tap creation failed: {e}")
                print("💡 This usually means accessibility permissions are not granted")
                # Fall back to safe monitoring
                self._safe_key_monitoring()
                
        except ImportError as e:
            print(f"❌ Quartz not available: {e}")
            # Fall back to safe monitoring
            self._safe_key_monitoring()
    
    def _key_code_to_name(self, key_code):
        """Convert macOS key code to readable name"""
        # FIXED: Added comprehensive key code mapping
        key_map = {
            0: 'a', 1: 's', 2: 'd', 3: 'f', 4: 'h', 5: 'g', 6: 'z', 7: 'x', 8: 'c', 9: 'v',
            10: '§', 11: 'b', 12: 'q', 13: 'w', 14: 'e', 15: 'r', 16: 'y', 17: 't',
            18: '1', 19: '2', 20: '3', 21: '4', 22: '6', 23: '5', 24: '=', 25: '9',
            26: '7', 27: '-', 28: '8', 29: '0', 30: ']', 31: 'o', 32: 'u', 33: '[',
            34: 'i', 35: 'p', 36: 'Return', 37: 'l', 38: 'j', 39: "'", 40: 'k', 41: ';',
            42: '\\', 43: ',', 44: '/', 45: 'n', 46: 'm', 47: '.', 48: 'Tab',
            49: 'Space', 50: '`', 51: 'Delete', 52: 'Enter', 53: 'Escape',
            54: 'RightCommand', 55: 'Command', 56: 'Shift', 57: 'CapsLock',
            58: 'Option', 59: 'Control', 60: 'RightShift', 61: 'RightOption',
            62: 'RightControl', 63: 'Function', 64: 'F17', 65: 'KeypadDecimal',
            66: 'KeypadMultiply', 67: 'KeypadPlus', 68: 'KeypadClear', 69: 'VolumeUp',
            70: 'VolumeDown', 71: 'Mute', 72: 'KeypadDivide', 73: 'KeypadEnter',
            74: 'KeypadMinus', 75: 'F18', 76: 'F19', 77: 'KeypadEquals',
            78: 'Keypad0', 79: 'Keypad1', 80: 'Keypad2', 81: 'Keypad3', 82: 'Keypad4',
            83: 'Keypad5', 84: 'Keypad6', 85: 'Keypad7', 86: 'F20', 87: 'Keypad8',
            88: 'Keypad9', 89: 'Yen', 90: 'Underscore', 91: 'KeypadComma',
            92: 'F5', 93: 'F6', 94: 'F7', 95: 'F3', 96: 'F8', 97: 'F9',
            98: 'Eisu', 99: 'F11', 100: 'Kana', 101: 'F13', 102: 'F16', 103: 'F14',
            104: 'F10', 105: 'F12', 106: 'F15', 107: 'Help', 108: 'Home',
            109: 'PageUp', 110: 'ForwardDelete', 111: 'F4', 112: 'End', 113: 'F2',
            114: 'PageDown', 115: 'F1', 116: 'LeftArrow', 117: 'RightArrow',
            118: 'DownArrow', 119: 'UpArrow'
        }
        
        return key_map.get(key_code, f'Unknown({key_code})')
    
    def _safe_key_monitoring(self):
        """Safe fallback key monitoring using NSEvent polling"""
        print("🔄 Falling back to safe key monitoring...")
        
        while self.logging:
            try:
                from Cocoa import NSEvent
                
                # Sample current key states
                current_flags = NSEvent.modifierFlags()
                if current_flags != getattr(self, '_last_sampled_flags', 0):
                    self._last_sampled_flags = current_flags
                    
                    # Log modifier changes
                    active_mods = self._decode_modifiers(current_flags)
                    if active_mods:
                        self._log_keyboard_event({
                            'type': 'modifier_state_change',
                            'active_modifiers': active_mods,
                            'inferred_action': f'Modifier keys: {"+".join(active_mods)}',
                            'capture_method': 'safe_polling'
                        })
                
                time.sleep(0.1)
            except:
                time.sleep(1)
    
    def _typing_pattern_detector(self):
        """Detect typing patterns and sessions"""
        while self.logging:
            try:
                current_time = time.time()
                
                # Analyze typing session patterns
                if hasattr(self, 'consecutive_key_count') and self.consecutive_key_count > 0:
                    # Check if typing session is ongoing
                    time_since_last_key = current_time - self.last_key_time
                    
                    if time_since_last_key > 2.0 and self.consecutive_key_count > 3:
                        # End of typing session
                        session_duration = current_time - (self.typing_session_start or current_time)
                        
                        self._log_keyboard_event({
                            'type': 'typing_session_end',
                            'session_duration': session_duration,
                            'key_count': self.consecutive_key_count,
                            'backspace_count': getattr(self, 'backspace_count', 0),
                            'enter_count': getattr(self, 'enter_count', 0),
                            'tab_count': getattr(self, 'tab_count', 0),
                            'typing_speed': self.consecutive_key_count / max(session_duration, 1),
                            'inferred_action': f'Completed typing session ({self.consecutive_key_count} keys)'
                        })
                        
                        # Reset session counters
                        self.consecutive_key_count = 0
                        self.backspace_count = 0
                        self.enter_count = 0
                        self.tab_count = 0
                        self.typing_session_start = None
                
                time.sleep(0.5)
            except:
                time.sleep(1)
    
    def _decode_modifiers(self, modifier_flags):
        """Decode modifier flags"""
        modifiers = []
        
        if modifier_flags & (1 << 17):
            modifiers.append('shift')
        if modifier_flags & (1 << 18):
            modifiers.append('control')
        if modifier_flags & (1 << 19):
            modifiers.append('option')
        if modifier_flags & (1 << 20):
            modifiers.append('command')
        
        return modifiers
    
    def _safe_preview(self, text, max_length=50):
        """Create safe text preview"""
        if not text:
            return ""
        
        if any(keyword in text.lower() for keyword in ['password', 'secret', 'token', 'key']):
            return "[SENSITIVE_CONTENT_MASKED]"
        
        preview = text.replace('\n', ' ').replace('\t', ' ')
        if len(preview) > max_length:
            preview = preview[:max_length] + '...'
        
        return preview
    
    def _calculate_text_diff(self, old_text, new_text):
        """Calculate difference between text states"""
        try:
            if not old_text or not new_text:
                return {'type': 'text_change', 'description': 'Text added/removed'}
            
            old_len = len(old_text)
            new_len = len(new_text)
            
            # Simple diff analysis
            if new_len > old_len:
                # Text was added
                if new_text.startswith(old_text):
                    added_text = new_text[old_len:]
                    return {
                        'type': 'text_added',
                        'added_text': self._safe_preview(added_text, 30),
                        'length_change': new_len - old_len,
                        'description': f'Added {len(added_text)} characters'
                    }
                else:
                    return {
                        'type': 'text_modified',
                        'length_change': new_len - old_len,
                        'description': 'Text was modified/inserted'
                    }
            elif new_len < old_len:
                # Text was removed
                return {
                    'type': 'text_removed',
                    'length_change': new_len - old_len,
                    'description': f'Removed {old_len - new_len} characters'
                }
            else:
                # Same length, text was modified
                return {
                    'type': 'text_replaced',
                    'length_change': 0,
                    'description': 'Text was replaced'
                }
        except:
            return {'type': 'text_change', 'description': 'Text changed'}
    
    def _key_code_to_name(self, key_code):
        """Convert macOS key code to key name"""
        key_map = {
            0: 'A', 1: 'S', 2: 'D', 3: 'F', 4: 'H', 5: 'G', 6: 'Z', 7: 'X', 8: 'C', 9: 'V',
            11: 'B', 12: 'Q', 13: 'W', 14: 'E', 15: 'R', 16: 'Y', 17: 'T', 18: '1', 19: '2',
            20: '3', 21: '4', 22: '6', 23: '5', 24: '=', 25: '9', 26: '7', 27: '-', 28: '8',
            29: '0', 30: ']', 31: 'O', 32: 'U', 33: '[', 34: 'I', 35: 'P', 36: 'Return',
            37: 'L', 38: 'J', 39: '\'', 40: 'K', 41: ';', 42: '\\', 43: ',', 44: '/', 45: 'N',
            46: 'M', 47: '.', 48: 'Tab', 49: 'Space', 50: '`', 51: 'Delete', 53: 'Escape',
            55: 'Command', 56: 'Shift', 57: 'CapsLock', 58: 'Option', 59: 'Control',
            60: 'RightShift', 61: 'RightOption', 62: 'RightControl', 63: 'Function',
            64: 'F17', 65: 'KeypadDecimal', 67: 'KeypadMultiply', 69: 'KeypadPlus',
            71: 'KeypadClear', 75: 'KeypadDivide', 76: 'KeypadEnter', 78: 'KeypadMinus',
            81: 'KeypadEquals', 82: 'Keypad0', 83: 'Keypad1', 84: 'Keypad2', 85: 'Keypad3',
            86: 'Keypad4', 87: 'Keypad5', 88: 'Keypad6', 89: 'Keypad7', 91: 'Keypad8',
            92: 'Keypad9', 96: 'F5', 97: 'F6', 98: 'F7', 99: 'F3', 100: 'F8', 101: 'F9',
            103: 'F11', 105: 'F13', 106: 'F16', 107: 'F14', 109: 'F10', 111: 'F12',
            113: 'F15', 114: 'Help', 115: 'Home', 116: 'PageUp', 117: 'ForwardDelete',
            118: 'F4', 119: 'End', 120: 'F2', 121: 'PageDown', 122: 'F1', 123: 'LeftArrow',
            124: 'RightArrow', 125: 'DownArrow', 126: 'UpArrow'
        }
        return key_map.get(key_code, f'Key{key_code}')
    
    def _update_typing_patterns(self, key_name, timestamp):
        """Update typing pattern tracking"""
        try:
            current_time = timestamp
            
            # Initialize typing session if needed
            if self.typing_session_start is None:
                self.typing_session_start = current_time
            
            # Track consecutive keys
            time_since_last = current_time - self.last_key_time
            if time_since_last < 2.0:  # Keys within 2 seconds are part of same session
                self.consecutive_key_count += 1
            else:
                # New typing session
                self.consecutive_key_count = 1
                self.typing_session_start = current_time
            
            # Track special keys
            if key_name == 'Delete':
                self.backspace_count += 1
            elif key_name == 'Return':
                self.enter_count += 1
            elif key_name == 'Tab':
                self.tab_count += 1
            
            self.last_key_time = current_time
            
        except Exception as e:
            pass
    
    def _applescript_key_monitor(self):
        """Alternative keystroke monitoring using AppleScript"""
        try:
            import subprocess
            
            print("🍎 Starting AppleScript key monitoring...")
            
            last_focused_app = ""
            
            while self.logging:
                try:
                    # Get current focused application and detect rapid changes (typing indicators)
                    current_app = self._get_current_app()
                    current_time = time.time()
                    
                    # Enhanced typing detection through system behavior
                    if current_app != last_focused_app:
                        # Rapid app switching might indicate Cmd+Tab usage
                        if current_time - getattr(self, '_last_app_switch_time', 0) < 1.0:
                            self._log_keyboard_event({
                                'type': 'rapid_app_switch',
                                'from_app': last_focused_app,
                                'to_app': current_app,
                                'inferred_action': 'Rapid app switching (possibly Cmd+Tab)',
                                'capture_method': 'applescript_monitoring'
                            })
                        self._last_app_switch_time = current_time
                        last_focused_app = current_app
                    
                    # Check for system-level typing indicators using AppleScript
                    try:
                        # Detect frontmost application changes that indicate user activity
                        result = subprocess.run([
                            'osascript', '-e',
                            'tell application "System Events" to get name of first application process whose frontmost is true'
                        ], capture_output=True, text=True, timeout=1)
                        
                        if result.returncode == 0:
                            frontmost_app = result.stdout.strip().strip('"')
                            
                            if frontmost_app != getattr(self, '_last_frontmost_app', ''):
                                self._log_keyboard_event({
                                    'type': 'frontmost_app_change',
                                    'new_frontmost_app': frontmost_app,
                                    'inferred_action': f'Switched to {frontmost_app}',
                                    'capture_method': 'applescript_frontmost_detection'
                                })
                                self._last_frontmost_app = frontmost_app
                    
                    except subprocess.TimeoutExpired:
                        pass
                    except Exception:
                        pass
                    
                    # Detect typing patterns through enhanced system monitoring
                    if hasattr(self, 'consecutive_key_count') and self.consecutive_key_count > 0:
                        time_since_last = current_time - self.last_key_time
                        if time_since_last < 0.5:  # Very recent activity
                            self._log_keyboard_event({
                                'type': 'active_typing_detected',
                                'typing_intensity': min(self.consecutive_key_count, 10),
                                'time_since_last_key': time_since_last,
                                'inferred_action': 'Active typing session in progress',
                                'capture_method': 'applescript_analysis'
                            })
                    
                    time.sleep(0.5)
                    
                except Exception:
                    time.sleep(1)
                    
        except Exception as e:
            print(f"AppleScript monitoring error: {e}")
            while self.logging:
                time.sleep(1)
    
    def _log_keyboard_event(self, event_data):
        """Log keyboard event"""
        try:
            event = {
                'timestamp': self._get_relative_timestamp(),
                'datetime': datetime.now().isoformat(),
                'source': 'full_comprehensive_keyboard',
                **event_data
            }
            
            self.keyboard_events.append(event)
            
            if event_data['type'] in ['clipboard_activity', 'app_switch']:
                print(f"⌨️ Keyboard activity: {event_data['type']} - {event_data.get('inferred_action', '')}")
                
        except Exception as e:
            print(f"Keyboard event logging error: {e}")
    
    def _get_safe_app_context(self):
        """Get app context safely"""
        try:
            if PLATFORM == "Darwin":
                workspace = NSWorkspace.sharedWorkspace()
                active_app = workspace.activeApplication()
                return {
                    'name': active_app.get('NSApplicationName', 'Unknown'),
                    'bundle_id': active_app.get('NSApplicationBundleIdentifier', 'Unknown'),
                    'pid': active_app.get('NSApplicationProcessIdentifier', 0)
                }
        except:
            pass
        return {'name': 'Unknown', 'bundle_id': 'Unknown', 'pid': 0}
    
    def _get_safe_window_context(self):
        """Get window context safely"""
        try:
            if PLATFORM == "Darwin":
                from AppKit import NSWorkspace
                from Quartz import CGWindowListCopyWindowInfo, kCGWindowListOptionOnScreenOnly, kCGNullWindowID
                
                workspace = NSWorkspace.sharedWorkspace()
                active_app = workspace.activeApplication()
                
                return {
                    'active_app': {
                        'name': active_app.get('NSApplicationName', 'Unknown'),
                        'bundle_id': active_app.get('NSApplicationBundleIdentifier', 'Unknown'),
                        'pid': active_app.get('NSApplicationProcessIdentifier', 0)
                    }
                }
        except:
            pass
        return {'error': 'Window context unavailable'}
    
    def _get_relative_timestamp(self):
        """Get relative timestamp"""
        try:
            return time.time() - self.start_time if self.start_time else 0
        except:
            return 0
    
    def _safe_log_interaction(self, interaction):
        """Log interaction safely"""
        try:
            self.interactions.append(interaction)
            
            if len(self.interactions) % 25 == 0:
                print(f"📝 Logged {len(self.interactions)} full comprehensive interactions...")
                
        except Exception as e:
            print(f"⚠️ Interaction log error: {e}")
    
    def stop_logging(self):
        """Stop full comprehensive logging"""
        if not self.logging:
            return
        
        self.logging = False
        
        # Stop mouse thread
        if self.mouse_thread:
            self.mouse_thread.join(timeout=3)
        
        # Stop keyboard threads
        for thread in self.keyboard_threads:
            thread.join(timeout=1)
        
        print(f"✅ Full comprehensive interaction logging stopped")
        print(f"   Mouse/UI interactions: {len(self.interactions)}")
        print(f"   Keyboard events: {len(self.keyboard_events)}")
    
    def _serialize_for_json(self, obj):
        """Convert objects to JSON-serializable format"""
        if obj is None:
            return None
        elif isinstance(obj, (str, int, float, bool)):
            return obj
        elif isinstance(obj, dict):
            return {k: self._serialize_for_json(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [self._serialize_for_json(item) for item in obj]
        else:
            return str(obj)
    
    def save_interactions(self, output_path):
        """Save all comprehensive interaction data"""
        try:
            # Serialize all data
            serialized_interactions = [self._serialize_for_json(i) for i in self.interactions]
            serialized_keyboard_events = [self._serialize_for_json(e) for e in self.keyboard_events]
            
            comprehensive_data = {
                'session_info': {
                    'platform': PLATFORM,
                    'start_time': datetime.now().isoformat(),
                    'duration': self._get_relative_timestamp(),
                    'interaction_count': len(serialized_interactions),
                    'keyboard_event_count': len(serialized_keyboard_events),
                    'capture_method': 'full_comprehensive_hybrid',
                    'features': {
                        'mouse_tracking': True,
                        'click_detection': True,
                        'hybrid_keyboard_logging': True,
                        'ui_tree_capture': True,
                        'accessibility_inspection': ACCESSIBILITY_AVAILABLE,
                        'app_context': True,
                        'window_context': True,
                        'clipboard_monitoring': True,
                        'modifier_key_tracking': True,
                        'typing_activity_detection': True,
                        'comprehensive_logging': True,
                        'crash_protection': True
                    }
                },
                'mouse_interactions': serialized_interactions,
                'keyboard_events': serialized_keyboard_events
            }
            
            with open(output_path, 'w') as f:
                json.dump(comprehensive_data, f, indent=2)
            
            print(f"💾 Full comprehensive interactions saved: {output_path}")
            
            # Print breakdown
            interaction_types = {}
            for interaction in serialized_interactions:
                itype = interaction.get('type', 'unknown')
                interaction_types[itype] = interaction_types.get(itype, 0) + 1
            
            keyboard_types = {}
            for event in serialized_keyboard_events:
                ktype = event.get('type', 'unknown')
                keyboard_types[ktype] = keyboard_types.get(ktype, 0) + 1
            
            print("📊 Full comprehensive interaction breakdown:")
            print("   Mouse/UI Interactions:")
            for itype, count in interaction_types.items():
                print(f"     {itype}: {count}")
            print("   Keyboard Events:")
            for ktype, count in keyboard_types.items():
                print(f"     {ktype}: {count}")
            
            return True
            
        except Exception as e:
            print(f"❌ Error saving comprehensive interactions: {e}")
            traceback.print_exc()
            return False

class FullComprehensiveRPARecorderApp:
    """Full comprehensive RPA Recorder GUI"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Enhanced RPA Recorder (Full Comprehensive)")
        self.root.geometry("700x600")
        
        # Initialize components
        self.accessibility_inspector = None
        if ACCESSIBILITY_AVAILABLE:
            try:
                self.accessibility_inspector = create_accessibility_inspector()
            except Exception as e:
                print(f"⚠️ Accessibility inspector failed: {e}")
        
        self.video_recorder = FullComprehensiveVideoRecorder()
        self.interaction_logger = FullComprehensiveInteractionLogger(self.accessibility_inspector)
        
        # State
        self.recording = False
        self.output_directory = str(Path.cwd() / "records")
        Path(self.output_directory).mkdir(exist_ok=True)
        
        self.setup_gui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
    
    def setup_gui(self):
        """Setup full comprehensive GUI"""
        # Title
        title_label = ttk.Label(self.root, text="Enhanced RPA Recorder", font=("Arial", 18, "bold"))
        title_label.pack(pady=10)
        
        subtitle_label = ttk.Label(self.root, text="Enhanced Keystroke Edition - Complete Typing Capture, Zero Crashes", 
                                 font=("Arial", 11), foreground="darkblue")
        subtitle_label.pack(pady=(0, 10))
        
        # Status
        self.status_var = tk.StringVar(value="Ready for full comprehensive recording")
        status_label = ttk.Label(self.root, textvariable=self.status_var, font=("Arial", 12, "bold"))
        status_label.pack(pady=5)
        
        # Output directory
        dir_frame = ttk.Frame(self.root)
        dir_frame.pack(fill=tk.X, padx=20, pady=10)
        
        ttk.Label(dir_frame, text="Output Directory:").pack(anchor=tk.W)
        self.dir_var = tk.StringVar(value=self.output_directory)
        dir_entry = ttk.Entry(dir_frame, textvariable=self.dir_var, state="readonly")
        dir_entry.pack(fill=tk.X, side=tk.LEFT, expand=True)
        ttk.Button(dir_frame, text="Browse", command=self.browse_directory).pack(side=tk.RIGHT, padx=(5, 0))
        
        # Recording options
        options_frame = ttk.LabelFrame(self.root, text="Full Comprehensive Recording Options")
        options_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Video options
        self.video_enabled = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame, text="Record Video", variable=self.video_enabled).pack(anchor=tk.W, pady=2)
        
        fps_frame = ttk.Frame(options_frame)
        fps_frame.pack(fill=tk.X, pady=2)
        ttk.Label(fps_frame, text="FPS:").pack(side=tk.LEFT)
        self.fps_var = tk.StringVar(value="15")
        ttk.Entry(fps_frame, textvariable=self.fps_var, width=5).pack(side=tk.LEFT, padx=(5, 0))
        
        # Audio options
        self.audio_enabled = tk.BooleanVar(value=AUDIO_AVAILABLE)
        audio_cb = ttk.Checkbutton(options_frame, text="Record Audio", variable=self.audio_enabled)
        audio_cb.pack(anchor=tk.W, pady=2)
        if not AUDIO_AVAILABLE:
            audio_cb.configure(state="disabled")
        
        # Comprehensive interaction options
        interaction_frame = ttk.LabelFrame(self.root, text="Full Comprehensive Interaction Logging")
        interaction_frame.pack(fill=tk.X, padx=20, pady=10)
        
        self.mouse_enabled = tk.BooleanVar(value=True)
        ttk.Checkbutton(interaction_frame, text="Track Mouse, Clicks & UI Context", 
                       variable=self.mouse_enabled).pack(anchor=tk.W, pady=2)
        
        self.keyboard_enabled = tk.BooleanVar(value=APPKIT_AVAILABLE)
        keyboard_cb = ttk.Checkbutton(interaction_frame, text="ENHANCED Keystroke Capture (Core Graphics + AppleScript)", variable=self.keyboard_enabled)
        keyboard_cb.pack(anchor=tk.W, pady=2)
        if not APPKIT_AVAILABLE:
            keyboard_cb.configure(state="disabled")
        
        self.ui_tree_enabled = tk.BooleanVar(value=ACCESSIBILITY_AVAILABLE)
        ui_tree_cb = ttk.Checkbutton(interaction_frame, text="Full UI Tree & Accessibility Context", variable=self.ui_tree_enabled)
        ui_tree_cb.pack(anchor=tk.W, pady=2)
        if not ACCESSIBILITY_AVAILABLE:
            ui_tree_cb.configure(state="disabled")
        
        # Comprehensive features
        features_frame = ttk.LabelFrame(self.root, text="Full Comprehensive Features")
        features_frame.pack(fill=tk.X, padx=20, pady=10)
        
        features_text = "✅ Video + Audio recording\n✅ Safe mouse & click detection\n✅ ENHANCED keyboard logging (actual keystrokes, text changes, typing patterns)\n✅ Text field monitoring & content tracking\n✅ Global key event monitoring\n✅ Full UI element tree capture\n✅ Accessibility hierarchy & selectors\n✅ App & window context tracking\n✅ Typing session analysis\n✅ Interaction hints generation\n✅ 100% crash protection"
        ttk.Label(features_frame, text=features_text, font=("Arial", 9), foreground="darkgreen").pack(pady=5)
        
        # Control buttons
        button_frame = ttk.Frame(self.root)
        button_frame.pack(pady=20)
        
        self.record_button = ttk.Button(button_frame, text="Start Full Comprehensive Recording", 
                                      command=self.toggle_recording, style="Accent.TButton")
        self.record_button.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(button_frame, text="Open Output Folder", command=self.open_output_folder).pack(side=tk.LEFT, padx=5)
        
        # Status display
        caps_text = f"Status: Video{'✅' if True else '❌'} Audio{'✅' if AUDIO_AVAILABLE else '❌'} Keyboard{'✅' if APPKIT_AVAILABLE else '❌'} UITree{'✅' if ACCESSIBILITY_AVAILABLE else '❌'} CrashProof🛡️"
        ttk.Label(self.root, text=caps_text, font=("Arial", 9), foreground="blue").pack(pady=(5, 10))
    
    def browse_directory(self):
        """Browse for output directory"""
        directory = filedialog.askdirectory(initialdir=self.output_directory)
        if directory:
            self.output_directory = directory
            self.dir_var.set(directory)
    
    def toggle_recording(self):
        """Toggle recording state"""
        if self.recording:
            self.stop_recording()
        else:
            self.start_recording()
    
    def start_recording(self):
        """Start full comprehensive recording"""
        try:
            if self.recording:
                return
            
            self.recording = True
            self.record_button.configure(text="Stop Recording")
            self.status_var.set("🔴 FULL COMPREHENSIVE RECORDING...")
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            base_path = Path(self.output_directory) / f"full_comprehensive_recording_{timestamp}"
            
            started_components = []
            
            # Start video recording
            if self.video_enabled.get():
                try:
                    fps = max(5, min(30, int(self.fps_var.get() or 15)))
                    video_path = str(base_path) + ".mp4"
                    record_audio = self.audio_enabled.get() and AUDIO_AVAILABLE
                    
                    success = self.video_recorder.start_recording(video_path, fps, record_audio)
                    if success:
                        if record_audio:
                            started_components.append("comprehensive-video+audio")
                        else:
                            started_components.append("comprehensive-video")
                except Exception as e:
                    print(f"❌ Video recording failed: {e}")
                    messagebox.showerror("Error", f"Video recording failed: {e}")
                    self.recording = False
                    self.record_button.configure(text="Start Full Comprehensive Recording")
                    self.status_var.set("Ready for full comprehensive recording")
                    return
            
            # Start full comprehensive interaction logging
            if self.mouse_enabled.get() or self.keyboard_enabled.get():
                try:
                    capture_keyboard = self.keyboard_enabled.get() and APPKIT_AVAILABLE
                    
                    success = self.interaction_logger.start_logging(capture_keyboard)
                    if success:
                        components = []
                        if self.mouse_enabled.get():
                            components.append("mouse+clicks+ui-tree")
                        if capture_keyboard:
                            components.append("hybrid-keyboard")
                        started_components.append(f"comprehensive-interactions({'+'.join(components)})")
                except Exception as e:
                    print(f"⚠️ Comprehensive interaction logging failed: {e}")
            
            if started_components:
                print(f"🎬 Full comprehensive recording started: {', '.join(started_components)}")
                messagebox.showinfo("Recording Started", 
                                  f"Full comprehensive recording started!\n\nComponents: {', '.join(started_components)}\n\nMaximum visibility for Gemini processing!")
            else:
                self.recording = False
                self.record_button.configure(text="Start Full Comprehensive Recording")
                self.status_var.set("Ready for full comprehensive recording")
                messagebox.showerror("Error", "No recording components could be started")
            
        except Exception as e:
            print(f"❌ Recording start failed: {e}")
            messagebox.showerror("Error", f"Failed to start recording: {e}")
            self.recording = False
            self.record_button.configure(text="Start Full Comprehensive Recording")
            self.status_var.set("Ready for full comprehensive recording")
    
    def stop_recording(self):
        """Stop full comprehensive recording"""
        try:
            if not self.recording:
                return
            
            self.recording = False
            self.record_button.configure(text="Start Full Comprehensive Recording")
            self.status_var.set("⏳ Saving comprehensive data...")
            
            stopped_components = []
            
            # Stop video recording
            try:
                self.video_recorder.stop_recording()
                stopped_components.append("comprehensive-video+audio")
            except Exception as e:
                print(f"⚠️ Error stopping video: {e}")
            
            # Stop comprehensive interaction logging and save
            try:
                self.interaction_logger.stop_logging()
                if len(self.interaction_logger.interactions) > 0 or len(self.interaction_logger.keyboard_events) > 0:
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    interaction_path = Path(self.output_directory) / f"full_comprehensive_interactions_{timestamp}.json"
                    success = self.interaction_logger.save_interactions(str(interaction_path))
                    if success:
                        stopped_components.append("comprehensive-interactions")
            except Exception as e:
                print(f"⚠️ Error saving comprehensive interactions: {e}")
            
            self.status_var.set("✅ Full comprehensive recording saved!")
            print(f"🛑 Full comprehensive recording completed: {', '.join(stopped_components)}")
            messagebox.showinfo("Recording Complete", 
                              f"Full comprehensive recording saved!\n\nComponents: {', '.join(stopped_components)}\n\nComplete workflow captured for Gemini processing!")
            
        except Exception as e:
            print(f"❌ Error stopping recording: {e}")
            self.status_var.set("❌ Error during stop")
            messagebox.showerror("Error", f"Error stopping recording: {e}")
    
    def open_output_folder(self):
        """Open output folder"""
        try:
            if PLATFORM == "Darwin":
                os.system(f'open "{self.output_directory}"')
            elif PLATFORM == "Windows":
                os.system(f'explorer "{self.output_directory}"')
            else:
                os.system(f'xdg-open "{self.output_directory}"')
        except Exception as e:
            print(f"Error opening folder: {e}")
    
    def on_closing(self):
        """Handle application closing"""
        try:
            if self.recording:
                if messagebox.askokcancel("Quit", "Full comprehensive recording in progress. Stop and quit?"):
                    self.stop_recording()
                    time.sleep(2)
                    self.root.destroy()
            else:
                self.root.destroy()
        except Exception as e:
            print(f"Error during closing: {e}")
            self.root.destroy()
    
    def run(self):
        """Run full comprehensive application"""
        try:
            self.root.mainloop()
        except Exception as e:
            print(f"GUI error: {e}")

def main():
    """Main entry point"""
    print("🚀 Starting Enhanced RPA Recorder (ENHANCED KEYSTROKE EDITION)...")
    print(f"Platform: {PLATFORM}")
    print(f"Audio Recording: {'✅' if AUDIO_AVAILABLE else '❌'}")
    print(f"Enhanced Keystroke Capture: {'✅' if APPKIT_AVAILABLE else '❌'}")
    print(f"UI Tree Capture: {'✅' if ACCESSIBILITY_AVAILABLE else '❌'}")
    print()
    print("🔑 KEYSTROKE CAPTURE METHODS:")
    print("   • Core Graphics Event Tap (captures every keypress)")
    print("   • Text Field Content Monitoring (tracks what was typed)")
    print("   • AppleScript System Monitoring (detects typing patterns)")
    print("   • Clipboard & App Focus Analysis (contextual typing)")
    print("   • Typing Session Analytics (speed, patterns, special keys)")
    print()
    print("🎯 Complete keystroke logging for Gemini processing")
    print("🛡️ Multi-method capture with crash protection")
    
    if not AUDIO_AVAILABLE:
        print("⚠️ Install pyaudio for audio recording: pip install pyaudio")
    
    try:
        app = FullComprehensiveRPARecorderApp()
        app.run()
    except KeyboardInterrupt:
        print("\n👋 Full Comprehensive RPA Recorder stopped by user")
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    main()