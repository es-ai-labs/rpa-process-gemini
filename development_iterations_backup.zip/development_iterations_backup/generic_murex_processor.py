#!/usr/bin/env python3
"""
Generic Murex Workflow Processor

A workflow-agnostic processor that captures ANY Murex process:
- No assumptions about specific workflows (bonds, trading, config, etc.)
- Focuses on UI interactions rather than business logic
- Generic field identification without hardcoded names
- Captures user actions mechanically for any Murex module
"""

import json
import base64
import requests
import os
from datetime import datetime
from typing import List, Dict
from simple_rpa_generator import SimpleRpaGenerator
from rpa_config import RpaConfig

class GenericMurexProcessor(SimpleRpaGenerator):
    """Generic processor for any Murex workflow"""
    
    def extract_interaction_sequence(self, json_path: str) -> str:
        """Extract interaction sequence without workflow assumptions"""
        
        with open(json_path, 'r') as f:
            data = json.load(f)
        
        session_info = data.get('session_info', {})
        duration = session_info.get('duration', 0)
        
        mouse_interactions = data.get('mouse_interactions', [])
        keyboard_events = data.get('keyboard_events', [])
        app_switches = data.get('app_switches', [])
        
        # Extract clicks from mouse press/release pairs
        clicks = []
        for i, interaction in enumerate(mouse_interactions):
            if interaction.get('type') == 'mouse_press' and interaction.get('button') == 'left':
                clicks.append({
                    'timestamp': interaction.get('timestamp', 0),
                    'position': interaction.get('position', {}),
                    'type': 'click'
                })
        
        # Extract typed text sequences
        typed_sequences = []
        current_text = ""
        sequence_start = None
        
        for event in keyboard_events:
            if event.get('type') == 'key_press' and event.get('is_character'):
                key = event.get('key_name', '')
                timestamp = event.get('timestamp', 0)
                
                if key == 'Return':
                    if current_text:
                        typed_sequences.append({
                            'timestamp': sequence_start,
                            'text': current_text,
                            'end_action': 'enter'
                        })
                        current_text = ""
                        sequence_start = None
                elif key == 'Tab':
                    if current_text:
                        typed_sequences.append({
                            'timestamp': sequence_start,
                            'text': current_text,
                            'end_action': 'tab'
                        })
                        current_text = ""
                        sequence_start = None
                elif key == 'Delete':
                    typed_sequences.append({
                        'timestamp': timestamp,
                        'text': '',
                        'end_action': 'delete'
                    })
                elif key and len(key) == 1:  # Regular character
                    if not current_text:
                        sequence_start = timestamp
                    current_text += key
        
        # Handle remaining text
        if current_text:
            typed_sequences.append({
                'timestamp': sequence_start,
                'text': current_text,
                'end_action': 'incomplete'
            })
        
        # Combine all interactions chronologically
        all_interactions = []
        
        for click in clicks:
            all_interactions.append({
                'timestamp': click['timestamp'],
                'type': 'click',
                'action': f"Click at screen location",
                'details': click['position']
            })
        
        for seq in typed_sequences:
            if seq['text']:  # Only include actual text
                action = f"Type '{seq['text']}'"
                if seq['end_action'] == 'enter':
                    action += " and press Enter"
                elif seq['end_action'] == 'tab':
                    action += " and press Tab"
                all_interactions.append({
                    'timestamp': seq['timestamp'],
                    'type': 'typing',
                    'action': action,
                    'details': {'text': seq['text'], 'end': seq['end_action']}
                })
            elif seq['end_action'] == 'delete':
                all_interactions.append({
                    'timestamp': seq['timestamp'],
                    'type': 'key',
                    'action': "Press Delete key",
                    'details': {}
                })
        
        for switch in app_switches:
            all_interactions.append({
                'timestamp': switch.get('timestamp', 0),
                'type': 'app_switch',
                'action': f"Switch from {switch.get('from_app')} to {switch.get('to_app')}",
                'details': switch
            })
        
        # Sort chronologically
        all_interactions.sort(key=lambda x: x['timestamp'])
        
        # Create timeline
        timeline = []
        timeline.append("=== GENERIC INTERACTION SEQUENCE ===")
        timeline.append(f"Session Duration: {duration:.1f} seconds")
        timeline.append(f"Total Interactions: {len(all_interactions)}")
        timeline.append("")
        timeline.append("Chronological sequence of user actions:")
        
        for i, interaction in enumerate(all_interactions):
            timestamp = interaction['timestamp']
            action = interaction['action']
            timeline.append(f"[{timestamp:.1f}s] {action}")
        
        timeline.append("")
        timeline.append("=" * 50)
        
        return "\n".join(timeline)
    
    def create_generic_workflow_prompt(self, interaction_sequence: str) -> str:
        """Create workflow-agnostic prompt for any Murex process"""
        
        prompt = f"""You are an expert RPA analyst creating generic workflow commands for Murex application processes. Your task is to convert user interactions into clear, executable RPA commands without making assumptions about the specific business process.

CRITICAL APPROACH:
🎯 WORKFLOW AGNOSTIC: Do not assume this is bonds, trading, configuration, or any specific process
🎯 DESCRIBE ACTIONS: Focus on WHAT the user does, not WHY they do it
🎯 GENERIC TERMS: Use "field", "dropdown", "button" rather than specific names
🎯 MUREX CONTEXT: This is a Murex application, but the workflow type is unknown
🎯 INTERACTION FOCUS: Capture the mechanical sequence of user actions

{interaction_sequence}

GENERIC RPA OUTPUT REQUIREMENTS:

✅ LOGIN & NAVIGATION:
- Describe login process generically
- Capture menu navigation without assuming destination
- Note screen transitions and loading

✅ DATA ENTRY (Generic Terms):
- "Type '[VALUE]' into the input field"
- "Select '[OPTION]' from the dropdown menu"  
- "Click the button/link/tab"
- "Navigate to the [SECTION] area"

✅ INTERACTION PATTERNS:
- Click sequences for navigation
- Field-to-field movement (Tab, Enter)
- Data corrections (Delete, re-type)
- Confirmation actions

✅ AVOID ASSUMPTIONS:
- Don't assume field purposes ("Security", "Currency", etc.)
- Don't assume business workflow ("bond creation", "trade entry")
- Don't assume data meanings
- Focus on mechanical actions

EXAMPLE GENERIC OUTPUT:
"Login to Murex application using the provided username and password. Navigate through the menu system to reach the target section. In the main work area, locate the first input field and type '[VALUE1]'. Move to the next field and select an option from the dropdown menu. Continue filling fields in sequence: type '[VALUE2]', select '[OPTION1]', enter '[VALUE3]'. Use Tab to move between fields and Enter to confirm entries. Make corrections by using Delete key and re-entering values. Click the process/submit button to complete the workflow."

Generate generic RPA commands that describe the user's interaction pattern with the Murex interface, without assumptions about the specific business process being performed."""

        return prompt
    
    def process_generic_murex_session(self, video_path: str, json_path: str) -> str:
        """Process any Murex workflow generically"""
        
        print(f"🔧 Generic Murex Workflow Processor")
        print("=" * 50)
        print("Processing workflow without business-specific assumptions")
        
        # Extract generic interaction sequence
        print("🔍 Extracting generic interaction sequence...")
        interaction_sequence = self.extract_interaction_sequence(json_path)
        
        # Count interactions
        lines = interaction_sequence.split('\n')
        interaction_count = len([l for l in lines if l.startswith('[')])
        print(f"📊 Found {interaction_count} user interactions")
        
        # Create generic prompt
        prompt = self.create_generic_workflow_prompt(interaction_sequence)
        
        # Check video file size
        size_mb = os.path.getsize(video_path) / (1024 * 1024)
        if size_mb > self.config.MAX_FILE_SIZE_MB:
            print(f"❌ Video file too large: {size_mb:.1f} MB")
            return None
        
        print(f"✅ Video size OK: {size_mb:.1f} MB")
        
        # Encode video
        print("🔄 Encoding video for generic analysis...")
        try:
            with open(video_path, 'rb') as f:
                video_bytes = f.read()
            video_base64 = base64.b64encode(video_bytes).decode('utf-8')
        except Exception as e:
            print(f"❌ Error encoding video: {e}")
            return None
        
        # Generic processing configuration
        generic_config = {
            "temperature": 0.3,  # Balanced for generic descriptions
            "topK": 5,
            "topP": 0.9,
            "maxOutputTokens": 4000,  # Focused output
            "responseMimeType": "text/plain"
        }
        
        generic_video_metadata = {
            "fps": 2.0  # Good detail without over-analysis
        }
        
        # Prepare API request
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inline_data": {
                                "mime_type": "video/mp4",
                                "data": video_base64
                            },
                            "video_metadata": generic_video_metadata
                        }
                    ]
                }
            ],
            "generationConfig": generic_config
        }
        
        # Make API request
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.config.GEMINI_MODEL}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }
        
        print("🚀 Generating generic Murex workflow commands...")
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=400)
            
            if response.status_code == 200:
                result = response.json()
                
                # Extract token usage
                if "usageMetadata" in result:
                    usage = result["usageMetadata"]
                    total_tokens = usage.get('totalTokenCount', 0)
                    estimated_cost = (total_tokens / 1000) * 0.00015
                    print(f"💰 Tokens: {total_tokens:,}, Cost: ${estimated_cost:.6f}")
                
                # Extract generic RPA commands
                if "candidates" in result and len(result["candidates"]) > 0:
                    candidate = result["candidates"][0]
                    if "content" in candidate and "parts" in candidate["content"]:
                        text_parts = [part.get("text", "") for part in candidate["content"]["parts"]]
                        rpa_commands = "".join(text_parts).strip()
                        
                        # Save generic commands
                        base_name = os.path.splitext(os.path.basename(video_path))[0]
                        output_name = f"{base_name}_GENERIC_MUREX_rpa_commands.txt"
                        
                        output_dir = self.config.ensure_output_dir()
                        output_path = os.path.join(output_dir, output_name)
                        
                        with open(output_path, 'w') as f:
                            f.write(f"# Generic Murex RPA Commands Generated: {datetime.now()}\n")
                            f.write(f"# Source Video: {os.path.basename(video_path)}\n")
                            f.write(f"# Source JSON: {os.path.basename(json_path)}\n")
                            f.write(f"# Processing Mode: Generic Workflow (No Business Assumptions)\n")
                            f.write(f"# Interactions Captured: {interaction_count}\n")
                            f.write(f"# Application: Murex (Workflow Type: Auto-detected)\n\n")
                            f.write(rpa_commands)
                        
                        print(f"✅ Generic Murex RPA commands saved to: {output_path}")
                        print(f"\n🔧 Generic Commands Preview:")
                        print("-" * 60)
                        preview = rpa_commands[:400] + "..." if len(rpa_commands) > 400 else rpa_commands
                        print(preview)
                        
                        print(f"\n🎯 Generic Processing Summary:")
                        print(f"   • Workflow type: Auto-detected (no assumptions)")
                        print(f"   • Interactions: {interaction_count}")
                        print(f"   • Application: Murex")
                        print(f"   • Output: Generic RPA commands")
                        print(f"   • Reusable: For any Murex workflow")
                        
                        return rpa_commands
                        
            else:
                print(f"❌ API Error: HTTP {response.status_code}")
                
        except Exception as e:
            print(f"❌ Error: {e}")
            
        return None


def main():
    """Main function for generic Murex processing"""
    print("🔧 Generic Murex Workflow Processor")
    print("=" * 50)
    print("Workflow-agnostic RPA command generation")
    print("Works for ANY Murex process: Trading, Bonds, Config, Reports, etc.")
    print("=" * 50)
    
    # Auto-detect latest recording or specify files
    import sys
    if len(sys.argv) > 2:
        video_path = sys.argv[1]
        json_path = sys.argv[2]
    else:
        # Default to your latest recording
        video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
        json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    print(f"📹 Video: {video_path}")
    print(f"📊 JSON:  {json_path}")
    
    try:
        processor = GenericMurexProcessor()
        commands = processor.process_generic_murex_session(video_path, json_path)
        
        if commands:
            print(f"\n🎉 SUCCESS: Generic Murex RPA commands generated!")
            print(f"✅ Works for ANY Murex workflow")
            print(f"✅ No business-specific assumptions")
            print(f"✅ Reusable for trading, bonds, config, reports, etc.")
            print(f"📁 Ready for your RPA execution engine")
        else:
            print(f"\n❌ Generic processing failed")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()