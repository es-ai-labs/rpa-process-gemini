#!/usr/bin/env python3
"""
Human-Readable RPA Processor

Captures ALL interactions but describes them in natural language
as if explaining the process to a human colleague.

No coordinates, no technical details - just clear business instructions
that don't miss any steps.
"""

import json
from typing import List, Dict
from ultra_precise_rpa_processor import UltraPreciseRpaProcessor

class HumanReadableRpaProcessor(UltraPreciseRpaProcessor):
    """Processor that creates human-readable business instructions"""
    
    def create_human_readable_prompt(self, detailed_timeline: str) -> str:
        """Create prompt for human-readable RPA commands"""
        
        prompt = f"""You are an expert business process analyst creating natural language RPA commands. Your task is to describe the COMPLETE workflow as if explaining it to a human colleague who needs to perform the same tasks.

CRITICAL REQUIREMENTS:
🎯 COMPLETE COVERAGE: Capture EVERY interaction from the 198.5-second session - miss nothing
🎯 HUMAN LANGUAGE: Write as if instructing a colleague, not a robot
🎯 NO COORDINATES: Focus on business actions, not technical details
🎯 FIELD NAMES: Use actual field labels and business terminology
🎯 LOGICAL FLOW: Organize steps in clear business sequence

{detailed_timeline}

HUMAN-READABLE OUTPUT STYLE:

✅ USE NATURAL BUSINESS LANGUAGE:
- "Login to the application using username MUREXFO"
- "Navigate to the Bonds section" 
- "Type 'SAGB123456' into the Security field"
- "Select 'ZAR' from the Currency dropdown"

✅ DESCRIBE BUSINESS ACTIONS:
- What the user is trying to accomplish
- Which screens/sections they navigate to
- What data they enter and why
- How they confirm or submit actions

✅ INCLUDE ALL INTERACTIONS:
- Every menu click and navigation
- Every field that gets populated  
- Every dropdown selection
- Every confirmation and submission
- All corrections and edits made

✅ MAINTAIN WORKFLOW CONTEXT:
- Group related actions together
- Explain the business purpose
- Include wait points and confirmations
- Note any error corrections

EXAMPLE STYLE (like your sample commands):
"Login to Murex application using username MUREXFO and password [PASSWORD], then click to Login. When you see the welcome screen, click the START button. Once on the main page, navigate to the History menu and select Bonds. On the Bonds page, click Edit and select Insert to create a new bond. In the Properties section, type 'SAGB123456' into the Security field and press Enter. Open the Currency dropdown and select 'ZAR'. Type '1000000' into the Amount field. Continue filling all required fields..."

Your output should read like step-by-step instructions you would give to a colleague, capturing every action from the session but in clear, natural business language. Focus on WHAT is being done and WHERE, not technical coordinates.

Generate the complete workflow description that captures all 143 interactions in human-readable format."""

        return prompt
    
    def process_human_readable_session(self, video_path: str, json_path: str) -> str:
        """Process session for human-readable business instructions"""
        
        print(f"👥 Human-Readable RPA Processing")
        print("=" * 50)
        print("Creating natural language business instructions...")
        
        # Use the ultra-detailed timeline for completeness
        detailed_timeline = self.create_ultra_detailed_timeline(json_path)
        event_count = detailed_timeline.count('[') - 3
        print(f"📊 Processing {event_count} interactions into natural language")
        
        # Create human-readable prompt
        prompt = self.create_human_readable_prompt(detailed_timeline)
        
        # Check video file size
        import os
        size_mb = os.path.getsize(video_path) / (1024 * 1024)
        if size_mb > self.config.MAX_FILE_SIZE_MB:
            print(f"❌ Video file too large: {size_mb:.1f} MB")
            return None
        
        print(f"✅ Video size OK: {size_mb:.1f} MB")
        
        # Encode video
        print("🔄 Encoding video for human-readable analysis...")
        import base64
        try:
            with open(video_path, 'rb') as f:
                video_bytes = f.read()
            video_base64 = base64.b64encode(video_bytes).decode('utf-8')
        except Exception as e:
            print(f"❌ Error encoding video: {e}")
            return None
        
        # Human-readable configuration - optimized for natural language
        human_config = {
            "temperature": 0.3,  # Slightly higher for natural language flow
            "topK": 5,
            "topP": 0.95,
            "maxOutputTokens": 5000,  # Focused on clear instructions
            "responseMimeType": "text/plain"
        }
        
        human_video_metadata = {
            "fps": 2.0  # Good balance of detail and processing
        }
        
        # Prepare human-readable API request
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inline_data": {
                                "mime_type": "video/mp4",
                                "data": video_base64
                            },
                            "video_metadata": human_video_metadata
                        }
                    ]
                }
            ],
            "generationConfig": human_config
        }
        
        # Make API request
        import requests
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.config.GEMINI_MODEL}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }
        
        print("🚀 Generating human-readable instructions...")
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=400)
            
            if response.status_code == 200:
                result = response.json()
                
                # Extract token usage
                if "usageMetadata" in result:
                    usage = result["usageMetadata"]
                    total_tokens = usage.get('totalTokenCount', 0)
                    estimated_cost = (total_tokens / 1000) * 0.00015
                    print(f"💰 Tokens: {total_tokens:,}, Cost: ${estimated_cost:.6f}")
                
                # Extract human-readable RPA commands
                if "candidates" in result and len(result["candidates"]) > 0:
                    candidate = result["candidates"][0]
                    if "content" in candidate and "parts" in candidate["content"]:
                        text_parts = [part.get("text", "") for part in candidate["content"]["parts"]]
                        rpa_commands = "".join(text_parts).strip()
                        
                        # Save human-readable commands
                        base_name = os.path.splitext(os.path.basename(video_path))[0]
                        output_name = f"{base_name}_HUMAN_READABLE_rpa_commands.txt"
                        
                        output_dir = self.config.ensure_output_dir()
                        output_path = os.path.join(output_dir, output_name)
                        
                        from datetime import datetime
                        with open(output_path, 'w') as f:
                            f.write(f"# Human-Readable RPA Commands Generated: {datetime.now()}\n")
                            f.write(f"# Source Video: {os.path.basename(video_path)}\n")
                            f.write(f"# Source JSON: {os.path.basename(json_path)}\n")
                            f.write(f"# Processing Mode: Human-Readable Business Instructions\n")
                            f.write(f"# Total Interactions: {event_count} (all captured)\n")
                            f.write(f"# Session Duration: 198.5 seconds\n\n")
                            f.write(rpa_commands)
                        
                        print(f"✅ Human-readable RPA commands saved to: {output_path}")
                        print(f"\n👥 Human-Readable Commands Preview:")
                        print("-" * 60)
                        preview = rpa_commands[:400] + "..." if len(rpa_commands) > 400 else rpa_commands
                        print(preview)
                        
                        print(f"\n📊 Summary:")
                        print(f"   • Total interactions: {event_count} (complete coverage)")
                        print(f"   • Output style: Natural business language")
                        print(f"   • Technical details: Removed (no coordinates)")
                        print(f"   • Business focus: Maintained")
                        
                        return rpa_commands
                        
            else:
                print(f"❌ API Error: HTTP {response.status_code}")
                try:
                    error_detail = response.json()
                    print(error_detail)
                except:
                    print(response.text)
                
        except Exception as e:
            print(f"❌ Error: {e}")
            
        return None


def main():
    """Main function for human-readable processing"""
    print("👥 Human-Readable RPA Processor")
    print("=" * 50)
    print("Converts technical interactions into natural business instructions")
    print("Perfect for RPA engines that need human-like descriptions")
    print("=" * 50)
    
    # Your specific files
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    try:
        processor = HumanReadableRpaProcessor()
        commands = processor.process_human_readable_session(video_path, json_path)
        
        if commands:
            print(f"\n🎉 SUCCESS: Human-readable RPA commands generated!")
            print(f"📁 Perfect for your RPA execution engine")
            print(f"✅ All steps captured in natural language")
        else:
            print(f"\n❌ Human-readable processing failed")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()