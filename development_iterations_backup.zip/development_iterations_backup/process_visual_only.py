import os
import base64
import json
import requests
from dotenv import load_dotenv

# --- Configuration ---

VIDEO_FILE = "safe_recording_20250730_182151.mp4"  # Using the compressed video file
# Set the desired frames per second for sampling.
# Lower FPS for UI interactions to save tokens
FRAMES_PER_SECOND = 0.1
PROMPT = """Analyze the visual content of this video showing a user interacting with a software UI.

Focus ONLY on the visual actions - ignore any audio or narration.

Your task is to produce a JSON object with the following structure:
{
  "ui_actions": [
    {
      "timestamp": "MM:SS",
      "action_type": "CLICK|TYPE|SELECT|SCROLL|DRAG|RIGHT_CLICK|DOUBLE_CLICK|HOVER",
      "target_element": "Description of the UI element (button, field, menu, etc.)",
      "target_text": "Visible text on or near the element",
      "value": "Text entered or option selected (if applicable)",
      "screen_area": "General area of screen (top-left, center, bottom-right, etc.)"
    }
  ],
  "workflow_summary": "Brief description of the overall process being performed"
}

Important guidelines:
- Focus only on user interactions with UI elements
- Ignore any spoken words or audio content
- Be precise about element descriptions
- Include the visible text on buttons/fields when possible
- Note the general screen location for each action
- Only include actual user actions (clicks, typing, etc.), not system responses"""

MODEL = "gemini-1.5-flash"
# --- End Configuration ---

def check_file_size(file_path):
    """Check if file is under 20MB limit for inline data"""
    try:
        size_mb = os.path.getsize(file_path) / (1024 * 1024)
        print(f"Video file size: {size_mb:.2f} MB")
        if size_mb > 20:
            print("Warning: File is over 20MB. Consider using File API instead.")
            return False
        return True
    except Exception as e:
        print(f"Error checking file size: {e}")
        return False

def process_video_visual_only(video_path: str, fps: float, prompt: str, model: str):
    """
    Analyzes a video for visual UI actions only, ignoring audio content.
    Note: This method is for videos smaller than 20MB.
    """
    print(f"Processing '{video_path}' at {fps} FPS for VISUAL ACTIONS ONLY")
    print("📹 Audio narration will be ignored")
    
    # 0. Check file size
    if not check_file_size(video_path):
        return
    
    # 1. Load API Key
    try:
        load_dotenv()
        api_key = os.environ["GEMINI_API_KEY"]
    except KeyError:
        print("Error: GEMINI_API_KEY not found. Please set it in your .env file.")
        return

    # 2. Read video bytes from file
    print("Reading video file into memory...")
    try:
        with open(video_path, 'rb') as f:
            video_bytes = f.read()
    except FileNotFoundError:
        print(f"Error: Video file not found at '{video_path}'")
        return

    # 3. Encode video as base64
    print("Encoding video as base64...")
    video_base64 = base64.b64encode(video_bytes).decode('utf-8')

    # 4. Construct the request payload with video_metadata for FPS control
    payload = {
        "contents": [
            {
                "parts": [
                    {
                        "text": prompt
                    },
                    {
                        "inline_data": {
                            "mime_type": "video/mp4",
                            "data": video_base64
                        },
                        "video_metadata": {
                            "fps": fps
                        }
                    }
                ]
            }
        ],
        "generationConfig": {
            "temperature": 0.1,
            "topK": 1,
            "topP": 1,
            "maxOutputTokens": 3000,  # Increased for detailed JSON output
            "responseMimeType": "application/json"  # Request JSON response
        }
    }

    # 5. Make the API request
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    headers = {
        "Content-Type": "application/json",
        "x-goog-api-key": api_key
    }

    print("Sending request to Gemini API...")
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=120)
        
        print(f"Response status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            
            # Extract token usage information
            if "usageMetadata" in result:
                usage = result["usageMetadata"]
                print(f"\n--- Token Usage ---")
                print(f"Prompt tokens: {usage.get('promptTokenCount', 'N/A')}")
                print(f"Candidates tokens: {usage.get('candidatesTokenCount', 'N/A')}")
                print(f"Total tokens: {usage.get('totalTokenCount', 'N/A')}")
                
                # Calculate estimated cost (rough estimate based on current pricing)
                total_tokens = usage.get('totalTokenCount', 0)
                estimated_cost = (total_tokens / 1000) * 0.00015  # Approximate cost per 1K tokens
                print(f"Estimated cost: ${estimated_cost:.6f}")
            
            # Extract and parse the JSON response
            if "candidates" in result and len(result["candidates"]) > 0:
                candidate = result["candidates"][0]
                if "content" in candidate and "parts" in candidate["content"]:
                    text_parts = [part.get("text", "") for part in candidate["content"]["parts"]]
                    generated_text = "".join(text_parts)
                    
                    print("\n--- Visual UI Actions Analysis ---")
                    
                    # Try to parse as JSON for better formatting
                    try:
                        ui_data = json.loads(generated_text)
                        
                        print("\n🎯 Workflow Summary:")
                        print(f"   {ui_data.get('workflow_summary', 'N/A')}")
                        
                        print(f"\n📋 UI Actions Detected ({len(ui_data.get('ui_actions', []))}):")
                        
                        for i, action in enumerate(ui_data.get('ui_actions', []), 1):
                            print(f"\n   {i}. [{action.get('timestamp', 'N/A')}] {action.get('action_type', 'N/A')}")
                            print(f"      Target: {action.get('target_element', 'N/A')}")
                            if action.get('target_text'):
                                print(f"      Text: \"{action.get('target_text')}\"")
                            if action.get('value'):
                                print(f"      Value: \"{action.get('value')}\"")
                            print(f"      Location: {action.get('screen_area', 'N/A')}")
                        
                        # Save structured data to file
                        output_file = f"{os.path.splitext(video_path)[0]}_visual_actions.json"
                        with open(output_file, 'w') as f:
                            json.dump(ui_data, f, indent=2)
                        print(f"\n💾 Structured data saved to: {output_file}")
                        
                    except json.JSONDecodeError:
                        print("Raw response (not valid JSON):")
                        print(generated_text)
                        
                else:
                    print("Error: Unexpected response structure")
                    print(json.dumps(result, indent=2))
            else:
                print("Error: No candidates in response")
                print(json.dumps(result, indent=2))
                
        else:
            print(f"Error: HTTP {response.status_code}")
            try:
                error_detail = response.json()
                print(json.dumps(error_detail, indent=2))
            except:
                print(response.text)
            
    except requests.exceptions.Timeout:
        print("Request timed out. The video might be too large or complex.")
    except requests.exceptions.RequestException as e:
        print(f"Network error: {e}")
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")


def main():
    """Main function with example usage"""
    
    print("🎬 Visual-Only UI Action Analyzer")
    print("=" * 50)
    print("This script processes videos to extract visual UI actions")
    print("while ignoring audio narration for more focused analysis.")
    print("=" * 50)
    
    process_video_visual_only(
        video_path=VIDEO_FILE,
        fps=FRAMES_PER_SECOND,
        prompt=PROMPT,
        model=MODEL
    )


if __name__ == "__main__":
    main() 