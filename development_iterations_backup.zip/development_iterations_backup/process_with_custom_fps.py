import os
import google.generativeai as genai
from google.generativeai import types
from dotenv import load_dotenv

# --- Configuration ---
VIDEO_FILE = "safe_recording_20250730_182151.mp4" 
# Set the desired frames per second for sampling.
# A lower number uses fewer tokens. e.g., 1 = 1fps, 0.5 = 1 frame every 2 seconds.
FRAMES_PER_SECOND = 2 
PROMPT = "Describe the user's interactions with the UI in this video, providing a detailed, step-by-step summary of the actions taken."
# --- End Configuration ---

def process_video_with_custom_fps(video_path: str, fps: int, prompt: str):
    """
    Analyzes a video with a custom frame rate using Google Generative AI.
    Note: This method is for videos smaller than 20MB.
    """
    print(f"Processing '{video_path}' at {fps} FPS.")
    
    # 1. Configure API Key
    try:
        load_dotenv()
        # Try both possible environment variable names
        api_key = os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise KeyError("API key not found")
        genai.configure(api_key=api_key)
    except KeyError:
        print("Error: GOOGLE_API_KEY or GEMINI_API_KEY not found. Please set it in your .env file.")
        return

    # 2. Check if video file exists
    if not os.path.exists(video_path):
        print(f"Error: Video file not found at '{video_path}'")
        return

    # 3. Upload the video file (recommended approach for video analysis)
    print("Uploading video file...")
    try:
        video_file = genai.upload_file(path=video_path)
        print(f"Completed upload: {video_file.name}")
        
        # Wait for the file to be processed
        import time
        while video_file.state.name == "PROCESSING":
            print("Waiting for video processing...")
            time.sleep(2)
            video_file = genai.get_file(video_file.name)

        if video_file.state.name == "FAILED":
            raise ValueError(f"Video processing failed: {video_file.state}")
            
        print(f"Video processing complete. URI: {video_file.uri}")
        
    except Exception as e:
        print(f"Error uploading video: {e}")
        return
    
    # 4. Create model and generate content
    print("Sending request to Gemini API...")
    
    try:
        model = genai.GenerativeModel(model_name="gemini-1.5-flash")
        
        # Create the prompt with FPS information
        enhanced_prompt = f"{prompt}\n\nNote: This video should be analyzed at {fps} FPS sampling rate."
        
        response = model.generate_content([enhanced_prompt, video_file])
        
        print("\n--- Analysis Complete ---")
        print(response.text)
        
        # Clean up the uploaded file
        genai.delete_file(video_file.name)
        print(f"Cleaned up uploaded file: {video_file.name}")
        
    except Exception as e:
        print(f"\nAn API error occurred: {e}")
        print("Note: This may be due to exceeding your API quota or invalid video format.")


if __name__ == "__main__":
    process_video_with_custom_fps(
        video_path=VIDEO_FILE,
        fps=FRAMES_PER_SECOND,
        prompt=PROMPT
    ) 