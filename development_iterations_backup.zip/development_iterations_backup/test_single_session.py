#!/usr/bin/env python3
"""
Quick test script to process your specific recording session
"""

from simple_rpa_generator import SimpleRpaGenerator

def main():
    print("🎬 Processing your recording session...")
    
    # Your specific files
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    print(f"📹 Video: {video_path}")
    print(f"📊 JSON:  {json_path}")
    
    try:
        generator = SimpleRpaGenerator()
        
        # Process the session
        commands = generator.process_single_session(video_path, json_path)
        
        if commands:
            print("✅ RPA commands generated successfully!")
            print("📁 Check the 'generated_rpa_commands/' directory for output")
        else:
            print("❌ Failed to generate RPA commands")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()