#!/usr/bin/env python3
"""
UI Element Detection Processor

Generates RPA commands in the exact style of the user's samples:
- Natural language instructions
- Specific UI element names (buttons, fields, screens)
- Exact values typed/selected
- Detailed enough for RPA execution
- Generic approach but specific output
"""

import json
import base64
import requests
import os
from datetime import datetime
from typing import List, Dict
from simple_rpa_generator import SimpleRpaGenerator
from rpa_config import RpaConfig

class UIElementDetectionProcessor(SimpleRpaGenerator):
    """Processor that detects actual UI elements and generates specific RPA commands"""
    
    def extract_detailed_interaction_data(self, json_path: str) -> str:
        """Extract detailed interaction data for UI element detection"""
        
        with open(json_path, 'r') as f:
            data = json.load(f)
        
        session_info = data.get('session_info', {})
        duration = session_info.get('duration', 0)
        
        mouse_interactions = data.get('mouse_interactions', [])
        keyboard_events = data.get('keyboard_events', [])
        typing_sessions = data.get('typing_sessions', [])
        app_switches = data.get('app_switches', [])
        
        # Extract clicks with precise timing
        clicks = []
        for interaction in mouse_interactions:
            if interaction.get('type') == 'mouse_press' and interaction.get('button') == 'left':
                clicks.append({
                    'timestamp': interaction.get('timestamp', 0),
                    'position': interaction.get('position', {}),
                    'datetime': interaction.get('datetime', '')
                })
        
        # Extract typed text sequences with values
        typed_sequences = []
        if typing_sessions:
            for session in typing_sessions:
                if session.get('final_text'):
                    typed_sequences.append({
                        'timestamp': session.get('start_time', 0),
                        'text': session.get('final_text', ''),
                        'duration': session.get('duration', 0)
                    })
        else:
            # Fallback: extract from individual key events
            current_text = ""
            sequence_start = None
            
            for event in keyboard_events:
                if event.get('type') == 'key_press' and event.get('is_character'):
                    key = event.get('key_name', '')
                    timestamp = event.get('timestamp', 0)
                    
                    if key in ['Return', 'Tab']:
                        if current_text:
                            typed_sequences.append({
                                'timestamp': sequence_start,
                                'text': current_text,
                                'end_key': key
                            })
                            current_text = ""
                            sequence_start = None
                    elif key and len(key) == 1:
                        if not current_text:
                            sequence_start = timestamp
                        current_text += key
            
            if current_text:
                typed_sequences.append({
                    'timestamp': sequence_start,
                    'text': current_text,
                    'end_key': 'incomplete'
                })
        
        # Create detailed timeline
        timeline = []
        timeline.append("=== DETAILED UI INTERACTION DATA ===")
        timeline.append(f"Session Duration: {duration:.1f} seconds")
        timeline.append(f"Application: Murex")
        timeline.append("")
        
        timeline.append("MOUSE CLICKS (for UI element identification):")
        for i, click in enumerate(clicks):
            timeline.append(f"[{click['timestamp']:.1f}s] Click at position ({click['position'].get('x')}, {click['position'].get('y')})")
        
        timeline.append("")
        timeline.append("TEXT ENTRIES (values typed into fields):")
        for i, text in enumerate(typed_sequences):
            timeline.append(f"[{text['timestamp']:.1f}s] Typed: '{text['text']}'")
        
        if app_switches:
            timeline.append("")
            timeline.append("APPLICATION SWITCHES:")
            for switch in app_switches:
                timeline.append(f"[{switch.get('timestamp', 0):.1f}s] From {switch.get('from_app')} to {switch.get('to_app')}")
        
        timeline.append("")
        timeline.append("=" * 50)
        
        return "\n".join(timeline)
    
    def create_ui_element_focused_prompt(self, interaction_data: str) -> str:
        """Create prompt focused on UI element detection and specific naming"""
        
        prompt = f"""You are an expert RPA analyst creating detailed, executable RPA commands. Your task is to watch the video and generate step-by-step instructions that identify SPECIFIC UI elements (screens, buttons, fields, dropdowns) and the EXACT values entered.

CRITICAL REQUIREMENTS:
🎯 IDENTIFY SPECIFIC UI ELEMENTS: Watch for actual button text, field labels, screen titles
🎯 EXTRACT EXACT VALUES: Capture precise text typed into each field
🎯 NATURAL LANGUAGE FORMAT: Write like the provided examples
🎯 RPA EXECUTABLE: Commands must be detailed enough for RPA engine to find and interact with elements

{interaction_data}

EXPECTED OUTPUT STYLE (like the examples):
"Login to Murex application using username [USERNAME] and password [PASSWORD], then click to Login. Then click on the [SPECIFIC_GROUP_NAME] group and click Start. Once on the main page type '[EXACT_SEARCH_TERM]' and press enter. Once on the [SPECIFIC_PAGE_NAME] page, you'll see a list of [ITEMS]. Type '[EXACT_FILTER_VALUE]' into the searchbar and press enter to filter the list. Then double click on the [SPECIFIC_OPTION] option when you see it."

UI ELEMENT DETECTION FOCUS:
✅ SCREEN NAMES: "main page", "revaluation rate curves page", "details page"
✅ BUTTON TEXT: "Login", "Start", "Details", "Process"  
✅ FIELD LABELS: "searchbar", "Security field", "Currency dropdown"
✅ MENU ITEMS: "FO_AM group", "History menu", "Bonds section"
✅ OPTION TEXT: "ZAR option", "Fixed option", "ZAR FX cell"
✅ EXACT VALUES: 'MUREXFO', 'ZAR', 'SAGB123456', 'BSE USDINR'

VIDEO ANALYSIS INSTRUCTIONS:
1. Watch the video frame by frame to identify:
   - Screen titles and page names
   - Button text and labels
   - Field names and input areas
   - Dropdown menus and their options
   - Menu items and navigation elements
   
2. For each interaction, identify:
   - What UI element was clicked (specific button/field name)
   - What text was typed (exact values)
   - What options were selected (specific option names)
   - What screens appeared (page titles/names)

3. Correlate video visuals with the interaction timing data to map:
   - Each click to a specific UI element
   - Each text entry to a specific field
   - Each screen transition to a page name

Generate detailed RPA commands that specify exactly which UI elements to interact with and what values to enter, following the natural language style of the examples."""

        return prompt
    
    def process_ui_element_detection(self, video_path: str, json_path: str) -> str:
        """Process video to detect UI elements and generate specific RPA commands"""
        
        print(f"🎯 UI Element Detection Processor")
        print("=" * 50)
        print("Detecting specific UI elements for RPA execution")
        
        # Extract detailed interaction data
        print("🔍 Extracting UI interaction data...")
        interaction_data = self.extract_detailed_interaction_data(json_path)
        
        # Count interactions
        lines = interaction_data.split('\n')
        click_count = len([l for l in lines if 'Click at position' in l])
        text_count = len([l for l in lines if 'Typed:' in l])
        print(f"📊 Found {click_count} clicks and {text_count} text entries")
        
        # Create UI-focused prompt
        prompt = self.create_ui_element_focused_prompt(interaction_data)
        
        # Check video file size
        size_mb = os.path.getsize(video_path) / (1024 * 1024)
        if size_mb > self.config.MAX_FILE_SIZE_MB:
            print(f"❌ Video file too large: {size_mb:.1f} MB")
            return None
        
        print(f"✅ Video size OK: {size_mb:.1f} MB")
        
        # Encode video
        print("🔄 Encoding video for UI element detection...")
        try:
            with open(video_path, 'rb') as f:
                video_bytes = f.read()
            video_base64 = base64.b64encode(video_bytes).decode('utf-8')
        except Exception as e:
            print(f"❌ Error encoding video: {e}")
            return None
        
        # UI detection configuration - optimized for element identification
        ui_config = {
            "temperature": 0.1,  # Low temperature for accurate element detection
            "topK": 1,
            "topP": 0.9,
            "maxOutputTokens": 4000,
            "responseMimeType": "text/plain"
        }
        
        ui_video_metadata = {
            "fps": 2.5  # Higher FPS for detailed UI element detection
        }
        
        # Prepare API request
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inline_data": {
                                "mime_type": "video/mp4",
                                "data": video_base64
                            },
                            "video_metadata": ui_video_metadata
                        }
                    ]
                }
            ],
            "generationConfig": ui_config
        }
        
        # Make API request
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.config.GEMINI_MODEL}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }
        
        print("🚀 Analyzing video for UI elements and generating RPA commands...")
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=400)
            
            if response.status_code == 200:
                result = response.json()
                
                # Extract token usage
                if "usageMetadata" in result:
                    usage = result["usageMetadata"]
                    total_tokens = usage.get('totalTokenCount', 0)
                    estimated_cost = (total_tokens / 1000) * 0.00015
                    print(f"💰 Tokens: {total_tokens:,}, Cost: ${estimated_cost:.6f}")
                
                # Extract RPA commands
                if "candidates" in result and len(result["candidates"]) > 0:
                    candidate = result["candidates"][0]
                    if "content" in candidate and "parts" in candidate["content"]:
                        text_parts = [part.get("text", "") for part in candidate["content"]["parts"]]
                        rpa_commands = "".join(text_parts).strip()
                        
                        # Save UI element-specific commands
                        base_name = os.path.splitext(os.path.basename(video_path))[0]
                        output_name = f"{base_name}_UI_ELEMENT_SPECIFIC_rpa_commands.txt"
                        
                        output_dir = self.config.ensure_output_dir()
                        output_path = os.path.join(output_dir, output_name)
                        
                        with open(output_path, 'w') as f:
                            f.write(f"# UI Element-Specific RPA Commands Generated: {datetime.now()}\n")
                            f.write(f"# Source Video: {os.path.basename(video_path)}\n")
                            f.write(f"# Source JSON: {os.path.basename(json_path)}\n")
                            f.write(f"# Processing Mode: UI Element Detection & Specific Naming\n")
                            f.write(f"# Application: Murex\n")
                            f.write(f"# Format: Natural language with specific element names\n\n")
                            f.write(rpa_commands)
                        
                        print(f"✅ UI element-specific RPA commands saved to: {output_path}")
                        print(f"\n🎯 UI Element-Specific Commands Preview:")
                        print("-" * 60)
                        preview = rpa_commands[:500] + "..." if len(rpa_commands) > 500 else rpa_commands
                        print(preview)
                        
                        print(f"\n📊 UI Detection Summary:")
                        print(f"   • UI elements: Identified from video analysis")
                        print(f"   • Format: Natural language with specific names")
                        print(f"   • RPA ready: Executable by RPA engine")
                        print(f"   • Style: Matches provided examples")
                        
                        return rpa_commands
                        
            else:
                print(f"❌ API Error: HTTP {response.status_code}")
                
        except Exception as e:
            print(f"❌ Error: {e}")
            
        return None


def main():
    """Main function for UI element detection processing"""
    print("🎯 UI Element Detection Processor")
    print("=" * 50)
    print("Generates RPA commands with specific UI element names")
    print("Format: Natural language like your sample commands")
    print("=" * 50)
    
    # Process your files
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    print(f"📹 Video: {video_path}")
    print(f"📊 JSON:  {json_path}")
    
    try:
        processor = UIElementDetectionProcessor()
        commands = processor.process_ui_element_detection(video_path, json_path)
        
        if commands:
            print(f"\n🎉 SUCCESS: UI element-specific RPA commands generated!")
            print(f"✅ Natural language format")
            print(f"✅ Specific UI element names") 
            print(f"✅ Exact values and field names")
            print(f"✅ RPA engine executable")
            print(f"📁 Ready for your RPA execution engine")
        else:
            print(f"\n❌ UI element detection failed")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()