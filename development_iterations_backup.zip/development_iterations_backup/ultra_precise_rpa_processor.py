#!/usr/bin/env python3
"""
Ultra-Precise RPA Processor

The most accurate processor that ensures ALL interactions are captured:
- Maps mouse press/release pairs to clicks
- Captures every keyboard entry and field selection
- Ensures no final steps are missed
- Creates detailed field-by-field timeline
- Uses maximum video analysis resolution
"""

import json
import base64
import requests
import os
from datetime import datetime
from typing import List, Dict, Tuple
from simple_rpa_generator import SimpleRpaGenerator
from rpa_config import RpaConfig

class UltraPreciseRpaProcessor(SimpleRpaGenerator):
    """Ultra-precise processor that captures every single interaction"""
    
    def extract_all_clicks(self, mouse_interactions: List[Dict]) -> List[Dict]:
        """Extract all clicks from mouse press/release pairs"""
        clicks = []
        
        # Find mouse_press events and match with releases
        for i, interaction in enumerate(mouse_interactions):
            if interaction.get('type') == 'mouse_press':
                press_time = interaction.get('timestamp', 0)
                press_pos = interaction.get('position', {})
                button = interaction.get('button', 'left')
                
                # Look for corresponding release
                release_time = None
                for j in range(i + 1, min(i + 10, len(mouse_interactions))):  # Look ahead 10 events
                    if (mouse_interactions[j].get('type') == 'mouse_release' and 
                        mouse_interactions[j].get('button') == button):
                        release_time = mouse_interactions[j].get('timestamp', 0)
                        break
                
                # Calculate click duration
                duration = (release_time - press_time) if release_time else 0
                
                # Determine click type based on duration
                if duration < 0.2:
                    click_type = 'click'
                elif duration < 0.5:
                    click_type = 'long_click'
                else:
                    click_type = 'drag'
                
                clicks.append({
                    'timestamp': press_time,
                    'type': f'{button}_{click_type}',
                    'position': press_pos,
                    'duration': duration
                })
        
        return clicks
    
    def extract_typed_sequences(self, keyboard_events: List[Dict]) -> List[Dict]:
        """Extract complete typed sequences from individual key events"""
        sequences = []
        current_sequence = ""
        sequence_start_time = None
        last_key_time = None
        
        for event in keyboard_events:
            if event.get('type') == 'key_press' and event.get('is_character'):
                key_name = event.get('key_name', '')
                timestamp = event.get('timestamp', 0)
                
                # Special handling for different key types
                if key_name == 'Return':
                    if current_sequence:
                        sequences.append({
                            'timestamp': sequence_start_time,
                            'text': current_sequence,
                            'end_action': 'enter',
                            'duration': timestamp - sequence_start_time if sequence_start_time else 0
                        })
                        current_sequence = ""
                        sequence_start_time = None
                elif key_name == 'Tab':
                    if current_sequence:
                        sequences.append({
                            'timestamp': sequence_start_time,
                            'text': current_sequence,
                            'end_action': 'tab',
                            'duration': timestamp - sequence_start_time if sequence_start_time else 0
                        })
                        current_sequence = ""
                        sequence_start_time = None
                elif key_name == 'Delete':
                    # Handle delete operations
                    sequences.append({
                        'timestamp': timestamp,
                        'text': '',
                        'end_action': 'delete',
                        'duration': 0
                    })
                elif key_name and len(key_name) == 1:  # Regular character
                    if not current_sequence:
                        sequence_start_time = timestamp
                    current_sequence += key_name
                    last_key_time = timestamp
        
        # Handle any remaining sequence
        if current_sequence:
            sequences.append({
                'timestamp': sequence_start_time,
                'text': current_sequence,
                'end_action': 'incomplete',
                'duration': last_key_time - sequence_start_time if sequence_start_time and last_key_time else 0
            })
        
        return sequences
    
    def create_ultra_detailed_timeline(self, json_path: str) -> str:
        """Create the most detailed timeline possible"""
        
        with open(json_path, 'r') as f:
            data = json.load(f)
        
        session_info = data.get('session_info', {})
        duration = session_info.get('duration', 0)
        
        mouse_interactions = data.get('mouse_interactions', [])
        keyboard_events = data.get('keyboard_events', [])
        app_switches = data.get('app_switches', [])
        
        # Extract all interactions
        clicks = self.extract_all_clicks(mouse_interactions)
        typed_sequences = self.extract_typed_sequences(keyboard_events)
        
        # Combine all events
        all_events = []
        
        # Add clicks
        for click in clicks:
            all_events.append({
                'timestamp': click['timestamp'],
                'type': 'click',
                'action': f"{click['type']} at ({click['position']['x']}, {click['position']['y']}) [duration: {click['duration']:.2f}s]",
                'category': 'mouse'
            })
        
        # Add typed sequences
        for seq in typed_sequences:
            action = f"Type '{seq['text']}'"
            if seq['end_action'] == 'enter':
                action += " + ENTER"
            elif seq['end_action'] == 'tab':
                action += " + TAB"
            elif seq['end_action'] == 'delete':
                action = "DELETE key"
            
            all_events.append({
                'timestamp': seq['timestamp'],
                'type': 'typing',
                'action': action,
                'category': 'keyboard'
            })
        
        # Add app switches
        for switch in app_switches:
            all_events.append({
                'timestamp': switch.get('timestamp', 0),
                'type': 'app_switch',
                'action': f"Switch from {switch.get('from_app')} to {switch.get('to_app')}",
                'category': 'system'
            })
        
        # Sort by timestamp
        all_events.sort(key=lambda x: x['timestamp'])
        
        # Create detailed timeline
        timeline = []
        timeline.append("=== ULTRA-DETAILED COMPLETE INTERACTION TIMELINE ===")
        timeline.append(f"Total Session Duration: {duration:.1f} seconds")
        timeline.append(f"Total Events Captured: {len(all_events)}")
        timeline.append("")
        
        # Group events by time segments for better analysis
        timeline.append("=== CHRONOLOGICAL EVENT SEQUENCE ===")
        
        for i, event in enumerate(all_events):
            timestamp = event['timestamp']
            action = event['action']
            category = event['category']
            
            # Time formatting
            minutes = int(timestamp // 60)
            seconds = timestamp % 60
            time_str = f"{minutes:02d}:{seconds:05.2f}"
            
            # Category icon
            icons = {'mouse': '🖱️', 'keyboard': '⌨️', 'system': '🔄'}
            icon = icons.get(category, '•')
            
            timeline.append(f"[{time_str}] {icon} {action}")
            
            # Add gap indicators for better flow understanding
            if i < len(all_events) - 1:
                next_timestamp = all_events[i + 1]['timestamp']
                gap = next_timestamp - timestamp
                if gap > 3.0:  # Gap > 3 seconds
                    timeline.append(f"         ... pause for {gap:.1f} seconds ...")
        
        timeline.append("")
        timeline.append("=== END-OF-SESSION ANALYSIS ===")
        
        # Focus on the last 30 seconds
        final_events = [e for e in all_events if e['timestamp'] > (duration - 30)]
        if final_events:
            timeline.append("CRITICAL: Final 30 seconds of session:")
            for event in final_events:
                timestamp = event['timestamp']
                action = event['action']
                timeline.append(f"  [{timestamp:.1f}s] {action}")
        
        timeline.append("=" * 70)
        
        return "\n".join(timeline)
    
    def create_field_focused_prompt(self, detailed_timeline: str) -> str:
        """Create prompt specifically focused on field interactions and completeness"""
        
        prompt = f"""You are an expert RPA (Robotic Process Automation) command generator. Your task is to create COMPLETE, FIELD-SPECIFIC RPA commands that capture EVERY SINGLE interaction in this 198.5-second recording session.

CRITICAL REQUIREMENTS:
🎯 CAPTURE EVERYTHING: This session has {detailed_timeline.count('[') - 3} distinct interactions - every one must be reflected in your RPA commands
🎯 FIELD PRECISION: For every typed sequence, identify the EXACT field name being populated
🎯 NO MISSING STEPS: Pay special attention to the END-OF-SESSION section - these final steps are critical
🎯 CLICK ACCURACY: Map every mouse click to its specific UI element and purpose

{detailed_timeline}

VIDEO ANALYSIS INSTRUCTIONS:
1. Watch the video at MAXIMUM detail - correlate every timestamp with visual UI elements
2. For EACH typed sequence, identify which field is being populated
3. For EACH mouse click, identify which button/dropdown/element is being selected
4. Pay EXTREME attention to the final 30 seconds - these often contain critical completion steps
5. Listen to audio for context about field purposes and business logic

FIELD-SPECIFIC OUTPUT REQUIREMENTS:
Your RPA commands must include:

✅ LOGIN PROCESS:
- Username field population
- Password field population  
- Login button click

✅ NAVIGATION:
- Menu selections and navigation clicks
- Screen transitions and confirmations

✅ FIELD POPULATION (BE SPECIFIC):
For each data entry, specify:
- Field name (e.g., "Security field", "Currency dropdown")
- Exact value entered (e.g., "SAGB123456", "ZAR")
- Input method (typing, dropdown selection, etc.)

✅ COMPLETION ACTIONS:
- Process/Submit button clicks
- Confirmation dialog handling
- Final validation steps
- Window closing/navigation

CRITICAL SUCCESS CRITERIA:
1. Every mouse click must correspond to a specific UI action
2. Every typed sequence must specify the target field
3. All dropdown selections must be captured with exact values
4. Final steps (last 30 seconds) must be fully detailed
5. Commands must be executable by someone who can't see the original video

EXAMPLE FIELD-SPECIFIC FORMAT:
"Type 'SAGB123456' into the Security field and press Enter. Click on the Currency dropdown and select 'ZAR'. Type '1000000' into the Amount field. Click the Process button to submit."

Generate comprehensive RPA commands that capture the COMPLETE workflow with field-level precision."""

        return prompt
    
    def process_ultra_precise_session(self, video_path: str, json_path: str) -> str:
        """Process with maximum precision and attention to detail"""
        
        print(f"🎯 Ultra-Precise RPA Processing")
        print(f"📹 Video: {video_path}")
        print(f"📊 JSON:  {json_path}")
        
        # Create ultra-detailed timeline
        print("🔍 Creating ultra-detailed interaction timeline...")
        detailed_timeline = self.create_ultra_detailed_timeline(json_path)
        
        # Show event count
        event_count = detailed_timeline.count('[') - 3  # Subtract header lines
        print(f"📊 Total events captured: {event_count}")
        
        # Create field-focused prompt
        prompt = self.create_field_focused_prompt(detailed_timeline)
        
        # Check video file size
        size_mb = os.path.getsize(video_path) / (1024 * 1024)
        if size_mb > self.config.MAX_FILE_SIZE_MB:
            print(f"❌ Video file too large: {size_mb:.1f} MB")
            return None
        
        print(f"✅ Video size OK: {size_mb:.1f} MB")
        
        # Encode video
        print("🔄 Encoding video with maximum detail preservation...")
        try:
            with open(video_path, 'rb') as f:
                video_bytes = f.read()
            video_base64 = base64.b64encode(video_bytes).decode('utf-8')
        except Exception as e:
            print(f"❌ Error encoding video: {e}")
            return None
        
        # Ultra-precise configuration
        ultra_config = {
            "temperature": 0.05,  # Maximum precision
            "topK": 1,
            "topP": 0.99,
            "maxOutputTokens": 8000,  # Maximum token allowance
            "responseMimeType": "text/plain"
        }
        
        ultra_video_metadata = {
            "fps": 3.0  # Maximum FPS for detailed analysis
        }
        
        # Prepare ultra-precise API request
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inline_data": {
                                "mime_type": "video/mp4",
                                "data": video_base64
                            },
                            "video_metadata": ultra_video_metadata
                        }
                    ]
                }
            ],
            "generationConfig": ultra_config
        }
        
        # Make API request
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.config.GEMINI_MODEL}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }
        
        print("🚀 Sending ultra-precise request to Gemini API...")
        print("⚠️  This may take 3-5 minutes due to maximum detail analysis...")
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=500)  # Extended timeout
            
            if response.status_code == 200:
                result = response.json()
                
                # Extract token usage
                if "usageMetadata" in result:
                    usage = result["usageMetadata"]
                    total_tokens = usage.get('totalTokenCount', 0)
                    estimated_cost = (total_tokens / 1000) * 0.00015
                    print(f"💰 Tokens: {total_tokens:,}, Cost: ${estimated_cost:.6f}")
                
                # Extract ultra-precise RPA commands
                if "candidates" in result and len(result["candidates"]) > 0:
                    candidate = result["candidates"][0]
                    if "content" in candidate and "parts" in candidate["content"]:
                        text_parts = [part.get("text", "") for part in candidate["content"]["parts"]]
                        rpa_commands = "".join(text_parts).strip()
                        
                        # Save ultra-precise commands
                        base_name = os.path.splitext(os.path.basename(video_path))[0]
                        output_name = f"{base_name}_ULTRA_PRECISE_rpa_commands.txt"
                        
                        output_dir = self.config.ensure_output_dir()
                        output_path = os.path.join(output_dir, output_name)
                        
                        with open(output_path, 'w') as f:
                            f.write(f"# ULTRA-PRECISE RPA Commands Generated: {datetime.now()}\n")
                            f.write(f"# Source Video: {os.path.basename(video_path)}\n")
                            f.write(f"# Source JSON: {os.path.basename(json_path)}\n")
                            f.write(f"# Processing Mode: Ultra-Precise Field-Level Analysis\n")
                            f.write(f"# Total Events Captured: {event_count}\n")
                            f.write(f"# Session Duration: 198.5 seconds\n\n")
                            f.write(rpa_commands)
                        
                        print(f"✅ Ultra-precise RPA commands saved to: {output_path}")
                        print(f"\n🎯 Ultra-Precise Commands Preview:")
                        print("-" * 70)
                        preview = rpa_commands[:500] + "..." if len(rpa_commands) > 500 else rpa_commands
                        print(preview)
                        
                        print(f"\n📊 Analysis Summary:")
                        print(f"   • Total events processed: {event_count}")
                        print(f"   • Video analysis: 3.0 FPS")
                        print(f"   • Precision level: Maximum")
                        print(f"   • Field-level accuracy: Enabled")
                        
                        return rpa_commands
                        
            else:
                print(f"❌ API Error: HTTP {response.status_code}")
                try:
                    error_detail = response.json()
                    print(error_detail)
                except:
                    print(response.text)
                
        except Exception as e:
            print(f"❌ Error: {e}")
            
        return None


def main():
    """Main function for ultra-precise processing"""
    print("🎯 Ultra-Precise RPA Processor - Maximum Accuracy Mode")
    print("=" * 70)
    print("This processor captures EVERY interaction with field-level precision")
    print("=" * 70)
    
    # Your specific files
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    try:
        processor = UltraPreciseRpaProcessor()
        commands = processor.process_ultra_precise_session(video_path, json_path)
        
        if commands:
            print(f"\n🎉 SUCCESS: Ultra-precise processing captured EVERY interaction!")
            print(f"📁 Check 'generated_rpa_commands/' for the ULTRA-PRECISE file")
            print(f"🎯 This version should capture all missing final steps")
        else:
            print(f"\n❌ Ultra-precise processing failed")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()