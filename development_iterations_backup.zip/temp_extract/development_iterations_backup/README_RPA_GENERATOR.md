# 🤖 Multimodal RPA Command Generator

A comprehensive system that analyzes recorded video sessions with interaction logs to generate natural language RPA (Robotic Process Automation) commands using Google's Gemini AI.

## 🎯 Overview

This system processes:
- **Video recordings** (MP4 with audio)
- **Interaction logs** (JSON with mouse/keyboard/app switching data)
- **Audio narration** (embedded in video or separate WAV files)

And produces **natural language RPA commands** that can be executed by your RPA engine.

## 📁 File Structure

```
RPA_PROCESS_GEMNI/
├── records/                          # Your recorded sessions
│   ├── enhanced_multiscreen_*.mp4    # Video recordings
│   ├── enhanced_multiscreen_*_interactions.json  # Interaction logs
│   └── ...
├── rpa_commands_sample/              # Example RPA command formats
├── generated_rpa_commands/           # Generated output (auto-created)
├── multimodal_rpa_generator.py       # Full multimodal processor
├── simple_rpa_generator.py           # Single session processor
├── batch_rpa_processor.py            # Batch processing
├── rpa_config.py                     # Configuration settings
└── README_RPA_GENERATOR.md           # This guide
```

## 🚀 Quick Start

### 1. Setup Environment

```bash
# Install dependencies
pip install -r requirements.txt

# Set up your Gemini API key
echo "GEMINI_API_KEY=your_api_key_here" > .env
```

### 2. Check Available Sessions

```bash
python simple_rpa_generator.py
```

This will list all available recording sessions and their sizes.

### 3. Process a Single Session

```bash
# Process by session name
python simple_rpa_generator.py enhanced_multiscreen_20250802_172440

# Or specify files directly
python simple_rpa_generator.py records/video.mp4 records/interactions.json
```

### 4. Batch Process Multiple Sessions

```bash
# Process all sessions
python batch_rpa_processor.py

# Process maximum 3 sessions with 5s delay
python batch_rpa_processor.py 3 5.0
```

## 📊 Components

### 🎬 Simple RPA Generator (`simple_rpa_generator.py`)

**Best for**: Testing, debugging, single session processing

**Features**:
- Interactive session listing
- Single session processing
- Immediate feedback
- Error handling

**Usage**:
```bash
python simple_rpa_generator.py [session_name]
```

### 🔄 Batch RPA Processor (`batch_rpa_processor.py`)

**Best for**: Processing multiple sessions efficiently

**Features**:
- Automatic session discovery
- Progress tracking
- Error recovery
- Summary reporting
- Configurable delays

**Usage**:
```bash
python batch_rpa_processor.py [max_sessions] [delay_seconds]
```

### 🤖 Multimodal RPA Generator (`multimodal_rpa_generator.py`)

**Best for**: Advanced processing with full correlation analysis

**Features**:
- Complete multimodal analysis
- Timestamp synchronization
- Detailed interaction correlation
- Enhanced context awareness

## ⚙️ Configuration

Edit `rpa_config.py` to customize:

```python
class RpaConfig:
    # API Settings
    GEMINI_MODEL = "gemini-1.5-flash"
    MAX_FILE_SIZE_MB = 20
    
    # Video Processing
    VIDEO_FPS = 1.0  # Frames per second for analysis
    
    # Generation Settings
    TEMPERATURE = 0.2
    MAX_OUTPUT_TOKENS = 4000
```

## 📋 Input Requirements

### Video Files
- **Format**: MP4 with audio
- **Size**: Under 20MB (Gemini API limit)
- **Content**: Screen recording of user interactions

### Interaction Logs (JSON)
Required structure:
```json
{
  "session_info": {
    "duration": 16.2,
    "interaction_count": 43,
    "platform": "Darwin"
  },
  "mouse_interactions": [...],
  "keyboard_events": [...],
  "app_switches": [...]
}
```

## 📤 Output Format

Generated RPA commands follow this natural language format:

```text
Login to Murex application using username MUREXFO and password MUREX, 
then click to Login. Then click on the FO_AM group and click Start. 
Once on the main page type 'Revaluation rate curves' and press enter. 
Once on the revaluation rate curves page, you'll see a list of currencies. 
Type 'ANG' into the searchbar and type enter to filter the list...
```

## 🔧 Troubleshooting

### Common Issues

**1. API Key Error**
```
Error: GEMINI_API_KEY not found
```
**Solution**: Set your API key in `.env` file

**2. File Too Large**
```
Warning: File is over 20MB
```
**Solution**: Compress video or use shorter recordings

**3. JSON Load Error**
```
Error loading interaction summary
```
**Solution**: Check if JSON file is properly formatted

**4. Network Timeout**
```
Request timed out
```
**Solution**: Check internet connection, increase timeout in config

### Debug Mode

For debugging, process single sessions first:
```bash
python simple_rpa_generator.py your_session_name
```

## 💰 Cost Estimation

Gemini API costs approximately **$0.00015 per 1K tokens**.

Typical usage:
- **Small session** (1MB video): ~2,000 tokens = $0.0003
- **Medium session** (5MB video): ~10,000 tokens = $0.0015
- **Large session** (15MB video): ~30,000 tokens = $0.0045

## 🎯 Best Practices

### Recording Quality
1. **Clear audio**: Include narration describing actions
2. **Stable video**: Avoid excessive camera movement
3. **Complete workflows**: Record from start to finish
4. **Focused content**: Keep recordings under 2-3 minutes

### Processing Efficiency
1. **Start small**: Process 1-2 sessions first
2. **Batch processing**: Use delays to avoid rate limits
3. **Monitor costs**: Track token usage
4. **Review outputs**: Validate generated commands

### RPA Command Quality
1. **Specific elements**: Commands include precise UI identifiers
2. **Error handling**: Includes popup and error management
3. **Wait conditions**: Proper synchronization points
4. **Business logic**: Maintains workflow context

## 📈 Performance Tips

### Optimize Video Files
```bash
# Compress video to reduce size
ffmpeg -i input.mp4 -vcodec h264 -acodec mp2 output.mp4
```

### Batch Processing Strategy
1. **Sort by size**: Process smaller files first
2. **Use delays**: Prevent API rate limiting
3. **Monitor progress**: Check intermediate results
4. **Handle failures**: Retry failed sessions

## 🔗 Integration

### With Your RPA Engine

The generated commands are designed to be compatible with your existing RPA engine. The natural language format allows for:

1. **Direct execution** if your engine supports natural language
2. **Manual conversion** to specific RPA syntax
3. **Template generation** for repetitive workflows

### Workflow Integration

```python
# Example integration pattern
from simple_rpa_generator import SimpleRpaGenerator

generator = SimpleRpaGenerator()
commands = generator.process_single_session(video_path, json_path)

# Send to your RPA engine
your_rpa_engine.execute_commands(commands)
```

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the configuration settings
3. Test with a single small session first
4. Verify your API key and quota

## 🎉 Success Indicators

You'll know the system is working when:
- ✅ Sessions are discovered automatically
- ✅ Video files are processed without size errors
- ✅ JSON interaction logs are parsed correctly
- ✅ Gemini API returns structured commands
- ✅ Output files are saved in `generated_rpa_commands/`
- ✅ Commands are specific and actionable