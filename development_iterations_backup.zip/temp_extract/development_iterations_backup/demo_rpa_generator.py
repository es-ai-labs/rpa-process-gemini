#!/usr/bin/env python3
"""
Demo RPA Generator

A demonstration script that showcases the RPA command generation system.
This script validates setup and provides guided examples.
"""

import os
import sys
from typing import Optional
from simple_rpa_generator import SimpleRpaGenerator
from batch_rpa_processor import BatchRpaProcessor

def check_environment() -> bool:
    """Check if the environment is properly set up"""
    print("🔍 Checking environment setup...")
    
    # Check for .env file
    if not os.path.exists('.env'):
        print("❌ .env file not found")
        print("   Create a .env file with: GEMINI_API_KEY=your_api_key_here")
        return False
    
    # Check for API key
    from dotenv import load_dotenv
    load_dotenv()
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        print("❌ API key not found in .env file")
        print("   Add: GEMINI_API_KEY=your_api_key_here")
        return False
    
    print(f"✅ API key found: {api_key[:10]}...")
    
    # Check records directory
    if not os.path.exists('records'):
        print("❌ Records directory not found")
        print("   Create 'records/' directory with your recording files")
        return False
    
    # Check for recording files
    video_files = [f for f in os.listdir('records') if f.endswith('.mp4')]
    json_files = [f for f in os.listdir('records') if f.endswith('_interactions.json')]
    
    if not video_files:
        print("❌ No video files found in records/")
        return False
    
    if not json_files:
        print("❌ No interaction JSON files found in records/")
        return False
    
    print(f"✅ Found {len(video_files)} video files and {len(json_files)} interaction logs")
    
    return True

def show_sample_rpa_commands():
    """Display sample RPA commands for reference"""
    print("\n📋 Sample RPA Command Format:")
    print("=" * 60)
    
    sample_commands = [
        "Login to Murex application using username MUREXFO and password MUREX, then click to Login.",
        "Click on the FO_AM group and click Start.",
        "Type 'Revaluation rate curves' and press enter.",
        "Type 'ANG' into the searchbar and press enter to filter the list.",
        "Double click on the ANG option when you see it.",
        "Click on the 'Details' button to bring up config details."
    ]
    
    for i, command in enumerate(sample_commands, 1):
        print(f"{i}. {command}")
    
    print("=" * 60)

def interactive_demo():
    """Run an interactive demonstration"""
    print("\n🎯 Interactive RPA Generator Demo")
    print("=" * 50)
    
    try:
        generator = SimpleRpaGenerator()
        
        # List available sessions
        print("\n📁 Available Recording Sessions:")
        generator.list_available_sessions()
        
        # Get user input
        print("\n📝 Demo Options:")
        print("1. Process a specific session")
        print("2. Run batch processing demo")
        print("3. View configuration")
        print("4. Exit")
        
        while True:
            choice = input("\nEnter your choice (1-4): ").strip()
            
            if choice == '1':
                session_name = input("Enter session name (without .mp4): ").strip()
                if session_name:
                    demo_single_session(generator, session_name)
                break
                
            elif choice == '2':
                demo_batch_processing()
                break
                
            elif choice == '3':
                show_configuration()
                break
                
            elif choice == '4':
                print("👋 Goodbye!")
                return
                
            else:
                print("❌ Invalid choice. Please enter 1-4.")
    
    except KeyboardInterrupt:
        print("\n👋 Demo interrupted by user")
    except Exception as e:
        print(f"❌ Demo error: {e}")

def demo_single_session(generator: SimpleRpaGenerator, session_name: str):
    """Demonstrate single session processing"""
    print(f"\n🎬 Processing session: {session_name}")
    
    video_path = f"records/{session_name}.mp4"
    json_path = f"records/{session_name}_interactions.json"
    
    if not os.path.exists(video_path):
        print(f"❌ Video file not found: {video_path}")
        return
    
    if not os.path.exists(json_path):
        print(f"❌ JSON file not found: {json_path}")
        return
    
    # Show file info
    video_size = os.path.getsize(video_path) / (1024 * 1024)
    print(f"📊 Video size: {video_size:.1f} MB")
    
    # Load and show interaction summary
    summary = generator.load_interaction_summary(json_path)
    print(f"\n{summary}")
    
    # Ask for confirmation
    proceed = input("\n🚀 Proceed with processing? (y/N): ").strip().lower()
    if proceed in ['y', 'yes']:
        print("\n⏳ Processing... (this may take 1-2 minutes)")
        commands = generator.process_single_session(video_path, json_path)
        
        if commands:
            print(f"\n✅ Success! RPA commands generated.")
            print(f"📁 Check the 'generated_rpa_commands/' directory for output.")
        else:
            print(f"\n❌ Failed to generate RPA commands.")
    else:
        print("⏹️  Processing cancelled.")

def demo_batch_processing():
    """Demonstrate batch processing"""
    print(f"\n🔄 Batch Processing Demo")
    
    processor = BatchRpaProcessor()
    sessions = processor.discover_processable_sessions()
    
    if not sessions:
        print("❌ No processable sessions found")
        return
    
    print(f"📊 Found {len(sessions)} processable sessions:")
    for i, session in enumerate(sessions[:5], 1):  # Show first 5
        print(f"   {i}. {session['name']} ({session['size_mb']:.1f} MB)")
    
    if len(sessions) > 5:
        print(f"   ... and {len(sessions) - 5} more")
    
    # Ask how many to process
    try:
        max_sessions = input(f"\nHow many sessions to process? (1-{len(sessions)}, or 'all'): ").strip()
        
        if max_sessions.lower() == 'all':
            max_count = None
        else:
            max_count = int(max_sessions)
            max_count = min(max_count, len(sessions))
    except ValueError:
        max_count = 1
        print(f"Invalid input, processing 1 session")
    
    # Ask for confirmation
    count_text = "all sessions" if max_count is None else f"{max_count} session(s)"
    proceed = input(f"\n🚀 Process {count_text}? (y/N): ").strip().lower()
    
    if proceed in ['y', 'yes']:
        print(f"\n⏳ Starting batch processing...")
        processor.process_all_sessions(max_sessions=max_count, delay_between_sessions=1.0)
    else:
        print("⏹️  Batch processing cancelled.")

def show_configuration():
    """Show current configuration"""
    from rpa_config import RpaConfig
    
    print(f"\n⚙️  Current Configuration:")
    print("=" * 40)
    print(f"Model: {RpaConfig.GEMINI_MODEL}")
    print(f"Max file size: {RpaConfig.MAX_FILE_SIZE_MB} MB")
    print(f"Video FPS: {RpaConfig.VIDEO_FPS}")
    print(f"Temperature: {RpaConfig.TEMPERATURE}")
    print(f"Max output tokens: {RpaConfig.MAX_OUTPUT_TOKENS}")
    print(f"Records directory: {RpaConfig.RECORDS_DIR}")
    print(f"Output directory: {RpaConfig.OUTPUT_DIR}")
    print("=" * 40)

def main():
    """Main demo function"""
    print("🤖 RPA Command Generator - System Demo")
    print("=" * 50)
    print("This demo validates your setup and guides you through")
    print("generating RPA commands from recorded sessions.")
    print("=" * 50)
    
    # Check environment
    if not check_environment():
        print("\n❌ Environment check failed. Please fix the issues above.")
        return
    
    print("✅ Environment check passed!")
    
    # Show sample commands
    show_sample_rpa_commands()
    
    # Run interactive demo
    interactive_demo()

if __name__ == "__main__":
    main()