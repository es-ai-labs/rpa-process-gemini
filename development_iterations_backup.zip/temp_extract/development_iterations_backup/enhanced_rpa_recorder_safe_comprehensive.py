#!/usr/bin/env python3
"""
Enhanced RPA Recorder - SAFE COMPREHENSIVE VERSION
Uses ONLY safe polling (NO pynput listeners) + comprehensive UI tree capture
Based on the stable safe_rpa_recorder.py pattern
"""

import os
import sys
import time
import json
import threading
import traceback
from datetime import datetime
from pathlib import Path
import platform
import wave

# Basic imports
try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
    import cv2
    import numpy as np
    import mss
except ImportError as e:
    print(f"Error importing required libraries: {e}")
    print("Please install requirements: pip install opencv-python mss pillow")
    sys.exit(1)

# Audio imports
try:
    import pyaudio
    AUDIO_AVAILABLE = True
except ImportError:
    AUDIO_AVAILABLE = False
    print("Audio recording not available (pyaudio not installed)")

# Accessibility (safe version only)
try:
    from accessibility_enhanced import create_accessibility_inspector
    ACCESSIBILITY_AVAILABLE = True
except ImportError:
    ACCESSIBILITY_AVAILABLE = False
    print("Enhanced accessibility not available")

PLATFORM = platform.system()

class SafeComprehensiveVideoRecorder:
    """Safe video recorder with audio"""
    
    def __init__(self):
        self.recording = False
        self.output_path = None
        self.fps = 15
        self.record_thread = None
        self.audio_thread = None
        self.video_writer = None
        self.audio_frames = []
        
        # Conservative audio settings
        self.audio_format = pyaudio.paInt16
        self.channels = 1
        self.rate = 22050
        self.chunk = 512
        self.audio = None
        
    def start_recording(self, output_path, fps=15, record_audio=True):
        """Start safe comprehensive recording"""
        if self.recording:
            return False
        
        self.output_path = output_path
        self.fps = fps
        self.recording = True
        self.audio_frames = []
        
        print(f"🎬 Starting safe comprehensive recording: {output_path}")
        
        # Start video recording
        self.record_thread = threading.Thread(target=self._safe_video_loop)
        self.record_thread.daemon = True
        self.record_thread.start()
        
        # Start audio recording
        if AUDIO_AVAILABLE and record_audio:
            try:
                self.audio_thread = threading.Thread(target=self._safe_audio_loop)
                self.audio_thread.daemon = True
                self.audio_thread.start()
                print("🎤 Safe comprehensive audio recording enabled")
            except Exception as e:
                print(f"⚠️ Audio recording failed: {e}")
        
        return True
    
    def _safe_video_loop(self):
        """Safe video recording loop"""
        try:
            with mss.mss() as sct:
                monitor = sct.monitors[0]
                
                # Initialize
                first_screenshot = sct.grab(monitor)
                first_frame = np.array(first_screenshot)
                
                if first_frame.shape[2] == 4:
                    first_frame = cv2.cvtColor(first_frame, cv2.COLOR_BGRA2BGR)
                
                height, width = first_frame.shape[:2]
                fourcc = cv2.VideoWriter_fourcc(*'mp4v')
                self.video_writer = cv2.VideoWriter(self.output_path, fourcc, self.fps, (width, height))
                
                if not self.video_writer.isOpened():
                    print("❌ Video writer initialization failed")
                    return
                
                frame_count = 0
                
                while self.recording:
                    try:
                        screenshot = sct.grab(monitor)
                        frame = np.array(screenshot)
                        
                        if frame.shape[2] == 4:
                            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
                        
                        frame = frame.astype(np.uint8)
                        self.video_writer.write(frame)
                        frame_count += 1
                        
                        time.sleep(1.0 / self.fps)
                        
                    except Exception as e:
                        print(f"Frame error: {e}")
                        time.sleep(0.1)
                
                print(f"📹 Safe video complete: {frame_count} frames")
                
        except Exception as e:
            print(f"Video recording error: {e}")
        finally:
            if self.video_writer:
                self.video_writer.release()
    
    def _safe_audio_loop(self):
        """Safe audio recording loop"""
        try:
            self.audio = pyaudio.PyAudio()
            
            # Find working device
            device_info = None
            for i in range(self.audio.get_device_count()):
                try:
                    info = self.audio.get_device_info_by_index(i)
                    if info['maxInputChannels'] > 0:
                        device_info = info
                        break
                except:
                    continue
            
            if not device_info:
                return
            
            stream = self.audio.open(
                format=self.audio_format,
                channels=self.channels,
                rate=self.rate,
                input=True,
                frames_per_buffer=self.chunk,
                input_device_index=device_info['index']
            )
            
            while self.recording:
                try:
                    data = stream.read(self.chunk, exception_on_overflow=False)
                    self.audio_frames.append(data)
                except:
                    time.sleep(0.01)
            
            stream.stop_stream()
            stream.close()
            
        except Exception as e:
            print(f"Audio error: {e}")
        finally:
            if self.audio:
                self.audio.terminate()
    
    def stop_recording(self):
        """Stop recording safely"""
        if not self.recording:
            return
        
        print("🛑 Stopping safe comprehensive recording...")
        self.recording = False
        
        if self.record_thread:
            self.record_thread.join(timeout=3)
        if self.audio_thread:
            self.audio_thread.join(timeout=2)
        
        if self.audio_frames:
            self._save_audio()
        
        print("✅ Safe comprehensive recording stopped")
    
    def _save_audio(self):
        """Save audio file"""
        try:
            audio_path = self.output_path.replace('.mp4', '_audio.wav')
            with wave.open(audio_path, 'wb') as wf:
                wf.setnchannels(self.channels)
                wf.setsampwidth(pyaudio.get_sample_size(self.audio_format))
                wf.setframerate(self.rate)
                wf.writeframes(b''.join(self.audio_frames))
            print(f"🎵 Audio saved: {audio_path}")
        except Exception as e:
            print(f"Audio save error: {e}")

class SafeComprehensiveInteractionLogger:
    """Safe comprehensive interaction logger using ONLY polling (NO pynput)"""
    
    def __init__(self, accessibility_inspector=None):
        self.inspector = accessibility_inspector
        self.interactions = []
        self.logging = False
        self.log_thread = None
        self.last_position = None
        self.start_time = None
        self.last_ui_capture = 0
        self.last_click_check = 0
        self.click_state = False
        
    def start_logging(self):
        """Start safe comprehensive interaction logging using ONLY polling"""
        if self.logging:
            return True
        
        self.logging = True
        self.interactions = []
        self.start_time = time.time()
        
        self.log_thread = threading.Thread(target=self._safe_comprehensive_polling_loop)
        self.log_thread.daemon = True
        self.log_thread.start()
        
        print("✅ Safe comprehensive interaction logging started (polling only)")
        return True
    
    def _safe_comprehensive_polling_loop(self):
        """Safe comprehensive polling loop with UI tree capture"""
        print("🔍 Starting safe comprehensive polling...")
        sample_count = 0
        
        while self.logging:
            try:
                current_time = time.time()
                current_pos = self._get_safe_mouse_position()
                
                if current_pos != (0, 0):
                    # Detect mouse movement
                    if self.last_position:
                        dx = abs(current_pos[0] - self.last_position[0])
                        dy = abs(current_pos[1] - self.last_position[1])
                        
                        if dx > 20 or dy > 20:  # Movement threshold
                            interaction = {
                                'type': 'mouse_move',
                                'timestamp': self._get_relative_timestamp(),
                                'datetime': datetime.now().isoformat(),
                                'position': {'x': current_pos[0], 'y': current_pos[1]},
                                'movement': {'dx': dx, 'dy': dy},
                                'source': 'safe_comprehensive_polling'
                            }
                            
                            # Add comprehensive UI context
                            interaction['ui_context'] = self._capture_comprehensive_ui_context(current_pos[0], current_pos[1])
                            
                            self._safe_log_interaction(interaction)
                    
                    # Check for potential clicks using safe polling approach
                    if (current_time - self.last_click_check) > 0.05:  # Check every 50ms
                        self._safe_check_for_clicks(current_pos)
                        self.last_click_check = current_time
                    
                    # Periodic comprehensive UI snapshots
                    if (current_time - self.last_ui_capture) > 3.0:  # Every 3 seconds
                        interaction = {
                            'type': 'comprehensive_ui_snapshot',
                            'timestamp': self._get_relative_timestamp(),
                            'datetime': datetime.now().isoformat(),
                            'position': {'x': current_pos[0], 'y': current_pos[1]},
                            'source': 'safe_comprehensive_polling'
                        }
                        
                        # Comprehensive UI context
                        interaction['ui_context'] = self._capture_comprehensive_ui_context(current_pos[0], current_pos[1])
                        
                        self._safe_log_interaction(interaction)
                        self.last_ui_capture = current_time
                    
                    # Periodic position samples
                    elif sample_count % 30 == 0:  # Every 3 seconds at 10fps
                        interaction = {
                            'type': 'position_sample',
                            'timestamp': self._get_relative_timestamp(),
                            'datetime': datetime.now().isoformat(),
                            'position': {'x': current_pos[0], 'y': current_pos[1]},
                            'source': 'safe_comprehensive_polling'
                        }
                        
                        # Basic UI context
                        interaction['ui_context'] = self._capture_comprehensive_ui_context(current_pos[0], current_pos[1])
                        
                        self._safe_log_interaction(interaction)
                    
                    self.last_position = current_pos
                
                sample_count += 1
                time.sleep(0.1)  # 10 FPS polling
                
            except Exception as e:
                print(f"⚠️ Safe polling error: {e}")
                time.sleep(0.5)
        
        print(f"🛑 Safe comprehensive polling stopped. Logged {len(self.interactions)} interactions")
    
    def _get_safe_mouse_position(self):
        """Get mouse position safely using macOS APIs"""
        try:
            if PLATFORM == "Darwin":
                from Cocoa import NSEvent
                from AppKit import NSScreen
                point = NSEvent.mouseLocation()
                screen_height = NSScreen.mainScreen().frame().size.height
                return (int(point.x), int(screen_height - point.y))
            else:
                import pyautogui
                return pyautogui.position()
        except:
            return (0, 0)
    
    def _safe_check_for_clicks(self, current_pos):
        """Safe click detection using mouse button state polling"""
        try:
            if PLATFORM == "Darwin":
                from Cocoa import NSEvent
                
                # Check current mouse button state safely
                current_mouse_down = NSEvent.pressedMouseButtons()
                
                # Detect click events
                if current_mouse_down > 0 and not self.click_state:
                    # Mouse pressed
                    self.click_state = True
                    interaction = {
                        'type': 'mouse_press',
                        'timestamp': self._get_relative_timestamp(),
                        'datetime': datetime.now().isoformat(),
                        'position': {'x': current_pos[0], 'y': current_pos[1]},
                        'button': 'left',
                        'source': 'safe_click_detection'
                    }
                    
                    # Add comprehensive UI context for clicks
                    interaction['ui_context'] = self._capture_comprehensive_ui_context(current_pos[0], current_pos[1])
                    
                    self._safe_log_interaction(interaction)
                    
                elif current_mouse_down == 0 and self.click_state:
                    # Mouse released
                    self.click_state = False
                    interaction = {
                        'type': 'mouse_release',
                        'timestamp': self._get_relative_timestamp(),
                        'datetime': datetime.now().isoformat(),
                        'position': {'x': current_pos[0], 'y': current_pos[1]},
                        'button': 'left',
                        'source': 'safe_click_detection'
                    }
                    
                    # Add comprehensive UI context for releases
                    interaction['ui_context'] = self._capture_comprehensive_ui_context(current_pos[0], current_pos[1])
                    
                    self._safe_log_interaction(interaction)
        except Exception as e:
            # Silently handle click detection errors
            pass
    
    def _capture_comprehensive_ui_context(self, x, y):
        """Capture comprehensive UI context safely"""
        ui_context = {
            'app_context': self._get_safe_app_context(),
            'window_context': self._get_safe_window_context(),
            'accessibility': None,
            'ui_tree': None
        }
        
        # Get accessibility information safely
        if self.inspector:
            try:
                accessibility_info = self.inspector.get_element_at_point(x, y)
                if accessibility_info and not accessibility_info.get('error'):
                    ui_context['accessibility'] = accessibility_info
                    
                    # Extract comprehensive UI tree
                    ui_context['ui_tree'] = self._extract_comprehensive_ui_tree(accessibility_info)
            except Exception as e:
                ui_context['accessibility_error'] = str(e)
        
        return ui_context
    
    def _extract_comprehensive_ui_tree(self, accessibility_info):
        """Extract comprehensive UI tree information"""
        try:
            accessibility_data = accessibility_info.get('accessibility', {})
            
            ui_tree = {
                'current_element': {
                    'role': self._safe_get_value(accessibility_data, 'AXRole'),
                    'role_description': self._safe_get_value(accessibility_data, 'AXRoleDescription'),
                    'title': self._safe_get_value(accessibility_data, 'AXTitle'),
                    'description': self._safe_get_value(accessibility_data, 'AXDescription'),
                    'value': self._safe_get_value(accessibility_data, 'AXValue'),
                    'identifier': self._safe_get_value(accessibility_data, 'AXIdentifier'),
                    'help': self._safe_get_value(accessibility_data, 'AXHelp'),
                    'placeholder': self._safe_get_value(accessibility_data, 'AXPlaceholderValue'),
                    'position': self._safe_get_value(accessibility_data, 'AXPosition'),
                    'size': self._safe_get_value(accessibility_data, 'AXSize'),
                    'enabled': self._safe_get_value(accessibility_data, 'AXEnabled'),
                    'focused': self._safe_get_value(accessibility_data, 'AXFocused'),
                    'selected': self._safe_get_value(accessibility_data, 'AXSelected'),
                    'children_count': len(self._safe_get_value(accessibility_data, 'AXChildren', []))
                },
                'selectors': accessibility_info.get('selector_suggestions', []),
                'element_hierarchy': self._build_element_hierarchy(accessibility_data),
                'interaction_hints': self._generate_interaction_hints(accessibility_data)
            }
            
            return ui_tree
        except Exception as e:
            return {'error': f'UI tree extraction failed: {e}'}
    
    def _safe_get_value(self, data, key, default=''):
        """Safely get value from accessibility data"""
        try:
            value = data.get(key, default)
            # Convert to string if it's a complex object
            if value and not isinstance(value, (str, int, float, bool, list, dict)):
                return str(value)
            return value
        except:
            return default
    
    def _build_element_hierarchy(self, accessibility_data):
        """Build element hierarchy information"""
        try:
            hierarchy = {
                'parent': self._safe_get_value(accessibility_data, 'AXParent'),
                'children': [],
                'siblings_count': 0
            }
            
            # Get children information
            children = self._safe_get_value(accessibility_data, 'AXChildren', [])
            if children:
                for i, child in enumerate(children[:5]):  # Limit to first 5 children
                    child_info = {
                        'index': i,
                        'role': str(child).split('AX')[1].split(' ')[0] if 'AX' in str(child) else 'Unknown'
                    }
                    hierarchy['children'].append(child_info)
            
            return hierarchy
        except Exception as e:
            return {'error': f'Hierarchy extraction failed: {e}'}
    
    def _generate_interaction_hints(self, accessibility_data):
        """Generate interaction hints based on element properties"""
        try:
            hints = []
            
            role = self._safe_get_value(accessibility_data, 'AXRole')
            enabled = self._safe_get_value(accessibility_data, 'AXEnabled')
            
            if role == 'AXButton' and enabled:
                hints.append('clickable_button')
            elif role == 'AXTextField':
                hints.append('text_input')
            elif role == 'AXLink':
                hints.append('clickable_link')
            elif role == 'AXPopUpButton':
                hints.append('dropdown_menu')
            elif role == 'AXMenuButton':
                hints.append('menu_trigger')
            elif role == 'AXCheckBox':
                hints.append('checkable')
            elif role == 'AXRadioButton':
                hints.append('selectable')
            
            return hints
        except:
            return []
    
    def _get_safe_app_context(self):
        """Get application context safely"""
        try:
            if PLATFORM == "Darwin":
                from AppKit import NSWorkspace
                workspace = NSWorkspace.sharedWorkspace()
                active_app = workspace.activeApplication()
                return {
                    'name': active_app.get('NSApplicationName', 'Unknown'),
                    'bundle_id': active_app.get('NSApplicationBundleIdentifier', 'Unknown'),
                    'pid': active_app.get('NSApplicationProcessIdentifier', 0)
                }
        except:
            pass
        return {'name': 'Unknown', 'bundle_id': 'Unknown', 'pid': 0}
    
    def _get_safe_window_context(self):
        """Get window context safely"""
        try:
            if PLATFORM == "Darwin":
                from AppKit import NSWorkspace
                from Quartz import CGWindowListCopyWindowInfo, kCGWindowListOptionOnScreenOnly, kCGNullWindowID
                
                workspace = NSWorkspace.sharedWorkspace()
                active_app = workspace.activeApplication()
                
                window_list = CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly, kCGNullWindowID)
                
                active_windows = []
                if window_list:
                    for window in window_list[:3]:  # Limit to top 3 windows
                        if window.get('kCGWindowOwnerPID') == active_app.get('NSApplicationProcessIdentifier'):
                            active_windows.append({
                                'name': str(window.get('kCGWindowName', '')),
                                'bounds': dict(window.get('kCGWindowBounds', {})),
                                'layer': int(window.get('kCGWindowLayer', 0))
                            })
                
                return {
                    'active_windows': active_windows,
                    'window_count': len(active_windows)
                }
        except:
            pass
        return {'error': 'Window context unavailable'}
    
    def _get_relative_timestamp(self):
        """Get relative timestamp"""
        try:
            return time.time() - self.start_time if self.start_time else 0
        except:
            return 0
    
    def _safe_log_interaction(self, interaction):
        """Safely log interaction"""
        try:
            self.interactions.append(interaction)
            
            if len(self.interactions) % 25 == 0:
                print(f"📝 Logged {len(self.interactions)} safe comprehensive interactions...")
                
        except Exception as e:
            print(f"⚠️ Safe interaction log error: {e}")
    
    def stop_logging(self):
        """Stop safe comprehensive logging"""
        if not self.logging:
            return
        
        self.logging = False
        
        if self.log_thread:
            self.log_thread.join(timeout=3)
        
        print(f"✅ Safe comprehensive interaction logging stopped: {len(self.interactions)} total")
    
    def _serialize_for_json(self, obj):
        """Convert objects to JSON-serializable format"""
        if obj is None:
            return None
        elif isinstance(obj, (str, int, float, bool)):
            return obj
        elif isinstance(obj, dict):
            return {k: self._serialize_for_json(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [self._serialize_for_json(item) for item in obj]
        else:
            return str(obj)
    
    def save_interactions(self, output_path):
        """Save comprehensive interaction data safely"""
        try:
            # Serialize all interactions
            serialized_interactions = []
            for interaction in self.interactions:
                serialized_interaction = self._serialize_for_json(interaction)
                serialized_interactions.append(serialized_interaction)
            
            session_data = {
                'session_info': {
                    'platform': PLATFORM,
                    'start_time': datetime.now().isoformat(),
                    'duration': self._get_relative_timestamp(),
                    'interaction_count': len(serialized_interactions),
                    'capture_method': 'safe_comprehensive_polling',
                    'features': {
                        'mouse_tracking': True,
                        'click_detection': True,
                        'keyboard_tracking': False,  # Disabled for safety
                        'ui_tree_capture': True,
                        'accessibility_inspection': ACCESSIBILITY_AVAILABLE,
                        'app_context': True,
                        'window_context': True,
                        'comprehensive_logging': True,
                        'crash_protection': True
                    }
                },
                'interactions': serialized_interactions
            }
            
            with open(output_path, 'w') as f:
                json.dump(session_data, f, indent=2)
            
            print(f"💾 Safe comprehensive interactions saved: {output_path}")
            print(f"📊 Interaction breakdown:")
            
            # Log interaction type breakdown
            type_counts = {}
            for interaction in serialized_interactions:
                interaction_type = interaction.get('type', 'unknown')
                type_counts[interaction_type] = type_counts.get(interaction_type, 0) + 1
            
            for interaction_type, count in type_counts.items():
                print(f"   {interaction_type}: {count}")
            
            return True
            
        except Exception as e:
            print(f"❌ Error saving safe comprehensive interactions: {e}")
            traceback.print_exc()
            return False

class SafeComprehensiveRPARecorderApp:
    """Safe comprehensive RPA Recorder GUI"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Enhanced RPA Recorder (Safe Comprehensive)")
        self.root.geometry("650x550")
        
        # Initialize components safely
        self.accessibility_inspector = None
        if ACCESSIBILITY_AVAILABLE:
            try:
                self.accessibility_inspector = create_accessibility_inspector()
            except Exception as e:
                print(f"⚠️ Accessibility inspector failed: {e}")
        
        self.video_recorder = SafeComprehensiveVideoRecorder()
        self.interaction_logger = SafeComprehensiveInteractionLogger(self.accessibility_inspector)
        
        # State
        self.recording = False
        self.output_directory = str(Path.cwd() / "records")
        Path(self.output_directory).mkdir(exist_ok=True)
        
        self.setup_gui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
    
    def setup_gui(self):
        """Setup safe comprehensive GUI"""
        # Title
        title_label = ttk.Label(self.root, text="Enhanced RPA Recorder", font=("Arial", 16, "bold"))
        title_label.pack(pady=10)
        
        subtitle_label = ttk.Label(self.root, text="Safe Comprehensive Edition - No Crashes, Full UI Tree Capture", 
                                 font=("Arial", 10), foreground="darkgreen")
        subtitle_label.pack(pady=(0, 10))
        
        # Status
        self.status_var = tk.StringVar(value="Ready for safe comprehensive recording")
        status_label = ttk.Label(self.root, textvariable=self.status_var, font=("Arial", 11, "bold"))
        status_label.pack(pady=5)
        
        # Output directory
        dir_frame = ttk.Frame(self.root)
        dir_frame.pack(fill=tk.X, padx=20, pady=10)
        
        ttk.Label(dir_frame, text="Output Directory:").pack(anchor=tk.W)
        self.dir_var = tk.StringVar(value=self.output_directory)
        dir_entry = ttk.Entry(dir_frame, textvariable=self.dir_var, state="readonly")
        dir_entry.pack(fill=tk.X, side=tk.LEFT, expand=True)
        ttk.Button(dir_frame, text="Browse", command=self.browse_directory).pack(side=tk.RIGHT, padx=(5, 0))
        
        # Recording options
        options_frame = ttk.LabelFrame(self.root, text="Safe Comprehensive Recording Options")
        options_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Video options
        self.video_enabled = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame, text="Record Video", variable=self.video_enabled).pack(anchor=tk.W, pady=2)
        
        fps_frame = ttk.Frame(options_frame)
        fps_frame.pack(fill=tk.X, pady=2)
        ttk.Label(fps_frame, text="FPS:").pack(side=tk.LEFT)
        self.fps_var = tk.StringVar(value="15")
        ttk.Entry(fps_frame, textvariable=self.fps_var, width=5).pack(side=tk.LEFT, padx=(5, 0))
        
        # Audio options
        self.audio_enabled = tk.BooleanVar(value=AUDIO_AVAILABLE)
        audio_cb = ttk.Checkbutton(options_frame, text="Record Audio", variable=self.audio_enabled)
        audio_cb.pack(anchor=tk.W, pady=2)
        if not AUDIO_AVAILABLE:
            audio_cb.configure(state="disabled")
        
        # Safe interaction options
        interaction_frame = ttk.LabelFrame(self.root, text="Safe Comprehensive Interaction Logging")
        interaction_frame.pack(fill=tk.X, padx=20, pady=10)
        
        self.interaction_enabled = tk.BooleanVar(value=True)
        ttk.Checkbutton(interaction_frame, text="Track Mouse & Clicks (Safe Polling Only)", 
                       variable=self.interaction_enabled).pack(anchor=tk.W, pady=2)
        
        self.ui_tree_enabled = tk.BooleanVar(value=ACCESSIBILITY_AVAILABLE)
        ui_tree_cb = ttk.Checkbutton(interaction_frame, text="Capture Comprehensive UI Tree", variable=self.ui_tree_enabled)
        ui_tree_cb.pack(anchor=tk.W, pady=2)
        if not ACCESSIBILITY_AVAILABLE:
            ui_tree_cb.configure(state="disabled")
        
        # Safety features
        safety_frame = ttk.LabelFrame(self.root, text="Safety & Comprehensive Features")
        safety_frame.pack(fill=tk.X, padx=20, pady=10)
        
        safety_text = "• NO event listeners (100% crash-free)\n• Safe polling-based mouse & click detection\n• Full UI element tree capture\n• Accessibility hierarchy logging\n• App & window context tracking\n• Interaction hints generation"
        ttk.Label(safety_frame, text=safety_text, font=("Arial", 9), foreground="darkgreen").pack(pady=5)
        
        # Control buttons
        button_frame = ttk.Frame(self.root)
        button_frame.pack(pady=20)
        
        self.record_button = ttk.Button(button_frame, text="Start Safe Comprehensive Recording", command=self.toggle_recording)
        self.record_button.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(button_frame, text="Open Output Folder", command=self.open_output_folder).pack(side=tk.LEFT, padx=5)
        
        # Status
        caps_text = f"Status: Video✅ Audio{'✅' if AUDIO_AVAILABLE else '❌'} SafeClicks✅ UITree{'✅' if ACCESSIBILITY_AVAILABLE else '❌'} CrashProof🛡️"
        ttk.Label(self.root, text=caps_text, font=("Arial", 8), foreground="blue").pack(pady=(5, 10))
    
    def browse_directory(self):
        """Browse for output directory"""
        directory = filedialog.askdirectory(initialdir=self.output_directory)
        if directory:
            self.output_directory = directory
            self.dir_var.set(directory)
    
    def toggle_recording(self):
        """Toggle recording state"""
        if self.recording:
            self.stop_recording()
        else:
            self.start_recording()
    
    def start_recording(self):
        """Start safe comprehensive recording"""
        try:
            if self.recording:
                return
            
            self.recording = True
            self.record_button.configure(text="Stop Recording")
            self.status_var.set("🔴 SAFE COMPREHENSIVE RECORDING...")
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            base_path = Path(self.output_directory) / f"safe_comprehensive_recording_{timestamp}"
            
            started_components = []
            
            # Start video recording
            if self.video_enabled.get():
                try:
                    fps = max(5, min(30, int(self.fps_var.get() or 15)))
                    video_path = str(base_path) + ".mp4"
                    record_audio = self.audio_enabled.get() and AUDIO_AVAILABLE
                    
                    success = self.video_recorder.start_recording(video_path, fps, record_audio)
                    if success:
                        if record_audio:
                            started_components.append("safe-video+audio")
                        else:
                            started_components.append("safe-video")
                except Exception as e:
                    print(f"❌ Video recording failed: {e}")
                    messagebox.showerror("Error", f"Video recording failed: {e}")
                    self.recording = False
                    self.record_button.configure(text="Start Safe Comprehensive Recording")
                    self.status_var.set("Ready for safe comprehensive recording")
                    return
            
            # Start safe comprehensive interaction logging
            if self.interaction_enabled.get():
                try:
                    success = self.interaction_logger.start_logging()
                    if success:
                        components = ["safe-mouse-tracking"]
                        if self.ui_tree_enabled.get() and ACCESSIBILITY_AVAILABLE:
                            components.append("comprehensive-ui-tree")
                        started_components.append(f"safe-interactions({'+'.join(components)})")
                except Exception as e:
                    print(f"⚠️ Safe interaction logging failed: {e}")
            
            if started_components:
                print(f"🎬 Safe comprehensive recording started: {', '.join(started_components)}")
                messagebox.showinfo("Recording Started", 
                                  f"Safe comprehensive recording started!\n\nComponents: {', '.join(started_components)}\n\nNo crashes, full UI tree capture for Gemini!")
            else:
                self.recording = False
                self.record_button.configure(text="Start Safe Comprehensive Recording")
                self.status_var.set("Ready for safe comprehensive recording")
                messagebox.showerror("Error", "No recording components could be started")
            
        except Exception as e:
            print(f"❌ Recording start failed: {e}")
            messagebox.showerror("Error", f"Failed to start recording: {e}")
            self.recording = False
            self.record_button.configure(text="Start Safe Comprehensive Recording")
            self.status_var.set("Ready for safe comprehensive recording")
    
    def stop_recording(self):
        """Stop safe comprehensive recording"""
        try:
            if not self.recording:
                return
            
            self.recording = False
            self.record_button.configure(text="Start Safe Comprehensive Recording")
            self.status_var.set("⏳ Saving comprehensive data safely...")
            
            stopped_components = []
            
            # Stop video recording
            try:
                self.video_recorder.stop_recording()
                stopped_components.append("safe-video+audio")
            except Exception as e:
                print(f"⚠️ Error stopping video: {e}")
            
            # Stop safe interaction logging and save
            try:
                self.interaction_logger.stop_logging()
                if len(self.interaction_logger.interactions) > 0:
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    interaction_path = Path(self.output_directory) / f"safe_comprehensive_interactions_{timestamp}.json"
                    success = self.interaction_logger.save_interactions(str(interaction_path))
                    if success:
                        stopped_components.append("safe-comprehensive-interactions")
            except Exception as e:
                print(f"⚠️ Error saving safe interactions: {e}")
            
            self.status_var.set("✅ Safe comprehensive recording saved!")
            print(f"🛑 Safe comprehensive recording completed: {', '.join(stopped_components)}")
            messagebox.showinfo("Recording Complete", 
                              f"Safe comprehensive recording saved!\n\nComponents: {', '.join(stopped_components)}\n\nFull workflow captured safely for Gemini processing!")
            
        except Exception as e:
            print(f"❌ Error stopping recording: {e}")
            self.status_var.set("❌ Error during stop")
            messagebox.showerror("Error", f"Error stopping recording: {e}")
    
    def open_output_folder(self):
        """Open output folder"""
        try:
            if PLATFORM == "Darwin":
                os.system(f'open "{self.output_directory}"')
            elif PLATFORM == "Windows":
                os.system(f'explorer "{self.output_directory}"')
            else:
                os.system(f'xdg-open "{self.output_directory}"')
        except Exception as e:
            print(f"Error opening folder: {e}")
    
    def on_closing(self):
        """Handle application closing"""
        try:
            if self.recording:
                if messagebox.askokcancel("Quit", "Safe comprehensive recording in progress. Stop and quit?"):
                    self.stop_recording()
                    time.sleep(1)
                    self.root.destroy()
            else:
                self.root.destroy()
        except Exception as e:
            print(f"Error during closing: {e}")
            self.root.destroy()
    
    def run(self):
        """Run safe comprehensive application"""
        try:
            self.root.mainloop()
        except Exception as e:
            print(f"GUI error: {e}")

def main():
    """Main entry point"""
    print("🛡️ Starting Enhanced RPA Recorder (Safe Comprehensive Version)...")
    print(f"Platform: {PLATFORM}")
    print(f"Audio Available: {AUDIO_AVAILABLE}")
    print(f"UI Tree Capture Available: {ACCESSIBILITY_AVAILABLE}")
    print("🎯 Safe comprehensive workflow logging for Gemini processing")
    print("🚫 NO pynput listeners - 100% crash-free polling approach")
    
    if not AUDIO_AVAILABLE:
        print("⚠️ Install pyaudio for audio recording: pip install pyaudio")
    
    try:
        app = SafeComprehensiveRPARecorderApp()
        app.run()
    except KeyboardInterrupt:
        print("\n👋 Safe Comprehensive RPA Recorder stopped by user")
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    main()