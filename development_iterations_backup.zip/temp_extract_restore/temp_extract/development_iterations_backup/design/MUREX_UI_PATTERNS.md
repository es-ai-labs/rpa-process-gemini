# Murex UI Patterns - Enhanced RPA Generator

## 🎯 Overview

The Complete Video Processor now includes detailed Murex-specific UI navigation patterns that ensure generated RPA commands follow the exact interaction methods required by Murex applications.

## 📋 Embedded Murex UI Knowledge

### **File/Screen Access**
- Access screens via top bar menu dropdown
- Pattern: Click dropdown → Click again to open target screen
- Format: `"Click on [Menu] in the top bar, then click [Submenu] to access [Screen]"`

### **Dropdown/List Access Mechanism**
- **Field Structure**: Label (left) + Input (middle) + Dropdown icon (far right)
- **Visual Indicator**: Three dots with lines icon
- **Access Methods**: Click dropdown icon OR press Spacebar
- **Format**: `"Locate the '[Field Label]' field. Click the dropdown icon (three dots) on the far right of the field"`

### **List Selection Mechanisms**

#### **Single-Column Lists**
1. Search for string in search bar
2. Press Enter
3. Double-click on found item
- **Format**: `"In the dropdown list, type '[Search Term]' in the search bar and press Enter. Double-click on '[Item]' to select it."`

#### **Multi-Column Lists**
1. Find and click the 'Label' column header
2. Type search query in top input field
3. Double-click on result
- **Format**: `"In the multi-column list, click on the 'Label' column header. Type '[Search Term]' in the top search input field. Double-click on '[Item]' to select it."`

#### **Tree Structure Lists**
1. Press Ctrl+F to enable search
2. Type search text and press Enter
3. Double-click to select
- **Format**: `"In the tree structure list, press Ctrl+F to enable search. Type '[Search Term]' and press Enter. Double-click on '[Item]' to select it."`

## 🎯 Generated RPA Command Format

### **Example Output Structure**
```
1. **Login to Murex:** Login to Murex application using username MUREXFO and password MUREX, then click Login button.

2. **Access Module:** Click on the FO_AM group and click Start.

3. **Navigate to Function:** Click on 'Tools' in the top bar menu, then click 'Revaluation rate curves' to access the function.

4. **Select Currency Field:** Locate the 'Currency' field (label on left, input in middle, dropdown icon on far right). Click the dropdown icon (three dots with lines) on the far right of the field to open the currency list.

5. **Search and Select Currency:** In the dropdown list, type 'ANG' in the search bar and press Enter. Double-click on 'ANG' to select it.

6. **Access Bond Type Field:** Locate the 'Bond type' field. Click the dropdown icon (three dots with lines) on the far right of the field to open the list.

7. **Select Industry:** In the multi-column list, click on the 'Label' column header. Type 'Insurance' in the top search input field. Double-click on 'Insurance' to select it.

8. **Navigate Tree Structure:** For the 'Category' field, click the dropdown icon to open the tree structure list. Press Ctrl+F to enable search. Type 'Government Bonds' and press Enter. Double-click on 'Government Bonds' to select it.
```

## 🔍 Quality Validation

The system now validates for:
- ✅ **Login sequence** present
- ✅ **Completion state** captured
- ✅ **Adequate detail level** (400+ chars minimum)
- ✅ **Murex UI patterns** (3+ specific patterns detected)
- ✅ **Structured format** (numbered steps + headers)

### **Detected Murex Patterns**
- "dropdown icon"
- "three dots"
- "double-click"
- "locate the"
- "field (label on left"
- "top bar"
- "ctrl+f"
- "search bar and press enter"

## 🚀 Benefits

1. **RPA Engine Compatibility**: Commands match exactly what your RPA engine expects
2. **Murex-Specific**: Uses actual Murex UI interaction patterns
3. **Detailed Instructions**: No ambiguity about how to interact with elements
4. **Consistent Format**: Structured, numbered steps with descriptive headers
5. **Quality Assured**: Validation ensures all patterns are followed

## 📁 Usage

```bash
python complete_video_processor.py your_video.mp4 your_interactions.json
```

The system will now generate RPA commands that include the precise Murex UI navigation patterns your engine needs for reliable execution.