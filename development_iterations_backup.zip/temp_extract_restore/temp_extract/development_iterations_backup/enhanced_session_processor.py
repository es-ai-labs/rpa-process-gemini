#!/usr/bin/env python3
"""
Enhanced Session Processor

Processes long recording sessions more thoroughly by:
1. Using enhanced prompting for complete workflow capture
2. Analyzing interaction timeline in detail
3. Ensuring no steps are missed at the end
"""

import json
from typing import List, Dict, Tuple
from simple_rpa_generator import SimpleRpaGenerator
from rpa_config import RpaConfig

class EnhancedSessionProcessor(SimpleRpaGenerator):
    """Enhanced processor for complete session analysis"""
    
    def create_detailed_interaction_analysis(self, json_path: str) -> str:
        """Create detailed analysis of all interactions throughout the session"""
        
        with open(json_path, 'r') as f:
            data = json.load(f)
        
        session_info = data.get('session_info', {})
        duration = session_info.get('duration', 0)
        
        # Analyze different types of interactions
        mouse_interactions = data.get('mouse_interactions', [])
        keyboard_events = data.get('keyboard_events', [])
        app_switches = data.get('app_switches', [])
        typing_sessions = data.get('typing_sessions', [])
        
        analysis = []
        analysis.append("=== DETAILED SESSION ANALYSIS ===")
        analysis.append(f"Total Duration: {duration:.1f} seconds")
        analysis.append(f"Mouse Actions: {len(mouse_interactions)}")
        analysis.append(f"Keyboard Events: {len(keyboard_events)}")
        analysis.append(f"App Switches: {len(app_switches)}")
        analysis.append("")
        
        # Extract key clicks (non-movement mouse events)
        clicks = [m for m in mouse_interactions if m.get('type') in ['left_click', 'right_click', 'double_click']]
        if clicks:
            analysis.append("=== KEY MOUSE CLICKS ===")
            for i, click in enumerate(clicks):
                timestamp = click.get('timestamp', 0)
                click_type = click.get('type', 'click')
                pos = click.get('position', {})
                analysis.append(f"[{timestamp:.1f}s] {click_type} at ({pos.get('x')}, {pos.get('y')})")
            analysis.append("")
        
        # Extract typing sessions
        if typing_sessions:
            analysis.append("=== TYPING SESSIONS ===")
            for i, session in enumerate(typing_sessions):
                start_time = session.get('start_time', 0)
                final_text = session.get('final_text', '')
                analysis.append(f"[{start_time:.1f}s] Typed: '{final_text}'")
            analysis.append("")
        
        # Extract app switches
        if app_switches:
            analysis.append("=== APPLICATION SWITCHES ===")
            for switch in app_switches:
                timestamp = switch.get('timestamp', 0)
                from_app = switch.get('from_app', 'Unknown')
                to_app = switch.get('to_app', 'Unknown')
                analysis.append(f"[{timestamp:.1f}s] {from_app} → {to_app}")
            analysis.append("")
        
        # Create timeline of significant events
        all_events = []
        
        # Add significant keyboard events
        for event in keyboard_events:
            if event.get('is_special') or event.get('key_name') in ['Return', 'Tab', 'Delete', 'Space']:
                all_events.append({
                    'timestamp': event.get('timestamp', 0),
                    'type': 'keyboard',
                    'action': f"Key: {event.get('key_name', 'Unknown')}"
                })
        
        # Add clicks
        for click in clicks:
            all_events.append({
                'timestamp': click.get('timestamp', 0),
                'type': 'click',
                'action': f"{click.get('type', 'click')} at ({click.get('position', {}).get('x')}, {click.get('position', {}).get('y')})"
            })
        
        # Add typing
        for session in typing_sessions:
            all_events.append({
                'timestamp': session.get('start_time', 0),
                'type': 'typing',
                'action': f"Typed: '{session.get('final_text', '')}'"
            })
        
        # Sort by timestamp and create timeline
        all_events.sort(key=lambda x: x['timestamp'])
        
        if all_events:
            analysis.append("=== COMPLETE INTERACTION TIMELINE ===")
            for event in all_events:
                timestamp = event['timestamp']
                action = event['action']
                analysis.append(f"[{timestamp:.1f}s] {action}")
        
        analysis.append("=" * 50)
        return "\n".join(analysis)
    
    def create_comprehensive_prompt(self, interaction_analysis: str) -> str:
        """Create comprehensive prompt that ensures complete workflow capture"""
        
        prompt = f"""You are an expert RPA (Robotic Process Automation) command generator. Analyze this COMPLETE multimodal recording session to create comprehensive RPA commands that capture the ENTIRE workflow from start to finish.

CRITICAL REQUIREMENTS:
1. This session is {interaction_analysis.split('Total Duration: ')[1].split(' seconds')[0]} seconds long - ensure you capture ALL activities throughout the ENTIRE session
2. Do NOT stop early - include ALL steps until the final completion
3. Pay special attention to the END of the session to capture final steps
4. Include ALL typing, clicking, navigation, and confirmation steps

{interaction_analysis}

VIDEO + AUDIO ANALYSIS INSTRUCTIONS:
1. Watch the COMPLETE video from start to finish
2. Listen to ALL audio narration throughout the entire session
3. Correlate visual actions with the detailed interaction timeline above
4. Identify ALL business processes and sub-processes performed
5. Note EVERY UI element interaction (buttons, fields, menus, dialogs, confirmations)
6. Capture ALL data entry, selections, and confirmations
7. Include ALL final steps, confirmations, and completion actions

RPA COMMAND GENERATION REQUIREMENTS:
Generate natural language RPA commands that include EVERY step from the session:

CRITICAL: Your output must capture the COMPLETE workflow including:
- Initial login and navigation
- ALL data entry and field population
- ALL dropdown selections and menu choices  
- ALL intermediate confirmations and dialog handling
- ALL final steps, confirmations, and completion actions
- Any error handling or retry actions
- Final confirmation or completion screens

The commands should be detailed enough that someone could replicate the EXACT same process step-by-step without missing any actions.

ENSURE COMPLETENESS: Do not truncate or summarize - include ALL steps from start to final completion."""

        return prompt
    
    def process_enhanced_session(self, video_path: str, json_path: str) -> str:
        """Process session with enhanced analysis for completeness"""
        
        print(f"🔍 Enhanced processing of session...")
        print(f"📹 Video: {video_path}")
        print(f"📊 JSON:  {json_path}")
        
        # Create detailed interaction analysis
        print("📋 Creating detailed interaction analysis...")
        interaction_analysis = self.create_detailed_interaction_analysis(json_path)
        
        # Show summary
        lines = interaction_analysis.split('\n')
        duration_line = [l for l in lines if 'Total Duration:' in l][0]
        print(f"⏱️  {duration_line}")
        
        # Create enhanced prompt
        prompt = self.create_comprehensive_prompt(interaction_analysis)
        
        # Check video file size
        import os
        size_mb = os.path.getsize(video_path) / (1024 * 1024)
        if size_mb > self.config.MAX_FILE_SIZE_MB:
            print(f"❌ Video file too large: {size_mb:.1f} MB")
            return None
        
        print(f"✅ Video size OK: {size_mb:.1f} MB")
        
        # Process with enhanced settings
        print("🔄 Processing with enhanced analysis...")
        
        # Use higher FPS and more tokens for better analysis
        enhanced_config = {
            "temperature": 0.1,  # Lower temperature for more consistent output
            "topK": 1,
            "topP": 0.95,
            "maxOutputTokens": 6000,  # Increased token limit
            "responseMimeType": "text/plain"
        }
        
        enhanced_video_metadata = {
            "fps": 2.0  # Higher FPS for better temporal resolution
        }
        
        # Encode video
        print("🔄 Encoding video...")
        import base64
        try:
            with open(video_path, 'rb') as f:
                video_bytes = f.read()
            video_base64 = base64.b64encode(video_bytes).decode('utf-8')
        except Exception as e:
            print(f"❌ Error encoding video: {e}")
            return None
        
        # Prepare enhanced API request
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inline_data": {
                                "mime_type": "video/mp4",
                                "data": video_base64
                            },
                            "video_metadata": enhanced_video_metadata
                        }
                    ]
                }
            ],
            "generationConfig": enhanced_config
        }
        
        # Make API request
        import requests
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.config.GEMINI_MODEL}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }
        
        print("🚀 Sending enhanced request to Gemini API...")
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=400)  # Longer timeout
            
            if response.status_code == 200:
                result = response.json()
                
                # Extract token usage
                if "usageMetadata" in result:
                    usage = result["usageMetadata"]
                    total_tokens = usage.get('totalTokenCount', 0)
                    estimated_cost = (total_tokens / 1000) * 0.00015
                    print(f"💰 Tokens: {total_tokens}, Cost: ${estimated_cost:.6f}")
                
                # Extract RPA commands
                if "candidates" in result and len(result["candidates"]) > 0:
                    candidate = result["candidates"][0]
                    if "content" in candidate and "parts" in candidate["content"]:
                        text_parts = [part.get("text", "") for part in candidate["content"]["parts"]]
                        rpa_commands = "".join(text_parts).strip()
                        
                        # Save enhanced commands
                        base_name = os.path.splitext(os.path.basename(video_path))[0]
                        output_name = f"{base_name}_ENHANCED_rpa_commands.txt"
                        
                        output_dir = self.config.ensure_output_dir()
                        output_path = os.path.join(output_dir, output_name)
                        
                        from datetime import datetime
                        with open(output_path, 'w') as f:
                            f.write(f"# ENHANCED RPA Commands Generated: {datetime.now()}\n")
                            f.write(f"# Source Video: {os.path.basename(video_path)}\n")
                            f.write(f"# Source JSON: {os.path.basename(json_path)}\n")
                            f.write(f"# Processing Mode: Enhanced Complete Session Analysis\n\n")
                            f.write(rpa_commands)
                        
                        print(f"✅ Enhanced RPA commands saved to: {output_path}")
                        print(f"\n📋 Enhanced Commands Preview:")
                        print("-" * 60)
                        preview = rpa_commands[:400] + "..." if len(rpa_commands) > 400 else rpa_commands
                        print(preview)
                        
                        return rpa_commands
                        
            else:
                print(f"❌ API Error: HTTP {response.status_code}")
                
        except Exception as e:
            print(f"❌ Error: {e}")
            
        return None


def main():
    """Main function to run enhanced processing"""
    print("🚀 Enhanced Session Processor - Complete Workflow Capture")
    print("=" * 65)
    
    # Your specific files
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    try:
        processor = EnhancedSessionProcessor()
        commands = processor.process_enhanced_session(video_path, json_path)
        
        if commands:
            print(f"\n🎉 SUCCESS: Enhanced processing captured the complete workflow!")
            print(f"📁 Check 'generated_rpa_commands/' for the ENHANCED file")
        else:
            print(f"\n❌ Enhanced processing failed")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()