"""
Multimodal RPA Command Generator

This script processes recorded videos, audio, and interaction logs to generate 
RPA commands using Gemini's multimodal capabilities.

Features:
- Processes video + audio + interaction logs simultaneously
- Synchronizes timestamps across different data sources
- Uses Gemini AI for multimodal analysis
- Generates natural language RPA commands
- Handles batch processing of multiple recordings
"""

import os
import json
import base64
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from dotenv import load_dotenv
import re

@dataclass
class RecordingSession:
    """Represents a complete recording session with all associated files"""
    session_id: str
    video_path: Optional[str] = None
    audio_path: Optional[str] = None
    interactions_path: Optional[str] = None
    timestamp: Optional[datetime] = None

@dataclass
class ProcessedInteraction:
    """Represents a processed interaction with context"""
    timestamp: float
    action_type: str
    details: Dict
    context: str

class MultimodalRpaGenerator:
    def __init__(self, records_dir: str = "records"):
        """Initialize the RPA generator"""
        self.records_dir = records_dir
        self.api_key = self._load_api_key()
        self.model = "gemini-1.5-flash"
        
    def _load_api_key(self) -> str:
        """Load API key from environment"""
        load_dotenv()
        api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY or GOOGLE_API_KEY not found in environment")
        return api_key
    
    def discover_recording_sessions(self) -> List[RecordingSession]:
        """Discover and group recording sessions from the records directory"""
        sessions = {}
        
        # Scan all files in records directory
        for filename in os.listdir(self.records_dir):
            filepath = os.path.join(self.records_dir, filename)
            if not os.path.isfile(filepath):
                continue
                
            # Extract session identifier from filename
            session_id = self._extract_session_id(filename)
            if not session_id:
                continue
                
            # Initialize session if not exists
            if session_id not in sessions:
                sessions[session_id] = RecordingSession(session_id=session_id)
                
            # Assign files to appropriate session attributes
            if filename.endswith('.mp4'):
                if 'audio' not in filename:  # Main video file
                    sessions[session_id].video_path = filepath
            elif filename.endswith('.wav'):
                sessions[session_id].audio_path = filepath
            elif filename.endswith('_interactions.json'):
                sessions[session_id].interactions_path = filepath
                
        # Filter sessions that have at least video and interactions
        complete_sessions = []
        for session in sessions.values():
            if session.video_path and session.interactions_path:
                # Extract timestamp from session ID
                session.timestamp = self._parse_timestamp_from_session_id(session.session_id)
                complete_sessions.append(session)
                
        # Sort by timestamp
        complete_sessions.sort(key=lambda x: x.timestamp or datetime.min)
        return complete_sessions
    
    def _extract_session_id(self, filename: str) -> Optional[str]:
        """Extract session identifier from filename"""
        # Pattern: type_YYYYMMDD_HHMMSS
        patterns = [
            r'(enhanced_multiscreen|combined_media|full_comprehensive|streaming)_(\d{8}_\d{6})',
            r'(\w+)_recording_(\d{8}_\d{6})',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, filename)
            if match:
                return f"{match.group(1)}_{match.group(2)}"
        return None
    
    def _parse_timestamp_from_session_id(self, session_id: str) -> Optional[datetime]:
        """Parse timestamp from session ID"""
        try:
            # Extract YYYYMMDD_HHMMSS from session_id
            timestamp_match = re.search(r'(\d{8}_\d{6})', session_id)
            if timestamp_match:
                timestamp_str = timestamp_match.group(1)
                return datetime.strptime(timestamp_str, '%Y%m%d_%H%M%S')
        except:
            pass
        return None
    
    def load_interaction_logs(self, interactions_path: str) -> Tuple[Dict, List[ProcessedInteraction]]:
        """Load and process interaction logs"""
        with open(interactions_path, 'r') as f:
            data = json.load(f)
            
        session_info = data.get('session_info', {})
        processed_interactions = []
        
        # Process different types of interactions
        for interaction_type in ['mouse_interactions', 'keyboard_events', 'app_switches']:
            interactions = data.get(interaction_type, [])
            for interaction in interactions:
                processed = self._process_interaction(interaction, interaction_type)
                if processed:
                    processed_interactions.append(processed)
        
        # Sort by timestamp
        processed_interactions.sort(key=lambda x: x.timestamp)
        return session_info, processed_interactions
    
    def _process_interaction(self, interaction: Dict, interaction_type: str) -> Optional[ProcessedInteraction]:
        """Process individual interaction into structured format"""
        timestamp = interaction.get('timestamp', 0)
        
        if interaction_type == 'mouse_interactions':
            action_type = interaction.get('type', 'mouse_action')
            details = {
                'position': interaction.get('position', {}),
                'button': interaction.get('button'),
                'click_count': interaction.get('click_count')
            }
            context = f"Mouse {action_type} at ({details['position'].get('x')}, {details['position'].get('y')})"
            
        elif interaction_type == 'keyboard_events':
            action_type = 'keyboard'
            details = {
                'key': interaction.get('key'),
                'char': interaction.get('char'),
                'modifiers': interaction.get('modifiers', [])
            }
            key_info = details['char'] or details['key'] or 'unknown'
            context = f"Keyboard: {key_info}"
            if details['modifiers']:
                context += f" (with {', '.join(details['modifiers'])})"
                
        elif interaction_type == 'app_switches':
            action_type = 'app_switch'
            details = {
                'from_app': interaction.get('from_app'),
                'to_app': interaction.get('to_app')
            }
            context = f"Switched from {details['from_app']} to {details['to_app']}"
            
        else:
            return None
            
        return ProcessedInteraction(
            timestamp=timestamp,
            action_type=action_type,
            details=details,
            context=context
        )
    
    def create_interaction_timeline(self, interactions: List[ProcessedInteraction], 
                                  duration: float) -> str:
        """Create a formatted timeline of interactions"""
        timeline = []
        timeline.append("=== INTERACTION TIMELINE ===")
        
        for i, interaction in enumerate(interactions):
            timestamp_str = f"{interaction.timestamp:.2f}s"
            timeline.append(f"[{timestamp_str}] {interaction.context}")
            
            # Add spacing for readability
            if i < len(interactions) - 1:
                next_timestamp = interactions[i + 1].timestamp
                if next_timestamp - interaction.timestamp > 2.0:  # Gap > 2 seconds
                    timeline.append(f"... (pause for {next_timestamp - interaction.timestamp:.1f}s) ...")
        
        timeline.append(f"\nTotal Duration: {duration:.2f} seconds")
        timeline.append("=" * 30)
        return "\n".join(timeline)
    
    def generate_rpa_prompt(self, session_info: Dict, interactions: List[ProcessedInteraction], 
                           interaction_timeline: str) -> str:
        """Generate comprehensive prompt for Gemini"""
        
        # Count interaction types
        mouse_count = len([i for i in interactions if 'mouse' in i.action_type])
        keyboard_count = len([i for i in interactions if i.action_type == 'keyboard'])
        app_switch_count = len([i for i in interactions if i.action_type == 'app_switch'])
        
        prompt = f"""You are an expert RPA (Robotic Process Automation) command generator. Analyze this multimodal recording session to create comprehensive RPA commands.

SESSION INFORMATION:
- Platform: {session_info.get('platform', 'Unknown')}
- Duration: {session_info.get('duration', 0):.2f} seconds
- Total Interactions: {session_info.get('interaction_count', 0)}
- Mouse Actions: {mouse_count}
- Keyboard Events: {keyboard_count}
- App Switches: {app_switch_count}

DETAILED INTERACTION LOG:
{interaction_timeline}

VIDEO + AUDIO ANALYSIS INSTRUCTIONS:
1. Watch the video carefully to see the actual UI elements being interacted with
2. Listen to any audio narration or system sounds that provide context
3. Correlate the visual actions with the logged interaction timestamps
4. Identify the application being used and the business process being performed
5. Note any specific UI elements (buttons, fields, menus, dialogs)

RPA COMMAND GENERATION REQUIREMENTS:
Generate natural language RPA commands that follow this format:

EXAMPLE FORMAT:
"Login to [Application] using username [USERNAME] and password [PASSWORD], then click to Login. Then click on the [SECTION] and click [ACTION]. Once on the [PAGE] type '[SEARCH_TERM]' and press enter. Once on the [RESULT_PAGE], you'll see [DESCRIPTION]. Type '[VALUE]' into the [FIELD] and press enter to [ACTION]. Then double click on the [ELEMENT] option when you see it..."

KEY REQUIREMENTS:
- Use precise UI element descriptions (button names, field labels, etc.)
- Include specific values typed or selected
- Mention any error handling needed
- Describe the logical flow and decision points
- Include wait conditions ("Once on...", "When you see...")
- Be specific about search terms, usernames, values entered
- Handle popups, confirmations, and error dialogs
- End with a clear completion condition

CRITICAL: Your output should be ONLY the RPA commands in natural language format, no additional explanation or formatting. Study both the video content AND the interaction logs to ensure accuracy."""

        return prompt
    
    def encode_video_to_base64(self, video_path: str) -> str:
        """Encode video file to base64"""
        with open(video_path, 'rb') as f:
            video_bytes = f.read()
        return base64.b64encode(video_bytes).decode('utf-8')
    
    def check_file_size(self, file_path: str, max_mb: int = 20) -> bool:
        """Check if file is under size limit"""
        try:
            size_mb = os.path.getsize(file_path) / (1024 * 1024)
            print(f"File size: {size_mb:.2f} MB")
            if size_mb > max_mb:
                print(f"Warning: File is over {max_mb}MB limit")
                return False
            return True
        except Exception as e:
            print(f"Error checking file size: {e}")
            return False
    
    def process_session_to_rpa_commands(self, session: RecordingSession) -> Optional[str]:
        """Process a complete recording session to generate RPA commands"""
        print(f"\n🎬 Processing session: {session.session_id}")
        print(f"📹 Video: {session.video_path}")
        print(f"📊 Interactions: {session.interactions_path}")
        
        # Check video file size
        if not self.check_file_size(session.video_path):
            print("❌ Video file too large, skipping...")
            return None
        
        # Load interaction logs
        try:
            session_info, interactions = self.load_interaction_logs(session.interactions_path)
            print(f"📋 Loaded {len(interactions)} interactions")
        except Exception as e:
            print(f"❌ Error loading interaction logs: {e}")
            return None
        
        # Create interaction timeline
        duration = session_info.get('duration', 0)
        interaction_timeline = self.create_interaction_timeline(interactions, duration)
        
        # Generate prompt
        prompt = self.generate_rpa_prompt(session_info, interactions, interaction_timeline)
        
        # Encode video
        try:
            print("🔄 Encoding video...")
            video_base64 = self.encode_video_to_base64(session.video_path)
        except Exception as e:
            print(f"❌ Error encoding video: {e}")
            return None
        
        # Prepare API request
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inline_data": {
                                "mime_type": "video/mp4",
                                "data": video_base64
                            },
                            "video_metadata": {
                                "fps": 1.0  # Analyze 1 frame per second
                            }
                        }
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "topK": 1,
                "topP": 0.9,
                "maxOutputTokens": 4000,
                "responseMimeType": "text/plain"
            }
        }
        
        # Make API request
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }
        
        print("🚀 Sending to Gemini API...")
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=300)
            
            if response.status_code == 200:
                result = response.json()
                
                # Extract token usage
                if "usageMetadata" in result:
                    usage = result["usageMetadata"]
                    total_tokens = usage.get('totalTokenCount', 0)
                    estimated_cost = (total_tokens / 1000) * 0.00015
                    print(f"💰 Tokens used: {total_tokens}, Est. cost: ${estimated_cost:.6f}")
                
                # Extract generated RPA commands
                if "candidates" in result and len(result["candidates"]) > 0:
                    candidate = result["candidates"][0]
                    if "content" in candidate and "parts" in candidate["content"]:
                        text_parts = [part.get("text", "") for part in candidate["content"]["parts"]]
                        rpa_commands = "".join(text_parts).strip()
                        
                        # Save RPA commands to file
                        output_file = f"{session.session_id}_rpa_commands.txt"
                        output_path = os.path.join("generated_rpa_commands", output_file)
                        os.makedirs("generated_rpa_commands", exist_ok=True)
                        
                        with open(output_path, 'w') as f:
                            f.write(rpa_commands)
                        
                        print(f"✅ RPA commands saved to: {output_path}")
                        return rpa_commands
                    
            else:
                print(f"❌ API Error: HTTP {response.status_code}")
                try:
                    error_detail = response.json()
                    print(json.dumps(error_detail, indent=2))
                except:
                    print(response.text)
                    
        except requests.exceptions.Timeout:
            print("⏱️ Request timed out")
        except Exception as e:
            print(f"❌ Error: {e}")
            
        return None
    
    def process_all_sessions(self, max_sessions: Optional[int] = None) -> List[str]:
        """Process all recording sessions to generate RPA commands"""
        print("🔍 Discovering recording sessions...")
        sessions = self.discover_recording_sessions()
        
        if not sessions:
            print("❌ No complete recording sessions found")
            return []
        
        print(f"📁 Found {len(sessions)} complete recording sessions")
        
        if max_sessions:
            sessions = sessions[:max_sessions]
            print(f"🎯 Processing first {max_sessions} sessions")
        
        generated_commands = []
        
        for i, session in enumerate(sessions, 1):
            print(f"\n{'='*60}")
            print(f"PROCESSING SESSION {i}/{len(sessions)}")
            print(f"{'='*60}")
            
            rpa_commands = self.process_session_to_rpa_commands(session)
            if rpa_commands:
                generated_commands.append(rpa_commands)
                print(f"\n✅ Session {i} completed successfully")
            else:
                print(f"\n❌ Session {i} failed")
        
        print(f"\n🎉 Processing complete! Generated {len(generated_commands)} RPA command sets")
        return generated_commands


def main():
    """Main function to run the multimodal RPA generator"""
    print("🤖 Multimodal RPA Command Generator")
    print("=" * 50)
    
    try:
        generator = MultimodalRpaGenerator()
        
        # Process all sessions (limit to 3 for testing)
        rpa_commands = generator.process_all_sessions(max_sessions=3)
        
        if rpa_commands:
            print(f"\n🎯 Generated RPA Commands Preview:")
            print("-" * 50)
            for i, commands in enumerate(rpa_commands, 1):
                print(f"\n📋 Session {i} Commands:")
                print(commands[:200] + "..." if len(commands) > 200 else commands)
                
    except Exception as e:
        print(f"❌ Fatal error: {e}")


if __name__ == "__main__":
    main()