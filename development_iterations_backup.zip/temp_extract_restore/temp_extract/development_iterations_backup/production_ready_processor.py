#!/usr/bin/env python3
"""
Production-Ready RPA Processor

Takes the ultra-precise output and enhances it with:
- Element selectors instead of just coordinates
- Field validation and wait conditions
- Error handling and retry logic
- Production-grade RPA commands
"""

from ultra_precise_rpa_processor import UltraPreciseRpaProcessor

class ProductionReadyProcessor(UltraPreciseRpaProcessor):
    """Production-ready processor with enhanced accuracy features"""
    
    def create_production_prompt(self, detailed_timeline: str) -> str:
        """Create prompt for production-ready RPA commands"""
        
        prompt = f"""You are an expert RPA developer creating production-ready automation commands. Generate RPA commands with MAXIMUM ACCURACY and RELIABILITY.

CRITICAL REQUIREMENTS:
🎯 ELEMENT IDENTIFICATION: Use multiple identification methods (text, class, ID, xpath)
🎯 FIELD VALIDATION: Include confirmation checks after each data entry
🎯 ERROR HANDLING: Add retry logic and error detection
🎯 WAIT CONDITIONS: Explicit waits for element availability
🎯 BUSINESS LOGIC: Maintain workflow context and validation

{detailed_timeline}

PRODUCTION-READY OUTPUT REQUIREMENTS:

✅ ELEMENT SELECTORS (Not just coordinates):
- Use element text content when available
- Include backup selectors (class, ID, xpath)
- Example: Click("Login Button", text="Login", class="btn-primary")

✅ FIELD VALIDATION:
- Verify field accepts input before typing
- Confirm field contains expected value after typing
- Example: Type("SAGB123456", field="Security") → Verify("Security field contains 'SAGB123456'")

✅ WAIT CONDITIONS:
- Wait for elements to be visible/enabled
- Wait for page transitions to complete
- Example: WaitFor("Bonds page to load") → Click("Process button")

✅ ERROR HANDLING:
- Detect and handle common errors
- Retry failed operations
- Example: If(PopupExists("Error")) → Click("OK") → Retry(last_action)

✅ DROPDOWN HANDLING:
- Open dropdown → Wait for options → Select by text → Verify selection
- Example: OpenDropdown("Currency") → SelectOption("ZAR") → VerifySelected("ZAR")

EXAMPLE PRODUCTION FORMAT:
```
// Login Process
WaitFor("Login page to load")
Type("MUREXFO", field="Username", selector="input[name='username']")
Type("[PASSWORD]", field="Password", selector="input[type='password']") 
Click("Login button", text="Login", class="login-btn")
WaitFor("Welcome screen", timeout=30)

// Navigation
Click("START button", text="START", wait_after=2)
WaitFor("Main application to load")
NavigateTo("Bonds", menu_path="History > Bonds")

// Field Population with Validation
OpenField("Security")
Type("SAGB123456", verify_after=true)
PressKey("ENTER")

SelectDropdown("Currency", option="ZAR", verify_selection=true)
```

Generate complete production-ready RPA commands that include all validation, error handling, and reliability features."""

        return prompt
    
    def process_production_ready(self, video_path: str, json_path: str) -> str:
        """Process with production-ready enhancements"""
        
        print(f"🏭 Production-Ready RPA Processing")
        print("=" * 50)
        
        # Use ultra-precise timeline
        detailed_timeline = self.create_ultra_detailed_timeline(json_path)
        
        # Create production prompt
        prompt = self.create_production_prompt(detailed_timeline)
        
        # Process with production settings
        return self.process_with_custom_prompt(video_path, json_path, prompt, "PRODUCTION_READY")


if __name__ == "__main__":
    processor = ProductionReadyProcessor()
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    processor.process_production_ready(video_path, json_path)