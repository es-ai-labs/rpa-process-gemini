#!/usr/bin/env python3
"""
Test Script for Complete Video Processor

Demonstrates the enhanced complete video processing that ensures 
end-to-end workflow capture from video start to finish.
"""

import os
import sys
from complete_video_processor import CompleteVideoProcessor
from workflow_validator import WorkflowValidator

def test_complete_processing():
    """Test the complete video processor with validation"""
    
    print("🎬 Testing Complete Video Processor")
    print("=" * 70)
    print("Ensuring end-to-end workflow capture from video start to finish")
    
    # Initialize components
    validator = WorkflowValidator()
    processor = CompleteVideoProcessor()
    
    # Test file paths
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    print(f"📹 Testing with video: {video_path}")
    print(f"📊 Testing with JSON: {json_path}")
    
    # Check if files exist
    if not os.path.exists(video_path):
        print(f"❌ Video file not found: {video_path}")
        print("💡 Please update the file paths in the script or provide them as arguments")
        return False
    
    if not os.path.exists(json_path):
        print(f"❌ JSON file not found: {json_path}")
        print("💡 Please update the file paths in the script or provide them as arguments")
        return False
    
    # Step 1: Analyze video duration and coverage
    print("\n🔍 Step 1: Analyzing video duration and interaction coverage...")
    session_duration, first_interaction, last_interaction = processor.analyze_complete_video_duration(json_path)
    
    print(f"📊 Video Analysis Results:")
    print(f"   • Total Duration: {session_duration:.1f} seconds")
    print(f"   • First Interaction: {first_interaction:.1f}s")
    print(f"   • Last Interaction: {last_interaction:.1f}s")
    print(f"   • Active Period: {last_interaction - first_interaction:.1f}s")
    
    # Calculate coverage percentage
    if session_duration > 0:
        coverage_percent = ((last_interaction - first_interaction) / session_duration) * 100
        print(f"   • Coverage: {coverage_percent:.1f}% of total video")
        
        if coverage_percent < 50:
            print("   ⚠️  Low coverage - may indicate gaps in workflow")
        elif coverage_percent > 80:
            print("   ✅ Good coverage across video duration")
    
    # Step 2: Validate inputs
    print("\n🔍 Step 2: Validating inputs...")
    validation_results = validator.validate_complete_workflow(video_path, json_path)
    is_valid = validator.print_validation_summary(validation_results)
    
    if not is_valid:
        print("❌ Validation failed - cannot proceed with testing")
        return False
    
    # Step 3: Process complete workflow
    print("\n🎬 Step 3: Processing complete video for end-to-end workflow...")
    try:
        rpa_commands = processor.process_complete_workflow(video_path, json_path)
        
        if rpa_commands:
            print("✅ Complete RPA workflow generated successfully!")
            
            # Step 4: Assess completeness
            print("\n🔍 Step 4: Assessing workflow completeness...")
            interactions = processor.extract_enhanced_interactions(json_path)
            completion_score = processor._assess_workflow_completeness(
                rpa_commands, session_duration, interactions
            )
            
            print("📊 Completeness Assessment:")
            print(f"   • Overall Score: {completion_score['score']:.1f}/10")
            print(f"   • Has Login: {'✅' if completion_score['has_login'] else '❌'}")
            print(f"   • Has Completion: {'✅' if completion_score['has_completion'] else '❌'}")
            print(f"   • Adequate Length: {'✅' if completion_score['adequate_length'] else '❌'}")
            print(f"   • Command Length: {completion_score['command_length']} chars")
            print(f"   • Expected Minimum: {completion_score['expected_min_length']} chars")
            
            # Step 5: Analyze command sections
            print(f"\n📋 Step 5: Analyzing command structure...")
            sections = analyze_command_sections(rpa_commands)
            
            print("Command Structure Analysis:")
            for section, found in sections.items():
                icon = "✅" if found else "❌"
                print(f"   {icon} {section}")
            
            # Step 6: Display sample output
            print(f"\n📄 Complete Workflow Sample:")
            print("-" * 50)
            sample = rpa_commands[:400] + "..." if len(rpa_commands) > 400 else rpa_commands
            print(sample)
            
            # Final assessment
            print(f"\n🎯 Final Assessment:")
            if completion_score['score'] >= 8:
                print("   🎉 Excellent - Complete workflow captured end-to-end")
            elif completion_score['score'] >= 6:
                print("   ✅ Good - Most workflow elements captured")
            elif completion_score['score'] >= 4:
                print("   ⚠️  Fair - Some workflow elements may be missing")
            else:
                print("   ❌ Poor - Significant workflow elements missing")
            
            return completion_score['score'] >= 6
            
        else:
            print("❌ Failed to generate complete RPA workflow")
            return False
            
    except Exception as e:
        print(f"❌ Error during complete processing: {e}")
        return False

def analyze_command_sections(rpa_commands: str) -> dict:
    """Analyze if the commands contain expected workflow sections"""
    
    command_lower = rpa_commands.lower()
    
    sections = {
        'Login/Authentication': any(word in command_lower for word in ['login', 'username', 'password', 'authenticate']),
        'Navigation/Menu': any(word in command_lower for word in ['navigate', 'menu', 'click', 'main page']),
        'Search/Filter': any(word in command_lower for word in ['search', 'type', 'filter', 'find']),
        'Data Entry': any(word in command_lower for word in ['enter', 'input', 'field', 'dropdown', 'select']),
        'Actions/Operations': any(word in command_lower for word in ['button', 'click', 'double-click', 'press']),
        'Completion/Result': any(word in command_lower for word in ['complete', 'finish', 'result', 'final', 'close', 'done'])
    }
    
    return sections

def compare_processors():
    """Compare the different processor approaches"""
    
    print("\n" + "=" * 70)
    print("🔄 PROCESSOR COMPARISON")
    print("=" * 70)
    
    print("1️⃣ GENERIC PROCESSOR:")
    print("   • Mechanical interaction capture")
    print("   • Limited context understanding")
    print("   • May miss workflow completion")
    print("   • Basic timeline grouping")
    
    print("\n2️⃣ ENHANCED PROCESSOR:")
    print("   • Video-aware UI element detection")
    print("   • Better contextual mapping")
    print("   • Improved human-readable output")
    print("   • Time window analysis")
    
    print("\n3️⃣ COMPLETE PROCESSOR (NEW):")
    print("   • End-to-end video coverage analysis")
    print("   • Gap detection and coverage validation")
    print("   • Workflow completeness assessment")
    print("   • Mandatory start-to-finish processing")
    print("   • Enhanced prompt for complete workflows")
    
    print("\n🎯 KEY IMPROVEMENTS:")
    print("   ✅ Analyzes complete video duration")
    print("   ✅ Detects interaction gaps")
    print("   ✅ Validates workflow completeness")
    print("   ✅ Ensures end-state capture")
    print("   ✅ Higher token limit for complete workflows")

def main():
    """Main function for testing complete processor"""
    
    print("🎬 Complete Video Processor - Test Suite")
    print("=" * 70)
    print("Testing end-to-end video analysis with complete workflow capture")
    print("=" * 70)
    
    # Check command line arguments
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "test":
            success = test_complete_processing()
            sys.exit(0 if success else 1)
        elif command == "compare":
            compare_processors()
            return
        elif command == "process":
            if len(sys.argv) > 3:
                video_path = sys.argv[2]
                json_path = sys.argv[3]
                processor = CompleteVideoProcessor()
                workflow = processor.process_complete_workflow(video_path, json_path)
                if workflow:
                    print("✅ Complete workflow generated successfully!")
                else:
                    print("❌ Failed to generate complete workflow")
            else:
                print("Usage: python test_complete_processor.py process <video_path> <json_path>")
            return
    
    # Default: Run comparison and test if files exist
    compare_processors()
    
    # Try to run test with default files
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    if os.path.exists(video_path) and os.path.exists(json_path):
        print(f"\n🔍 Found test files - running complete processing test...")
        success = test_complete_processing()
        if success:
            print(f"\n🎉 Complete processing test PASSED!")
        else:
            print(f"\n❌ Complete processing test FAILED!")
    else:
        print(f"\n💡 To run live test with your files:")
        print(f"   python test_complete_processor.py process <video_path> <json_path>")
        print(f"\n   Or update the default paths in the script:")
        print(f"   📹 {video_path}")
        print(f"   📊 {json_path}")

if __name__ == "__main__":
    main()