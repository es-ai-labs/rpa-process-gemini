#!/usr/bin/env python3
"""
Test Script for Enhanced Murex RPA Generator

Demonstrates how to use the enhanced RPA workflow generation system
with validation, error handling, and human-readable output.
"""

import os
import sys
from enhanced_murex_rpa_generator import EnhancedMurexRpaGenerator
from workflow_validator import WorkflowValidator

def test_enhanced_generator():
    """Test the enhanced RPA generator with validation"""
    
    print("🧪 Testing Enhanced Murex RPA Generator")
    print("=" * 60)
    
    # Initialize components
    validator = WorkflowValidator()
    generator = EnhancedMurexRpaGenerator()
    
    # Test file paths - update these to match your actual recording files
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    print(f"📹 Testing with video: {video_path}")
    print(f"📊 Testing with JSON: {json_path}")
    
    # Step 1: Validate inputs
    print("\n🔍 Step 1: Validating inputs...")
    validation_results = validator.validate_complete_workflow(video_path, json_path)
    is_valid = validator.print_validation_summary(validation_results)
    
    if not is_valid:
        print("❌ Validation failed - cannot proceed with testing")
        return False
    
    # Step 2: Generate enhanced workflow
    print("\n🚀 Step 2: Generating enhanced RPA workflow...")
    try:
        rpa_commands = generator.process_enhanced_workflow(video_path, json_path)
        
        if rpa_commands:
            print("✅ RPA workflow generated successfully!")
            
            # Step 3: Validate output
            print("\n🔍 Step 3: Validating generated workflow...")
            output_validation = validator.validate_workflow_output(rpa_commands)
            
            print("\n📋 OUTPUT VALIDATION:")
            for result in output_validation:
                if result.severity == 'error':
                    icon = "❌"
                elif result.severity == 'warning':
                    icon = "⚠️"
                else:
                    icon = "✅"
                
                print(f"   {icon} {result.message}")
                if result.suggestion:
                    print(f"      💡 {result.suggestion}")
            
            # Step 4: Display sample output
            print(f"\n📄 Sample Generated Commands:")
            print("-" * 40)
            sample = rpa_commands[:300] + "..." if len(rpa_commands) > 300 else rpa_commands
            print(sample)
            
            print(f"\n🎉 Test completed successfully!")
            return True
            
        else:
            print("❌ Failed to generate RPA workflow")
            return False
            
    except Exception as e:
        print(f"❌ Error during generation: {e}")
        return False

def demo_workflow_comparison():
    """Demonstrate the difference between generic and enhanced processing"""
    
    print("\n" + "=" * 60)
    print("🔄 COMPARISON: Generic vs Enhanced Processing")
    print("=" * 60)
    
    print("📊 GENERIC APPROACH (Current):")
    print("   • Mechanical interaction capture")
    print("   • Coordinate-based actions")
    print("   • Limited UI context")
    print("   • Generic descriptions")
    
    print("\n🚀 ENHANCED APPROACH (New):")
    print("   • Video-aware UI element detection")
    print("   • Contextual action mapping")
    print("   • Semantic understanding")
    print("   • Human-editable structure")
    print("   • Optimized frame rate for UI (0.8 fps)")
    print("   • Validation and error handling")
    
    print("\n💡 KEY IMPROVEMENTS:")
    print("   ✅ Better UI element identification")
    print("   ✅ More accurate command descriptions") 
    print("   ✅ Structured, editable output")
    print("   ✅ Robust validation system")
    print("   ✅ Cost-optimized video processing")

def show_usage_examples():
    """Show examples of how to use the enhanced generator"""
    
    print("\n" + "=" * 60)
    print("📚 USAGE EXAMPLES")
    print("=" * 60)
    
    print("1️⃣ BASIC USAGE:")
    print("   python enhanced_murex_rpa_generator.py video.mp4 interactions.json")
    
    print("\n2️⃣ WITH VALIDATION:")
    print("   python test_enhanced_generator.py")
    
    print("\n3️⃣ PROGRAMMATIC USAGE:")
    print("""   from enhanced_murex_rpa_generator import EnhancedMurexRpaGenerator
   from workflow_validator import WorkflowValidator
   
   # Validate inputs
   validator = WorkflowValidator()
   is_valid = validator.validate_complete_workflow(video_path, json_path)
   
   # Generate workflow
   if is_valid:
       generator = EnhancedMurexRpaGenerator()
       commands = generator.process_enhanced_workflow(video_path, json_path)""")
    
    print("\n4️⃣ OUTPUT FORMATS:")
    print("   • Raw commands: For direct RPA engine consumption")
    print("   • Structured file: Human-readable with headers and sections")
    print("   • Validation report: Detailed quality assessment")

def main():
    """Main function for testing and demonstration"""
    
    print("🧪 Enhanced Murex RPA Generator - Test Suite")
    print("=" * 60)
    print("Testing the new video-aware, context-sensitive RPA generator")
    print("=" * 60)
    
    # Check command line arguments
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "test":
            success = test_enhanced_generator()
            sys.exit(0 if success else 1)
        elif command == "demo":
            demo_workflow_comparison()
            show_usage_examples()
            return
        elif command == "validate":
            if len(sys.argv) > 3:
                video_path = sys.argv[2]
                json_path = sys.argv[3]
                validator = WorkflowValidator()
                results = validator.validate_complete_workflow(video_path, json_path)
                validator.print_validation_summary(results)
            else:
                print("Usage: python test_enhanced_generator.py validate <video_path> <json_path>")
            return
    
    # Default: Run full demonstration
    print("Running full demonstration...")
    
    # Show comparison
    demo_workflow_comparison()
    
    # Show usage examples
    show_usage_examples()
    
    # Attempt to run test if files exist
    video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
    json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
    
    if os.path.exists(video_path) and os.path.exists(json_path):
        print(f"\n🔍 Found test files - running live test...")
        test_enhanced_generator()
    else:
        print(f"\n💡 To run live test, ensure these files exist:")
        print(f"   📹 {video_path}")
        print(f"   📊 {json_path}")
        print(f"\n   Or run: python test_enhanced_generator.py validate <video> <json>")

if __name__ == "__main__":
    main()