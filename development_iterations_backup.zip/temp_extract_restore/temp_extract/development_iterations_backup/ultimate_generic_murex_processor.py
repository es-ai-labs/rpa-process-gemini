#!/usr/bin/env python3
"""
Ultimate Generic Murex Processor

The most flexible processor for ANY Murex workflow:
- Auto-detects workflow patterns without assumptions
- Adapts to different Murex modules (Trading, Risk, Config, etc.)
- Generates truly reusable RPA commands
- Works for bonds, FX, derivatives, reports, configuration, etc.
"""

import sys
from generic_murex_processor import GenericMurexProcessor

class UltimateGenericMurexProcessor(GenericMurexProcessor):
    """Ultimate flexible processor for any Murex workflow"""
    
    def create_ultimate_generic_prompt(self, interaction_sequence: str) -> str:
        """Create the most flexible prompt for any Murex process"""
        
        prompt = f"""You are an expert RPA automation analyst creating universally reusable commands for Murex application workflows. Your task is to generate generic, mechanical instructions that work across ALL Murex modules and processes.

UNIVERSAL APPROACH:
🎯 ZERO ASSUMPTIONS: Do not assume workflow type (trading, bonds, configuration, reporting, etc.)
🎯 MECHANICAL ACTIONS: Describe HOW the user interacts, not WHAT business process
🎯 PATTERN RECOGNITION: Identify interaction patterns that repeat across workflows
🎯 MUREX AGNOSTIC: Commands should work in any Murex module or screen

{interaction_sequence}

ULTIMATE GENERIC OUTPUT STYLE:

✅ UNIVERSAL LOGIN PATTERN:
"Login to Murex application using provided credentials and navigate to the target functional area."

✅ GENERIC NAVIGATION PATTERN:
"Navigate through the menu hierarchy to reach the desired work area. Click through menu items and wait for screen transitions."

✅ UNIVERSAL DATA ENTRY PATTERN:
"In the main work area, interact with form elements in sequence:
- Locate and click into input fields
- Enter the specified values
- Use Tab to move between fields
- Use Enter to confirm entries
- Use Delete key to make corrections
- Select options from dropdown menus
- Click buttons to proceed"

✅ GENERIC COMPLETION PATTERN:
"Execute the final submission sequence by clicking the primary action button (Process/Submit/Save/Execute) and handle any confirmation dialogs."

INTERACTION PATTERN CATEGORIES:
1. **Login & Authentication**
2. **Menu Navigation & Screen Transitions**  
3. **Form Population & Data Entry**
4. **Selection & Configuration**
5. **Validation & Correction**
6. **Submission & Confirmation**

EXAMPLE ULTIMATE GENERIC OUTPUT:
"Perform standard Murex login using the designated credentials. Navigate through the application menu structure to access the target functional module. Once in the main work area, execute the data entry sequence: populate form fields with the specified values using standard field navigation (Tab/Enter). Make data corrections as needed using Delete key and re-entry. Select appropriate options from dropdown controls. Complete the workflow by executing the primary submission action and confirming any system prompts."

Generate RPA commands that describe the user's mechanical interaction pattern with the Murex interface in a way that applies to ANY Murex workflow or module."""

        return prompt
    
    def process_ultimate_generic_session(self, video_path: str, json_path: str) -> str:
        """Process with ultimate flexibility for any workflow"""
        
        print(f"🌟 Ultimate Generic Murex Processor")
        print("=" * 50)
        print("Works for ALL Murex workflows: Trading, Bonds, FX, Derivatives,")
        print("Risk Management, Configuration, Reporting, Analytics, etc.")
        
        # Extract interaction sequence
        interaction_sequence = self.extract_interaction_sequence(json_path)
        
        # Count interactions
        lines = interaction_sequence.split('\n')
        interaction_count = len([l for l in lines if l.startswith('[')])
        print(f"🔍 Processing {interaction_count} universal interaction patterns")
        
        # Create ultimate generic prompt
        prompt = self.create_ultimate_generic_prompt(interaction_sequence)
        
        # Process with ultimate generic settings
        return self._process_with_ultimate_settings(video_path, json_path, prompt)
    
    def _process_with_ultimate_settings(self, video_path: str, json_path: str, prompt: str) -> str:
        """Process with optimized settings for universal workflows"""
        
        import os
        import base64
        import requests
        from datetime import datetime
        
        # Check video size
        size_mb = os.path.getsize(video_path) / (1024 * 1024)
        if size_mb > self.config.MAX_FILE_SIZE_MB:
            print(f"❌ Video file too large: {size_mb:.1f} MB")
            return None
        
        print(f"✅ Video size OK: {size_mb:.1f} MB")
        
        # Encode video
        print("🔄 Analyzing for universal patterns...")
        try:
            with open(video_path, 'rb') as f:
                video_bytes = f.read()
            video_base64 = base64.b64encode(video_bytes).decode('utf-8')
        except Exception as e:
            print(f"❌ Error encoding video: {e}")
            return None
        
        # Ultimate generic configuration
        ultimate_config = {
            "temperature": 0.4,  # Balanced for pattern recognition
            "topK": 10,
            "topP": 0.85,
            "maxOutputTokens": 3500,  # Focused on patterns
            "responseMimeType": "text/plain"
        }
        
        ultimate_video_metadata = {
            "fps": 1.5  # Balanced analysis
        }
        
        # API request
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inline_data": {
                                "mime_type": "video/mp4",
                                "data": video_base64
                            },
                            "video_metadata": ultimate_video_metadata
                        }
                    ]
                }
            ],
            "generationConfig": ultimate_config
        }
        
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.config.GEMINI_MODEL}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }
        
        print("🚀 Generating universal Murex workflow patterns...")
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=300)
            
            if response.status_code == 200:
                result = response.json()
                
                # Token usage
                if "usageMetadata" in result:
                    usage = result["usageMetadata"]
                    total_tokens = usage.get('totalTokenCount', 0)
                    estimated_cost = (total_tokens / 1000) * 0.00015
                    print(f"💰 Tokens: {total_tokens:,}, Cost: ${estimated_cost:.6f}")
                
                # Extract commands
                if "candidates" in result and len(result["candidates"]) > 0:
                    candidate = result["candidates"][0]
                    if "content" in candidate and "parts" in candidate["content"]:
                        text_parts = [part.get("text", "") for part in candidate["content"]["parts"]]
                        rpa_commands = "".join(text_parts).strip()
                        
                        # Save ultimate generic commands
                        base_name = os.path.splitext(os.path.basename(video_path))[0]
                        output_name = f"{base_name}_ULTIMATE_GENERIC_rpa_commands.txt"
                        
                        output_dir = self.config.ensure_output_dir()
                        output_path = os.path.join(output_dir, output_name)
                        
                        with open(output_path, 'w') as f:
                            f.write(f"# Ultimate Generic Murex RPA Commands Generated: {datetime.now()}\n")
                            f.write(f"# Source Video: {os.path.basename(video_path)}\n")
                            f.write(f"# Source JSON: {os.path.basename(json_path)}\n")
                            f.write(f"# Processing Mode: Universal Workflow Patterns\n")
                            f.write(f"# Application: Murex (Any Module/Workflow)\n")
                            f.write(f"# Reusable For: Trading, Bonds, FX, Risk, Config, Reports, etc.\n\n")
                            f.write(rpa_commands)
                        
                        print(f"✅ Ultimate generic RPA commands saved to: {output_path}")
                        print(f"\n🌟 Ultimate Generic Preview:")
                        print("-" * 60)
                        preview = rpa_commands[:400] + "..." if len(rpa_commands) > 400 else rpa_commands
                        print(preview)
                        
                        print(f"\n🎯 Universal Workflow Analysis:")
                        print(f"   • Workflow type: Pattern-based (any Murex module)")
                        print(f"   • Interactions: Universal patterns identified")
                        print(f"   • Reusability: ALL Murex workflows")
                        print(f"   • Modules: Trading, Bonds, FX, Risk, Config, Reports")
                        
                        return rpa_commands
                        
            else:
                print(f"❌ API Error: HTTP {response.status_code}")
                
        except Exception as e:
            print(f"❌ Error: {e}")
            
        return None


def main():
    """Main function with flexible file input"""
    print("🌟 Ultimate Generic Murex Processor")
    print("=" * 55)
    print("Universal RPA commands for ANY Murex workflow")
    print("Works across ALL modules: Trading, Bonds, FX, Risk, Config, Reports")
    print("=" * 55)
    
    # Flexible file input
    if len(sys.argv) == 3:
        video_path = sys.argv[1]
        json_path = sys.argv[2]
        print(f"📁 Processing specified files:")
    else:
        # Default files
        video_path = "records/enhanced_multiscreen_20250803_064201.mp4"
        json_path = "records/enhanced_multiscreen_interactions_20250803_064519.json"
        print(f"📁 Processing default files:")
    
    print(f"   📹 Video: {video_path}")
    print(f"   📊 JSON:  {json_path}")
    
    try:
        processor = UltimateGenericMurexProcessor()
        commands = processor.process_ultimate_generic_session(video_path, json_path)
        
        if commands:
            print(f"\n🎉 SUCCESS: Ultimate generic Murex RPA commands generated!")
            print(f"🌟 Works for ALL Murex workflows and modules")
            print(f"✅ Trading workflows")
            print(f"✅ Bond/Fixed Income workflows") 
            print(f"✅ FX/Derivatives workflows")
            print(f"✅ Risk Management workflows")
            print(f"✅ Configuration workflows")
            print(f"✅ Reporting workflows")
            print(f"📁 Ready for your RPA execution engine")
        else:
            print(f"\n❌ Ultimate processing failed")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()